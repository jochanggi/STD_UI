import Vue from "vue";
import VueCookie from 'vue-cookie';
import './plugins/axios';
import App from "./App.vue";
import router from "./router";
import store from "./store";
import "./registerServiceWorker";
import i18n from './i18n';


// import VueAnalytics from 'vue-analytics'


// console.log('@@@@ Environment:', process.env.NODE_ENV);

Vue.config.productionTip = false;
Vue.config.silent = true;

Vue.use(VueCookie);

/*if(process.env.NODE_ENV === 'production') {
  Vue.use(VueAnalytics, {
    id: _googleId,
    router,
    debug: {
      enabled: true
    }
  });
} else {
  Vue.config.performance = true;
}*/

// router.beforeEach((to, from, next) => {
//   console.log('@@@@ router.beforeEach', to, from, next);
//   return next();
// });

router.afterEach((to, from) => {

  // console.log('@@@@ router.afterEach', to, from);
  
  // var linkName = `dev_${to.name}`;

  // s.linkTrackVars='events';
  // s.linkTrackEvents=to.name;
  // s.events=to.name;

  // console.log('@@@@ omniture', s);

  // console.log('omniture', param);
  var link = {
    href: to.path
  }
  // s.tl(link,'o', `${to.path} - page load`);

  var linkName = to.name;
  console.log('omniture link name :', linkName);
  s.tl(this, 'o', linkName);

  // var pageName = to.name;

  // var requestData = {
  //     "reportDescription":{
  //         "reportSuiteID": pageName
  //     }
  // }    
 
  // Vue.omni.queueAndFetchReport(requestData,function(success,data) {
  //     if ( success ) {
  //         console.log(data);
  //     } else {
  //         console.error(data);
  //     }
  // });

})

var vm = new Vue({
  router,
  store,
  i18n,
  render: h => h(App)
}).$mount("#app");



