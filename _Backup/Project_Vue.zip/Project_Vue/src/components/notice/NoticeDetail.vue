<template>
	<!-- content -->
	<section id="content" class="content notice-cont">
		<!-- content Header -->
		<div class="content-header sub-visual">
			<div class="sub-visual-bg"></div>
			<div class="in-sec">
				<div class="tit-wrap centered-c">
					<h2 class="tit-h2">{{ $t('sdp.menu.notice') }}</h2>
					<p class="explain-h2">{{ $t('sdp.notic.message.title') }}</p>
				</div>
			</div>
		</div>
	<!-- //content Header -->
	<!-- content Body -->
	<div class="content-body">
		<!-- 상세게시판 -->
		<div class="board-wrap">
			<!-- 상세그룹 (공지 : type-notice, 약관 : type-term)-->
			<div class="board-view-wrap in-sec">
				<div class="board-view">
					<div class="board-header">
						<div class="tit-wrap">
							<!-- <h3 class="tit-h3"><em class="label-type1" role="text">공지</em> '채널 플러스' 채널 변경 안내</h3> -->
							<h3 class="tit-h3">{{ titleName }}</h3>
						</div>
						<div class="txt-wrap">
							<dl class="define-writer">
								<dt class="tit tit-writer" role="text">{{ $t('sdp.support.message.creater') }}</dt>
								<dd class="txt txt-writer">{{ writer }}</dd>
							</dl>
							<dl class="define-date">
								<dt class="tit tit-date" role="text">{{ $t('sdp.support.message.cdate') }}</dt>
								<dd class="txt txt-date">{{ cDate }}</dd>
							</dl>
						</div>
					</div>
					<div class="board-body">
						<div class="data-content" role="text" v-html="content"></div>
					</div>
					<div class="board-footer">
						<!-- 페이저 -->
						<div class="board-pager">
							<table>
								<caption>
									<div class="blind-area" role="text">
										<strong>{{ $t('gwa.alt.common.wa_caption_2') }}</strong>
										<p>{{ $t('gwa.alt.common.wa_summary_2') }}</p>
									</div>
								</caption>
								<tbody>
									<tr v-show="nextSeqNo != 0">
										<th id="boardPrev"><span class="tit">{{ $t('sdp.support.message.pre') }}<i class="arw arw-pager-prev centered-r" aria-hidden="true"></i></span></th>
										<td headers="boardPrev">
											<a @click="retreiveNoticeInfo(nextSeqNo)" href="javascript:;" class="link-wrap" :title="$t('gwa.alt.common.wa_title_6')">
												<span class="link-text">{{ nextTitleName }}</span>
											</a>
										</td>
									</tr>
									<tr v-show="prevSeqNo != 0">
										<th id="boardNext"><span class="tit">{{ $t('sdp.support.message.next') }}<i class="arw arw-pager-next centered-r" aria-hidden="true"></i></span></th>
										<td headers="boardNext">
											<a @click="retreiveNoticeInfo(prevSeqNo)" href="javascript:;" class="link-wrap" :title="$t('gwa.alt.common.wa_title_6')">
												<span class="link-text">{{ prevTitleName }}</span>
											</a>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
						<!-- //페이저 -->
					</div>
				</div>

				<!-- 버튼 -->
				<div class="btn-wrap in-sec">
					<a href="javascript:;" @click="goNoticeList()" class="btn btn-type1" role="button" :aria-label="$t('sdp.menu.notice') + ' '+ $t('sdp.support.message.listview')"><span>{{ $t('sdp.support.message.listview') }}</span></a>
				</div>
				<!-- //버튼 -->
			</div>
			<!-- //상세그룹 -->
		</div>
		<!-- //상세게시판 -->
	</div>
	<!-- //content Body -->
	</section>
	<!-- //content -->
</template>

<script>

import qs from "qs";

export default {
  name: "notice-detail",
  data() {
    return {
		prevSeqNo: 0,
		prevTitleName: '',
		nextSeqNo: 0,
		nextTitleName: '',
		titleName: '',
		content: '',
		writer: '',
		cDate: '',
		seqNo: 0,
		keyword: '',
		curPage: 1
	}
  },
  created() {
  },
  watch: {
    $route: "fetchData"
  },
  computed: {
  },
  methods: {
	  track () {
			console.log('@@@@ track:', this.$router.currentRoute.path);
			this.$ga.page(this.$router.currentRoute.path)
		},
	  _setResult(result) {
		  var info = result.data.noticeInfo[0];

		  console.log(info);
		  
		  this.content = info.cntt;
		  this.cDate = info.cDate;
		  this.nextSeqNo = info.nextSeq == null ? 0 : info.nextSeq;
		  this.nextTitleName = info.nextTitleName;
		  this.prevSeqNo = info.preSeq == null ? 0 : info.preSeq;
		  this.prevTitleName = info.preTitleName;
		  this.seqNo = info.seqNo;
		  this.writer = this.$t('sdp.support.message.admin');
		  this.titleName = info.titleName;
	  },
	  retreiveNoticeInfo(seqNo) {
		const vm = this;
		$(window).scrollTop(0);

		const params = {
			seqNo: seqNo,
			keyword: this.keyword
		};
		this.$axios.post("/api/notice/noticeInfo.ajax",
			qs.stringify(params)).then((result) => {
			vm.$nextTick(function() {
				vm._setResult(result);
				ui.init();
			})
		}).catch((err) => {
			alert("error");
		});
	  },
	  goNoticeList() {
          const r = { path : `/main/notice?keyword=${this.keyword}&curPage=${this.curPage}&detailYn=Y`};
          this.$router.push(r);
	  }
  },
  mounted() {
	
	this.seqNo = this.$route.query.seqNo;
	this.keyword = this.$route.query.keyword;
	this.curPage = this.$route.query.curPage;

	const vm = this;
    $(window).scrollTop(0);

	const params = {
		seqNo: this.seqNo,
		keyword: this.keyword
	};
	this.$axios.post("/api/notice/noticeInfo.ajax",
		qs.stringify(params)).then((result) => {
		vm.$nextTick(function() {
			vm._setResult(result);
			ui.init();
		})
	}).catch((err) => {
		alert("error");
	});
  }

};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
