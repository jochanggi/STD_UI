<template>
<!-- 목록게시판 -->
<div class="board-wrap in-sec">
	<!-- 검색영역 -->
	<div class="search-board-wrap">
		<div class="search-board" role="search">
			<fieldset>
				<legend id="searchBoardLegend">{{ $t('sdp.support.message.noticeSearch') }}</legend>
				<div class="search-form">
					<input v-model="keyword" @keydown="checkTextLength($event);" type="text" name="sSearchBoard" id="sSearchBoard" placeholder="" class="search-check" :title="$t('gwa.alt.common.wa_title_5')" v-on:keyup.13="checkSearchTime()"/>
					<transition name="fade" v-on:after-leave="afterLeave">
						<button type="button" @click="deleteKeyword()" class="btn-ico search-delete centered-r" v-show="keyword != null && keyword != ''"><span><i class="ico ico-del2">{{ $t('gwa.alt.notice.wa_alt_1') }}</i></span></button>
					</transition>
					<button @click="checkSearchTime()" type="button" class="btn-ico btn-search centered-r"><span><i class="ico ico-search2">{{ $t('gwa.alt.common.wa_label_5') }}</i></span></button>
				</div>
			</fieldset>
		</div>
	</div>
	<!-- //검색영역 -->
	<!-- 목록그룹 (공지 :, 약관 : type-term)-->
	<div class="section-body" v-if="loadingYn == 'Y'">
		<div class="loading-wrap">
			<div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
		</div>
	</div>
	<div class="board-list-wrap" v-else>
		<div class="board-list">
			<table>
				<caption>
					<div class="blind-area" role="text">
						<strong>{{ $t('gwa.alt.common.wa_caption_1') }}</strong>
						<p>{{ $t('gwa.alt.common.wa_summary_1') }}</p>
					</div>
				</caption>
				<thead>
					<tr>
						<th id="boardListNo">{{ $t('sdp.support.message.num') }}</th>
						<th id="boardListSubject">{{ $t('sdp.support.message.subject') }}</th>
						<th id="boardListDate">{{ $t('sdp.support.message.regdate') }}</th>
					</tr>
				</thead>
				<tbody>
					<!-- 등록게시물 -->
					<tr v-for="notice in noticeList">
						<td headers="boardListNo">{{ notice.rnum }}</td>
						<td headers="boardListSubject" class="align-l">
							<a @click="retrieveNoticeInfo(notice.seqNo)" href="javascript:;" class="link-wrap" :title="$t('gwa.alt.common.wa_title_33')">
								<span class="link-text">{{ notice.titleName }}</span>
								<!-- <em class="label-type3">NEW</em>
								<i class="arw arw-next2 centered-r" aria-hidden="true"></i> -->
							</a>
						</td>
						<td headers="boardListDate">{{ notice.cDate }}</td>
					</tr>
					<!-- //등록게시물 -->
					<!-- 미등록게시물 -->
					<tr v-show="noticeList.length == 0 && loadingYn == 'N'" class="tbl-noData-wrap">
						<td colspan="3" class="tbl-noData">{{ $t('sdp.support.message.nolist') }}</td>
					</tr>
					<!-- //미등록게시물 -->
				</tbody>
			</table>
		</div>
	</div>
	<!-- //목록그룹 -->
	<!-- 페이징 개발참고(선택된 현재페이지 번호)
			1. span태그로 변경
			2. aria-current="true"를 추가
			3. role="text"로 변경
	-->
	<div class="pagination-wrap" v-if="loadingYn == 'N'">
		<div class="pagination">
			<div class="btn-wrap">
				<a @click="goFirstPage()" href="javascript:;" class="btn-ico btn-page first" :class="paging.hasFirst == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-first">{{ $t('sdp.menu.notice') }} 처음 페이지</i></span></a>
				<a @click="goPrevPage()" href="javascript:;" class="btn-ico btn-page prev" :class="paging.hasPrev == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-prev">{{ $t('sdp.menu.notice') }} 이전 페이지</i></span></a>
			</div>
			<ul class="num-wrap">
				<li v-for="page in paging.pageList">
					<span v-show="page.num == paging.curPage" class="btn btn-num" aria-current="true" role="text" :aria-label="$t('sdp.menu.notice')+' '+page.num+' 페이지'"><span>{{ page.num }}</span></span>
					<a v-show="page.num != paging.curPage" @click="goPage(page.num)" href="javascript:;" class="btn btn-num" role="button" :aria-label="$t('sdp.menu.notice')+' '+page.num+' 페이지'"><span>{{ page.num }}</span></a>
				</li>
			</ul>
			<div class="btn-wrap">
				<a @click="goNextPage()" href="javascript:;" class="btn-ico btn-page next" :class="paging.hasNext == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-next">{{ $t('sdp.menu.notice') }} 다음 페이지</i></span></a>
				<a @click="goLastPage()" href="javascript:;" class="btn-ico btn-page last" :class="paging.hasLast == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-last">{{ $t('sdp.menu.notice') }} 마지막 페이지</i></span></a>
			</div>
		</div>
	</div>
	<!-- //페이징 -->
</div>
<!-- //목록게시판 -->
</template>

<script>
    import qs from "qs";

    export default {
		name: "notice-list",
        data() {
            return {
                keyword: '',
				maxLength: 256,
                noticeList : [],
				paging: {
					pageList: [],
					totalCount: 0,
					pageCount: 0,
					curPage: 1,
					hasNext: false,
					hasLast: false,
					hasPrev: false,
					hasFirst: false,
					curMaxPage: 0,
					curMinPage: 1,
					maxPage: 0
				},
				loadingYn : "Y"
            }
        },
		computed: {
           
		},
        watch: {
            /*   $route: "fetchData"*/
        },
        methods: {
			track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            retrieveNoticeInfo(seqNo) {
                const r = { path : `notice/detail?seqNo=${seqNo}&keyword=${this.keyword}&curPage=${this.paging.curPage}`};
                this.$router.push(r);
            },
            checkSearchTime() {
                const vm = this;
                this.$axios.post("/api/common/checkSearchTimeValidation.ajax").then((result) => {
                    if(result.data.timeErrorYn == "Y") {
                        alert("Please wait 1 seconds");
                    } else {
                        vm.searchNoticeList();
                    }
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            searchNoticeList() {
                console.log(this.paging);
				this.paging.curPage = 1;
				this.paging.totalCount = 0;
				this._retrieveNoticeListAjax();
            },
			goFirstPage() {
				console.log('goFirstPage');
				if(this.paging.curMinPage > 1) {
                    this.paging.curPage = this.paging.curMinPage - 1;
				}
                this._retrieveNoticeListAjax();
			},
			goPrevPage() {
				console.log('goPrevPage');
				if(this.paging.curPage > 1) {
                    this.paging.curPage -= 1;
				}
                this._retrieveNoticeListAjax();
			},
			goNextPage() {
				console.log('goNextPage');
				if(this.paging.curPage < this.paging.maxPage) {
                    this.paging.curPage += 1;
				}
                this._retrieveNoticeListAjax();
			},
			goLastPage() {
				console.log('goLastPage');
				if(this.paging.curMaxPage < this.paging.maxPage) {
                    this.paging.curPage = this.paging.curMaxPage + 1;
				}
                this._retrieveNoticeListAjax();
			},
			goPage(page) {
				this.paging.curPage = page;
                this._retrieveNoticeListAjax();
			},
            afterLeave: function (el) {
                this.$nextTick(function(){
                    $('#sSearchBoard').focus();
                });
            },
            deleteKeyword() {
				this.keyword = '';
				$('#sSearchBoard').focus();
            },
            checkTextLength (event) {
                var strValue = event.target.value;
                var strLength = this.getStrByte(event.target.value);

                if (strLength > this.maxLength) {
                    strValue = this.strCutByByte(strValue, this.maxLength);
                    strLength = this.getStrByte(strValue);
                    this.keyword = strValue;
                    return;
                }
            },
            strCutByByte (str, max) {
                var byteLength = 0;
                var result = "";

                for (var inx = 0; inx < str.length; inx++) {
                    var oneChar  = str.charAt(inx);
                    var charCode = oneChar.charCodeAt(0);
                    if(charCode)
                        if(charCode != 13){
                            if (charCode <= 0x00007F) {
                                byteLength ++;
                            }else if (charCode <= 0x0007FF) {
                                byteLength += 2;
                            }else if (charCode <= 0x00FFFF) {
                                byteLength += 3;
                            } else {
                                byteLength += 4;
                            }
                        }

                    if (byteLength > max) {
                        break;
                    }
                    result = result + str.charAt(inx);
                }

                return result;
            },
            getStrByte(value) {
                var byteLength = 0, ch;
                var charCode;
                var len = value.length;
                for(var i = 0; i < len; i++) {
                    ch = value.charAt(i);
                    charCode = ch.charCodeAt(0);
                    if(charCode)
                        if(charCode != 13){ // enter값이 2번 넘어온다.10,13 10번은 화면 test 시  나오지만 13번은 나오지 않아 13번을 막음.
                            if (charCode <= 0x00007F) {
                                byteLength ++;
                            }else if (charCode <= 0x0007FF) {
                                byteLength += 2;
                            }else if (charCode <= 0x00FFFF) {
                                byteLength += 3;
                            } else {
                                byteLength += 4;
                            }
                        }
                }
                return byteLength;
            },
            _setResult(result) {
				this.noticeList = result.data.noticeList;
				this.paging.totalCount = result.data.totalCount;
				this.paging.pageCount = result.data.pageCount;
				this.paging.curPage = result.data.curPage;
				this.paging.rowCount = result.data.rowCount;
			},
            _retrieveNoticeListAjax() {
			    this.loadingYn = 'Y';
                ui.loading.open();
				console.log('_retrieveNoticeListAjax');

                const vm = this;
                const params = {
					keyword: this.keyword,
					curPage: this.paging.curPage,
					rowCount: this.paging.rowCount,
					pageCount: this.paging.pageCount,
					totalCount: this.paging.totalCount
				};
				console.log('_retrieveNoticeListAjax', params);
                this.$axios.post('/api/notice/retrieveNoticeList.ajax', qs.stringify(params)).then((result) => {
                    ui.loading.close();
                    vm.loadingYn = "N";

					vm._setResult(result);
					vm._resetPageList();
                    vm.$nextTick(function() {
                        ui.init();
                        $("#sSearchBoard").blur();
					});
                }).catch((err) => {
                    alert('error ' + err);
                    this.loadingYn = "N";
                    ui.loading.close();
                });
			},
			_resetPageList() {

				var maxPage = Math.floor(this.paging.totalCount / this.paging.rowCount);
				if(this.paging.totalCount % this.paging.rowCount != 0) {
					maxPage += 1;
				}
				this.paging.maxPage = maxPage;

				this.paging.curMaxPage = Math.floor((this.paging.curPage - 1) / this.paging.pageCount) * this.paging.pageCount + this.paging.pageCount;
				this.paging.curMinPage = Math.floor((this.paging.curPage - 1) / this.paging.pageCount) * this.paging.pageCount + 1;

				console.log('curPage ', this.paging.curPage);
				console.log('curMaxPage ', this.paging.curMaxPage);
				console.log('curMinPage ', this.paging.curMinPage);
				
				this.paging.pageList = [];
				for(var i = this.paging.curMinPage; i <= this.paging.curMaxPage; ++i) {
					if(maxPage < i) {
						break;
					}
					this.paging.pageList.push({
						num: i
					})
				}

				if(maxPage <= this.paging.curMaxPage) {
					this.paging.hasLast = false;
				} else {
					this.paging.hasLast = true;
				}

				if(this.paging.curPage < maxPage) {
					this.paging.hasNext = true;
				} else {
					this.paging.hasNext = false;
				}

				if(this.paging.curPage != 1) {
					this.paging.hasPrev = true;
				} else {
					this.paging.hasPrev = false;
				}

				if(this.paging.curMinPage != 1) {
					this.paging.hasFirst = true;
				} else {
					this.paging.hasFirst = false;
				}

				console.log(this.paging);
			}
        },

        mounted() {

		    ui.loading.open();
			console.log("keyword ", this.keyword);
			// window.addEventListener('resize', this.handleWindowResize);
            $(window).scrollTop(0);

			var clientWidth = document.documentElement.clientWidth;
			console.log('clientWidth ', clientWidth);

			var pageCount = 10;
			var rowCount = 10;
			if(clientWidth < 760) {
				rowCount = 3;
				pageCount = 3;
			}

			const vm = this;

            var curPage = 1;
            if(vm.$route.query.detailYn != null && vm.$route.query.detailYn != "") {
                vm.keyword = vm.$route.query.keyword;
                curPage = vm.$route.query.curPage;
			}

			const params = {
				keyword: vm.keyword,
				curPage: curPage,
				rowCount: rowCount,
				pageCount: pageCount,
				totalCount: 0,
			};
            this.$axios.post('/api/notice/retrieveNoticeList.ajax', qs.stringify(params)).then((result) => {
                ui.loading.close();
                vm.loadingYn = "N";

                vm._setResult(result);
                vm._resetPageList();
                vm.$nextTick(function () {
                    ui.init();
                });
            }).catch((err) => {
                alert('error ' + err);

                this.loadingYn = "N";
                ui.loading.close();
            })
        }
    }

</script>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
