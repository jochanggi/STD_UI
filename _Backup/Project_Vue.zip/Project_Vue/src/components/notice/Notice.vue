<template>
	<!-- content -->
	<section id="content" class="content notice-cont">
		<!-- content Header -->
		<div class="content-header sub-visual">
			<div class="sub-visual-bg"></div>
			<div class="in-sec">
				<div class="tit-wrap centered-c">
					<h2 class="tit-h2">{{ $t('sdp.menu.notice') }}</h2>
					<p class="explain-h2">{{ $t('sdp.notic.message.title') }}</p>
				</div>
			</div>
		</div>
		<!-- //content Header -->

		<!-- content Body -->
		<div class="content-body">
			<!-- 목록게시판 -->
			<NoticeListView ref="noticeList"></NoticeListView>
			<!-- //목록게시판 -->
		</div>
		<!-- //content Body -->
	</section>
	<!-- //content -->
</template>

<script>

	import qs from "qs";
	
	import NoticeListView from '@/components/notice/NoticeListView';


    export default {
		name: "SearchResult",
		components: {
			NoticeListView
		},
        data() {
            return {
                keyword: '',
            }
        },
		computed: {
           
		},
        watch: {
            /*   $route: "fetchData"*/
        },
        methods: {
			track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
        },

        mounted() {
		    this.$nextTick(function() {
            	ui.searchAll.close('searchAll');
        	});
        }
    }

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
