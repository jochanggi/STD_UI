<template>
<div>
    <!-- {{ cntryGroupList }} -->
    <button @click="changeLang('chit')">chit</button> <br/>
    <button @click="changeLang('cmn')">cmn</button> <br/>
    <button @click="changeLang('engu')">engu</button> <br/>
    <button @click="changeLang('fre')">fre</button> <br/>
    <button @click="changeLang('ger')">ger</button> <br/>
    <button @click="changeLang('ind')">ind</button> <br/>
    <button @click="changeLang('ita')">ita</button> <br/>
    <button @click="changeLang('jpn')">jpn</button> <br/>
    <button @click="changeLang('kor')">kor</button> <br/>
    <button @click="changeLang('por')">por</button> <br/>
    <button @click="changeLang('rus')">rus</button> <br/>
    <button @click="changeLang('spa')">spa</button> <br/>
    <button @click="changeLang('tha')">tha</button> <br/>
    <button @click="changeLang('tur')">tur</button> <br/>
    <button @click="changeLang('ukr')">ukr</button> <br/>
    <button @click="changeLang('vie')">vie</button> <br/>
</div>
    <!-- <div style="width: 1200px; margin: 0 auto">
        <h3>cntryGroupList</h3>
        <table border="1">
            <thead>
                <tr>
                    <th>Biz Area Code</th>
                    <th>Biz Area</th>
                    <th>IMG</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="item in cntryGroupList">
                    <td>{{ item.bizAreaCode }}</td>
                    <td>{{ item.bizArea }}</td>
                    <td>{{ item.img }}</td>
                </tr>
            </tbody>
        </table>
        <br>
        <h3>cntryList</h3>
        <table border="1">
            <thead>
                <tr>
                    <th>Biz Area Code</th>
                    <th>Biz Area</th>
                    <th>Cntry Code</th>
                    <th>Cntry Name</th>
                    <th>Java Locale Name</th>
                    <th>DP Cntry Lang Name</th>
                    <th>Nflg Act Img Pth Name</th>
                    <th>Cntry Lnk Url</th>
                    <th>Excpt Flag</th>
                    <th>PCMall Open Flag</th>
                    <th>Msg Lang</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="item in cntryList" style="cursor: pointer"
                    @click="goMain(item.javaLocaleName, item.cntryCode)">
                    <td>{{ item.bizAreaCode }}</td>
                    <td>{{ item.bizArea }}</td>
                    <td>{{ item.cntryCode }}</td>
                    <td>{{ item.cntryName }}</td>
                    <td>{{ item.javaLocaleName }}</td>
                    <td>{{ item.dpCntryLangName }}</td>
                    <td>{{ item.nflgActImgPthName }}</td>
                    <td>{{ item.cntryLnkUrl }}</td>
                    <td>{{ item.excptFlag }}</td>
                    <td>{{ item.pcmallOpenFlag }}</td>
                    <td>{{ item.msgLang }}</td>
                </tr>
            </tbody>
        </table>
        <br>
        <p>Flag Url : {{ flagUrl }}</p>
        <p>gftsUrl : {{ gftsurl }}</p>
        <p>cookieValueYn : {{ cookieValueYn }}</p>
        <button type="button" class="btn btn-primary" @click="goHome()">홈으로</button> <br><br>
        <input type="checkbox" name="rememberYn" id="rememberYn" @click="rememberChoice()">
        <p>mainUrl : {{ mainUrl }}</p>
    </div> -->
</template>

<script>
    import qs from "qs";

    export default {
        name: "retrieveNation",
        data() {
            return {
                cntryGroupList: [],
                cntryList: [],
                flagUrl: "",
                gftsurl: "",
                cookieValueYn: "N",
                mainUrl: ""
            }
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            changeLang(langCode) {
                this.$i18n.locale = langCode;
            },
            goHome() {
                const r = { path : "/main" };
                this.$router.push(r);
            },
            goMain(locale, cntryCode) {
                const vm = this;
                const params = {
                    locale : locale,
                    cntryCode : cntryCode
                };

                this.setCookie("user.cookie.javaLocale", locale);
                if(this.cookieValueYn == "Y") {
                    this.setCookie("user.cookie.rememberCntry", locale);
                }

                this.$axios.post("/api/common/retrieveNationUrl.ajax",
                    qs.stringify(params)).then((result) => {
                    window.location = result.data.mainUrl;
                    // vm.mainUrl = result.data.mainUrl;
                    // const r = { path : vm.mainUrl };
                    // this.$router.push(r);
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            rememberChoice() {
                if(this.cookieValueYn == "Y") {
                    this.cookieValueYn = "N";
                    this.setCookie("user.cookie.rememberYn", "");
                    this.setCookie("user.cookie.rememberCntry", "");
                } else {
                    this.cookieValueYn = "Y";
                    this.setCookie("user.cookie.rememberYn", "Y");
                }
            },
            setCookie(name, value) {
                const vm = this;

                var expires = "5000";

                const params = {
                    name : name,
                    value : escape(value),
                    url: window.location.hostname,
                    expires: expires
                };

                this.$axios.post("/api/common/setNationCookie.ajax",
                    qs.stringify(params)).then((result) => {
                    // do nothing
                }).catch((err) => {
                    alert("error : " + err);
                });
            }
        },
        computed: {

        },
        mounted() {
            const vm = this;
            this.$axios.post("/api/common/retrieveNation.ajax").then((result) => {
                vm.cntryGroupList = result.data.cntryGroupList;
                vm.cntryList = result.data.cntryList;
                vm.flagUrl = result.data.flagUrl;
                vm.gftsurl = result.data.gftsurl;
            }).catch((err) => {
                alert("error : " + err);
            });

            /*axios.get("https://ipinfo.io").then((result) => {
                var ip = result.data.ip;
                var hostname = result.data.hostname;
                var city = result.data.city;
                var region = result.data.region;
                var country = result.data.country;
                var loc = result.data.loc;
                var org = result.data.org;

                if(country == "KR") {
                    alert("한국에서 접속하셨습니다.");
                } else {
                    alert("한국에서 접속하지 않으셨습니다.");
                }

                console.log("ip : " + ip);
                console.log("hostname : " + hostname);
                console.log("city : " + city);
                console.log("region : " + region);
                console.log("country : " + country);
                console.log("loc : " + loc);
                console.log("org : " + org);
            }).catch((err) => {
                alert("ip error");
            });*/
        }
    }
</script>

<style scoped>

</style>