<template>
    <!-- content -->
    <div class="commPage">
        <div class="commPageLogo"><img src="/img/cmn/compage_logo02.gif" alt="LG"></div>
        <div class="commPageBoxAlert">
            <div class="text">The page cannot be found</div>
        </div>
        <div class="commPageMe">
            <div class="commPageMeTit02">The page you are looking for might have been removed, had its name changed, or is temporarily unavailable</div>
        </div>
    </div>
    <!-- //content -->
</template>

<script>
export default {
  name: "NotFound",
  data() {
    return {}
  },
  created() {
  },
  watch: {
    $route: "fetchData"
  },
  computed: {
  },
  methods: {
    track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
