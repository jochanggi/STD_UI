<template>
<div id="wrapper" class="global-wrapper">
	<!-- SkipNav -->
	<div id="skipNav">
		<ul>
			<li><a href="#content">본문 바로가기</a></li>
		</ul>
	</div>
	<!-- //SkipNav -->

	<!-- Header -->
	<header id="header" class="out-sec">
		<div class="in-sec">
			<!-- 로고 -->
			<div class="logo-wrap">
				<span class="logo" role="text" :aria-label="$t('gwa.alt.nation.wa_label_1')"></span>
			</div>
			<!-- //로고 -->
		</div>
	</header>
	<!-- //Header -->

    <!-- Content -->
    <section id="content" class="content global-cont">
        <!-- Content Header -->
        <div class="content-header sub-header">
            <div class="in-sec">
                <div class="tit-wrap">
                    <h2 class="tit-h2">Select Your Region</h2>
                </div>
            </div>
        </div>
        <!-- //Content Header -->

        <!-- Content Body -->
        <div class="section-body" v-if="loadingYn == 'Y'">
            <div class="loading-wrap">
                <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
            </div>
        </div>
        <div class="content-body" v-else>
            <div class="accordion-wrap global-accordion in-sec">
                <div class="accordion">
                    <!-- 국가 리스트 -->
                    <!-- ASIA_PACIFIC -->
                    <div class="accordion-title is-active">
                        <a href="#globalAccorCont1" id="globalAccorTitle1" class="accordion-toggle" role="button" aria-controls="globalAccorCont1" aria-expanded="true">
                            <span class="accordion-tit">ASIA &amp; PACIFIC</span>
                            <i class="arw arw-toggle"></i>
                        </a>
                    </div>
                    <div id="globalAccorCont1" class="accordion-content is-active" aria-labelledby="globalAccorTitle1" aria-hidden="false">
                        <div class="country-content">
                            <ul>
                                <li v-for="cntry in cntryList" v-show="cntry.bizAreaCode == 'AP'">
                                    <a @click="goMain(cntry.javaLocaleName, cntry.cntryCode, cntry.langCode)" href="javascript:;">
                                        <img aria-hidden="true" :src="cntry.nflgActImgPthName" :alt="cntry.cntryName"><span class="country-name" role="text" :aria-label="$t('gwa.alt.common.wa_label_1', { var1 : cntry.cntryName })">{{ cntry.cntryName }}</span><span class="country-language" role="text" :aria-label="' '+$t('gwa.alt.nation.wa_label_2', { var1 : cntry.dpCntryLangName })" :lang="cntry.langIsoCode">{{ cntry.dpCntryLangName }}</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- //ASIA_PACIFIC -->
                    <!-- CIS -->
                    <div class="accordion-title">
                        <a href="#globalAccorCont2" id="globalAccorTitle2" class="accordion-toggle" role="button" aria-controls="globalAccorCont2" aria-expanded="false">
                            <span class="accordion-tit">CIS</span>
                            <i class="arw arw-toggle"></i>
                        </a>
                    </div>
                    <div id="globalAccorCont2" class="accordion-content" aria-labelledby="globalAccorTitle2" aria-hidden="true">
                        <div class="country-content">
                            <ul>
                                <li v-for="cntry in cntryList" v-show="cntry.bizAreaCode == 'CS'">
                                    <a @click="goMain(cntry.javaLocaleName, cntry.cntryCode, cntry.langCode)" href="javascript:;">
                                        <img aria-hidden="true" :src="cntry.nflgActImgPthName" :alt="cntry.cntryName"><span class="country-name" role="text" :aria-label="$t('gwa.alt.common.wa_label_1', { var1 : cntry.cntryName })">{{ cntry.cntryName }}</span><span class="country-language" role="text" :aria-label="' '+$t('gwa.alt.nation.wa_label_2', { var1 : cntry.dpCntryLangName })" :lang="cntry.langIsoCode">{{ cntry.dpCntryLangName }}</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- //CIS -->
                    <!-- EUROPE -->
                    <div class="accordion-title">
                        <a href="#globalAccorCont3" id="globalAccorTitle3" class="accordion-toggle" role="button" aria-controls="globalAccorCont3" aria-expanded="false">
                            <span class="accordion-tit">EUROPE</span>
                            <i class="arw arw-toggle"></i>
                        </a>
                    </div>
                    <div id="globalAccorCont3" class="accordion-content" aria-labelledby="globalAccorTitle3" aria-hidden="true">
                        <div class="country-content">
                            <ul>
                                <li v-for="cntry in cntryList" v-show="cntry.bizAreaCode == 'EU'">
                                    <a @click="goMain(cntry.javaLocaleName, cntry.cntryCode, cntry.langCode)" href="javascript:;">
                                        <img aria-hidden="true" :src="cntry.nflgActImgPthName" :alt="cntry.cntryName"><span class="country-name" role="text" :aria-label="$t('gwa.alt.common.wa_label_1', { var1 : cntry.cntryName })">{{ cntry.cntryName }}</span><span class="country-language" role="text" :aria-label="' '+$t('gwa.alt.nation.wa_label_2', { var1 : cntry.dpCntryLangName })" :lang="cntry.langIsoCode">{{ cntry.dpCntryLangName }}</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- //EUROPE -->
                    <!-- MIDDLE EAST AFRICA -->
                    <div class="accordion-title">
                        <a href="#globalAccorCont4" id="globalAccorTitle4" class="accordion-toggle" role="button" aria-controls="globalAccorCont4" aria-expanded="false">
                            <span class="accordion-tit">MIDDLE EAST &amp; AFRICA</span>
                            <i class="arw arw-toggle"></i>
                        </a>
                    </div>
                    <div id="globalAccorCont4" class="accordion-content" aria-labelledby="globalAccorTitle4" aria-hidden="true">
                        <div class="country-content">
                            <ul>
                                <li v-for="cntry in cntryList" v-show="cntry.bizAreaCode == 'MA'">
                                    <a @click="goMain(cntry.javaLocaleName, cntry.cntryCode, cntry.langCode)" href="javascript:;">
                                        <img aria-hidden="true" :src="cntry.nflgActImgPthName" :alt="cntry.cntryName"><span class="country-name" role="text" :aria-label="$t('gwa.alt.common.wa_label_1', { var1 : cntry.cntryName })">{{ cntry.cntryName }}</span><span class="country-language" role="text" :aria-label="' '+$t('gwa.alt.nation.wa_label_2', { var1 : cntry.dpCntryLangName })" :lang="cntry.langIsoCode">{{ cntry.dpCntryLangName }}</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- //MIDDLE EAST AFRICA -->
                    <!-- NORTH AMERICA -->
                    <div class="accordion-title">
                        <a href="#globalAccorCont5" id="globalAccorTitle5" class="accordion-toggle" role="button" aria-controls="globalAccorCont5" aria-expanded="false">
                            <span class="accordion-tit">NORTH AMERICA</span>
                            <i class="arw arw-toggle"></i>
                        </a>
                    </div>
                    <div id="globalAccorCont5" class="accordion-content" aria-labelledby="globalAccorTitle5" aria-hidden="true">
                        <div class="country-content">
                            <ul>
                                <li v-for="cntry in cntryList" v-show="cntry.bizAreaCode == 'NA'">
                                    <a @click="goMain(cntry.javaLocaleName, cntry.cntryCode, cntry.langCode)" href="javascript:;">
                                        <img aria-hidden="true" :src="cntry.nflgActImgPthName" :alt="cntry.cntryName"><span class="country-name" role="text" :aria-label="$t('gwa.alt.common.wa_label_1', { var1 : cntry.cntryName })">{{ cntry.cntryName }}</span><span class="country-language" role="text" :aria-label="' '+$t('gwa.alt.nation.wa_label_2', { var1 : cntry.dpCntryLangName })" :lang="cntry.langIsoCode">{{ cntry.dpCntryLangName }}</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- //NORTH AMERICA -->
                    <!-- MIDDLE SOUTH AMERICA -->
                    <div class="accordion-title">
                        <a href="#globalAccorCont7" id="globalAccorTitle7" class="accordion-toggle" role="button" aria-controls="globalAccorCont7" aria-expanded="false">
                            <span class="accordion-tit">MIDDLE/SOUTH AMERICA</span>
                            <i class="arw arw-toggle"></i>
                        </a>
                    </div>
                    <div id="globalAccorCont7" class="accordion-content" aria-labelledby="globalAccorTitle7" aria-hidden="true">
                        <div class="country-content">
                            <ul>
                                <li v-for="cntry in cntryList" v-show="cntry.bizAreaCode == 'SA'">
                                    <a @click="goMain(cntry.javaLocaleName, cntry.cntryCode, cntry.langCode)" href="javascript:;">
                                        <img aria-hidden="true" :src="cntry.nflgActImgPthName" :alt="cntry.cntryName"><span class="country-name" role="text" :aria-label="$t('gwa.alt.common.wa_label_1', { var1 : cntry.cntryName })">{{ cntry.cntryName }}</span><span class="country-language" role="text" :aria-label="' '+$t('gwa.alt.nation.wa_label_2', { var1 : cntry.dpCntryLangName })" :lang="cntry.langIsoCode">{{ cntry.dpCntryLangName }}</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- //SOUTH AMERICA -->

                    <!--<template v-for="(item, index) in cntryGroupList">
                        <div @click="setCntryGroupIdx(index)" class="accordion-title" :class="isTabActive(index)">
                            <a :href="'#globalAccorCont'+(index+1)" :id="'globalAccorTitle'+(index+1)" class="accordion-toggle" role="button" :aria-controls="'globalAccorCont'+(index+1)" :aria-expanded="isAriaExpanded(index)">
                                <span class="accordion-tit">{{ item.bizArea }}</span>
                                <i class="arw arw-toggle"></i>
                            </a>
                        </div>
                        <div :id="'#globalAccorCont'+(index+1)" class="accordion-content" :class="isTabActive(index)" :aria-labelledby="'globalAccorTitle'+(index+1)" :aria-hidden="isAriaHidden(index)">
                            <div class="country-content">
                                <ul>
                                    <li v-for="cntry in cntryList" v-show="cntry.bizAreaCode == item.bizAreaCode">
                                        <a @click="goMain(cntry.javaLocaleName, cntry.cntryCode, cntry.langCode)" href="javascript:;">
                                            <img aria-hidden="true" :src="cntry.nflgActImgPthName" :alt="cntry.cntryName"><span class="country-name" role="text" :aria-label="'국가명 : '+cntry.cntryName">{{ cntry.cntryName }}</span><span class="country-language" role="text" :aria-label="'언어 : '+cntry.dpCntryLangName">{{ cntry.dpCntryLangName }}</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </template>-->
                    <!-- //국가 리스트 -->
                </div>
            </div>
        </div>
        <!-- //Content Body -->
    </section>
    <!-- //Content -->
</div>
</template>

<script>
    import qs from "qs";

    export default {
        name: "Nation",
        data() {
            return {
                cntryGroupList: [],
                cntryList: [],
                flagUrl: "",
                gftsurl: "",
                // cookieValueYn: "N",
                mainUrl: "",
                loadingYn: "Y"
                // cntryGroupIdx: 0
            }
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            changeLang(langCode) {
                this.$i18n.locale = langCode;
            },
            goMain(locale, cntryCode, langCode) {
                const vm = this;
                const params = {
                    locale : locale,
                    cntryCode : cntryCode
                };

                vm.changeLang(langCode);

                /*this.setCookie("user.cookie.javaLocale", locale);
                if(this.cookieValueYn == "Y") {
                    this.setCookie("user.cookie.rememberCntry", locale);
                }*/

                this.$axios.post("/api/common/retrieveNationUrl.ajax",
                    qs.stringify(params)).then((result) => {
                    window.location = result.data.mainUrl;
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            /*rememberChoice() {
                if(this.cookieValueYn == "Y") {
                    this.cookieValueYn = "N";
                    this.setCookie("user.cookie.rememberYn", "");
                    this.setCookie("user.cookie.rememberCntry", "");
                } else {
                    this.cookieValueYn = "Y";
                    this.setCookie("user.cookie.rememberYn", "Y");
                }
            },*/
            /*setCookie(name, value) {
                const vm = this;

                var expires = "5000";

                const params = {
                    name : name,
                    value : escape(value),
                    url: window.location.hostname,
                    expires: expires
                };

                this.$axios.post("/api/common/setNationCookie.ajax",
                    qs.stringify(params)).then((result) => {
                    // do nothing
                }).catch((err) => {
                    alert("error : " + err);
                });
            },*/
            /*setCntryGroupIdx(index) {
                this.cntryGroupIdx = index;
            },
            isTabActive(index) {
                if(this.cntryGroupIdx == index) {
                    return "is-active";
                } else {
                    return "";
                }
            },
            isAriaExpanded(index) {
                if(this.cntryGroupIdx == index) {
                    return true;
                } else {
                    return false;
                }
            },
            isAriaHidden(index) {
                if(this.cntryGroupIdx == index) {
                    return false;
                } else {
                    return true;
                }
            }*/
        },
        computed: {

        },
        mounted() {
            ui.loading.open();

            const vm = this;

            this.$axios.post("/api/common/retrieveNation.ajax").then((result) => {
                ui.loading.close();

                vm.cntryGroupList = result.data.cntryGroupList;
                vm.cntryList = result.data.cntryList;
                vm.flagUrl = result.data.flagUrl;
                vm.gftsurl = result.data.gftsurl;
                vm.loadingYn = "N";

                vm.$nextTick(function() {
                    ui.init();
                });
            }).catch((err) => {
                ui.loading.close();
                vm.loadingYn = "N";
                alert("error : " + err);
            });
        }
    }
</script>

<style scoped>

</style>