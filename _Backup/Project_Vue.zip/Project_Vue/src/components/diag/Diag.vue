<template>
	<!-- content -->
	<section id="content" class="content selftest-cont">
		<!-- content Header -->
		<div class="content-header sub-visual">
            <div class="sub-visual-bg"></div>
			<div class="in-sec">
				<div class="tit-wrap centered-c">
					<h2 class="tit-h2">{{ $t('sdp.menu.gnb.self') }}</h2>
					<p class="explain-h2">{{ $t('sdp.self.message.title1') }}</p>
				</div>
			</div>
		</div>
		<!-- //content Header -->
		<!-- content Body -->
		<div class="content-body">
			<!-- 검색전체영역 -->
			<div class="search-page-wrap in-sec" role="search">
				<!-- 검색영역 -->
				<fieldset class="search-page">
					<legend id="searchLegend">{{ $t("gwa.alt.common.wa_label_20") }}</legend>
					<!-- 검색입력 -->
					<div class="search-form">
						<input type="text" v-model="schTxt" @keydown="checkTextLength($event);" name="ssearchPage" id="sSearchPage" :placeholder="$t('sdp.search.message.text_box')" @keyup.enter="checkSearchTime('')" :title="$t('gwa.alt.common.wa_title_25')" />
						<transition name="fade" v-on:after-leave="afterLeave">
							<button type="button" @click="deleteKeyword()" class="btn-ico search-delete centered-r" v-show="schTxt != null && schTxt != ''"><span><i class="ico ico-del2">{{ $t('gwa.alt.common.wa_label_59') }}</i></span></button>
						</transition>
						<button type="submit" class="btn btn-search centered-r" @click="checkSearchTime('')"><span><i class="ico ico-search2 centered-c">{{ $t('gwa.alt.common.wa_label_20') }}</i></span></button>
					</div>
					<!-- //검색입력 -->
					<!-- 추천검색어 -->
                    <!-- 고도화 ver2 : 속성 aria-label 검색 추가 -->
					<div class="keyword-wrap" data-state="closed">
						<h3 class="keyword-tit">{{ $t('sdp.search.message.recommend') }}</h3>
						<div class="keyword">
							<div id="foldKeywordPage" class="folder-keyword folder-content type-page" data-name="foldKeywordPage">
								<div class="folder-inner">
									<p v-for="item in keywordList"><a href="javascript:;" @click="checkSearchTime(item.keywrd)" :aria-label="item.keywrd+' '+$t('gwa.alt.main.sch')">{{ item.keywrd }}</a></p>
								</div>
							</div>
                            <div class="keyword-btn">
                                <button type="button" class="btn-ico folder-open is-active" tabindex="0" aria-controls="foldKeywordPage" aria-expanded="false" aria-hidden="false" data-role="more" data-target="foldKeywordPage"><span><i class="arw arw-toggle6">{{ $t('gwa.alt.common.wa_label_32') }}</i></span></button>
                                <button type="button" class="btn-ico folder-close" tabindex="-1" aria-controls="foldKeywordPage" aria-expanded="true" aria-hidden="true" data-role="more" data-target="foldKeywordPage"><span><i class="arw arw-toggle6">{{ $t('gwa.alt.common.wa_label_33') }}</i></span></button>
                            </div>
						</div>
					</div>
					<!-- //추천검색어 -->
				</fieldset>
				<!-- //검색영역 -->
			</div>
			<!-- //검색전체영역 -->

			<!-- 탭전체영역 -->
            <div class="tab-type1-wrap in-sec">
                <!-- 탭메뉴 -->
                <nav class="tab-nav tab-type1 tab-responsive">
                    <ul role="tablist">
                        <li role="presentation" :class="{'is-active' : isTabActive('')}" v-show="diagCateList.length > 0">
                            <a href="javascript:;" role="tab" aria-selected="true" @click="goAllSearch()">
                                <span class="tit">{{ firstTabName }}<em v-show="searchYn == 'Y'" class="label-type2">{{ totCnt }}</em></span>
                            </a>
                        </li>
                        <li v-for="item in diagCateList" role="presentation" :class="{'is-active' : isTabActive(item.catCode)}">
                            <a href="javascript:;" role="tab" aria-selected="false" @click="goTabSearch(item.catCode, item.catName)">
                                <span class="tit">{{ item.catName }}<em class="label-type2">{{ item.cnt }}</em></span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- //탭메뉴 -->
                <div class="tab-body">
                    <h3 class="blind dv-pc-only">{{ tabPanelName }}</h3>
                    <!-- 자가진단 전체영역 -->
                    <div class="loading-wrap" v-if="loadingYn == 'Y'">
                        <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                    </div>
                    <div class="selftest-lists-wrap" v-else-if="diagList.length > 0"><!-- hidden속성을 삭제해서 검색결과를 노출합니다. -->
                        <!-- 목록그룹 (대체텍스트 형식 : alt="[제목] + Thumbnail") -->
                        <div class="selftest-lists" data-type="image">
                            <ul>
                                <li v-for="item in diagList">
                                    <!--
                                    <div class="item-wrap">
                                        <p class="item-thumb thumbnail" @click="updateViewCnt(item.seqNo)">
                                            <template v-for="path in diagResourcePathList">
                                                <a v-if="path.seqNo == item.seqNo" href="javascript:;" class="more-focus" :title="$t('gwa.alt.common.wa_title_33')">
                                                <span role="img" :aria-label="$t('gwa.alt.diag.wa_label_4', { var1 : item.titleName })">
                                                    <img :src="path.resourcePth" :alt="$t('gwa.alt.diag.wa_label_4', { var1 : item.titleName })" />
                                                </span>
                                                </a>
                                            </template>
                                        </p>
                                        <p class="item-tit"><a href="javascript:;" @click="updateViewCnt(item.seqNo)"><strong role="text">{{ item.titleName }}</strong></a></p>
                                        <p class="item-date"><a href="javascript:;" @click="updateViewCnt(item.seqNo)">{{ item.crtDate }}</a></p>
                                    </div>
                                    -->
                                    <a href="javascript:;" class="item-wrap more-focus" @click="updateViewCnt(item.seqNo)" :title="$t('gwa.alt.common.wa_title_33')">
                                        <div role="text">
                                            <template v-for="path in diagResourcePathList">
                                                <p class="item-thumb thumbnail" v-if="path.seqNo == item.seqNo" aria-hidden="true">
                                                    <img :src="path.resourcePth" :alt="$t('gwa.alt.diag.wa_label_4', { var1 : item.titleName })" />
                                                </p>
                                            </template>
                                            <p class="item-tit"><strong>{{ item.titleName }}</strong></p>
                                            <p class="item-date">{{ item.crtDate }}</p>
                                        </div>
                                    </a>
                                    <!--<div class="item-tag">
                                        <template v-for="tag in diagHashTagList">
                                            <a v-show="tag.seqNo == item.seqNo" href="javascript:;" class="tag-type1" role="button" @click="goKeywordSearch(tag.hashTag)">
                                                #{{ tag.hashTag }}
                                            </a>
                                        </template>
                                    </div>-->
                                </li>
                            </ul>
                        </div>
                        <!-- //목록그룹 -->

                        <!-- 페이징 개발참고(선택된 현재페이지 번호)
                                1. span태그로 변경
                                2. aria-current="true"
                                3. role="text"로 변경
                        -->
                        <!-- 고도화 ver2 : 속성 페이지 정보 aria-label 수정 -->
                        <div class="pagination-wrap">
                            <div class="pagination">
                                <div class="btn-wrap">
                                    <a @click="goFirstPage()" href="javascript:;" class="btn-ico btn-page first" :class="paging.hasFirst == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-first">{{ $t('gwa.alt.common.wa_title_41') }}</i></span></a>
                                    <a @click="goPrevPage()" href="javascript:;" class="btn-ico btn-page prev" :class="paging.hasPrev == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-prev">{{ $t('gwa.alt.common.wa_title_42') }}</i></span></a>
                                </div>
                                <ul class="num-wrap">
                                    <li v-for="page in paging.pageList">
                                        <span v-show="page.num == paging.curPage" class="btn btn-num" :aria-label="$t('gwa.alt.common.wa_title_43', { var1 : page.num })" aria-current="true" role="text"><span>{{ page.num }}</span></span>
                                        <a v-show="page.num != paging.curPage" @click="goPage(page.num)" href="javascript:;" class="btn btn-num" :aria-label="$t('gwa.alt.common.wa_title_43', { var1 : page.num })" role="button"><span>{{ page.num }}</span></a>
                                    </li>
                                </ul>
                                <div class="btn-wrap">
                                    <a @click="goNextPage()" href="javascript:;" class="btn-ico btn-page next" :class="paging.hasNext == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-next">{{ $t('gwa.alt.common.wa_title_44') }}</i></span></a>
                                    <a @click="goLastPage()" href="javascript:;" class="btn-ico btn-page last" :class="paging.hasLast == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-last">{{ $t('gwa.alt.common.wa_title_45') }}</i></span></a>
                                </div>
                            </div>
                        </div>
                        <!-- //페이징 -->
                    </div>
                    <!-- //자가진단 전체영역 -->
                    <!-- 미등록게시물 -->
                    <div class="noData-wrap" v-else>
                        <div class="noData">
                            <div class="inner">
                                <p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
                            </div>
                        </div>
                    </div>
                    <!-- //미등록게시물 -->
                </div>
            </div>
			<!-- //탭전체영역 -->

			<!-- 관련정보 -->
			<div class="box-wrap box-relateMenu in-sec">
				<div class="box">
					<div class="box-header">
						<p class="para">{{ $t('sdp.self.message.title2') }}</p>
					</div>
					<div class="box-body">
						<div class="grid grid-divieder">
							<div class="col col-6">
								<router-link to="/main/inquiry" tag="a" class="relate-link">
									<span class="ico-area" aria-hidden="true"><i class="ico ico-ques"></i></span>
									<dl>
										<dt class="tit">{{ $t('sdp.menu.qna') }}</dt>
										<dd class="txt" v-html="$t('sdp.support.message.new.qna4')"></dd>
									</dl>
								</router-link>
							</div>
							<div class="col col-6">
								<router-link to="/main/faq" tag="a" class="relate-link">
									<span class="ico-area" aria-hidden="true"><i class="ico ico-faq"></i></span>
									<dl>
										<dt class="tit">{{ $t('sdp.menu.faq') }}</dt>
										<dd class="txt" v-html="$t('sdp.faq.message.title')"></dd>
									</dl>
								</router-link>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- //관련정보 -->

			<div id="popupTabSelect" class="popup-wrap popup-select" role="dialog">
				<div class="popup popup-tab">
					<nav class="tab-nav tab-type1 tab-responsive">
						<ul role="tablist">
							<li role="presentation" :class="{'is-active' : isTabActive('')}" v-show="diagCateList.length > 0">
								<a href="javascript:;" role="tab" aria-selected="true" @click="goAllSearch()">
									<span class="tit">{{ firstTabName }}<em v-show="searchYn == 'Y'" class="label-type2">{{ totCnt }}</em></span>
								</a>
							</li>
							<li v-for="item in diagCateList" role="presentation" :class="{'is-active' : isTabActive(item.catCode)}">
								<a href="javascript:;" role="tab" aria-selected="false" @click="goTabSearch(item.catCode)">
									<span class="tit">{{ item.catName }}<em class="label-type2">{{ item.cnt }}</em></span>
								</a>
							</li>
						</ul>
					</nav>
                    <button type="button" class="btn-ico btn-close-select" aria-controls="popupTabSelect"><span><i class="ico ico-close2">{{ $t('gwa.alt.common.wa_label_22') }}</i></span></button>
				</div>
			</div>
		</div>
		<!-- //content Body -->
	</section>
	<!-- //content -->
</template>

<script>
    import qs from "qs";

    export default {
        name: "Diag",
        data() {
            return {
                diagList: [],
                diagCateList: [],
                totCnt: 0,
                // diagHashTagList: [],
                diagResourcePathList: [],
                catCode1: "",
                searchYn: "N",
                allClickYn: "Y",
				loadingYn: "Y",
                seqNo: "",
                schTxt: "",
                maxLength: 256,
                keywordList: [],
                paging: {
                    pageList: [],
                    totalCount: 0,
                    pageCount: 0,
                    rowCount: 0,
                    curPage: 1,
                    hasNext: false,
                    hasLast: false,
                    hasPrev: false,
                    hasFirst: false,
                    curMaxPage: 0,
                    curMinPage: 1,
                    maxPage: 0
                },
				tabPanelName: ""
            }
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            checkSearchTime(keyword) {
                const vm = this;
                this.$axios.post("/api/common/checkSearchTimeValidation.ajax").then((result) => {
                    if(result.data.timeErrorYn == "Y") {
                        alert("Please wait 1 seconds");
                    } else {
                        if(keyword != "") {
                            vm.goKeywordSearch(keyword);
                        } else {
                            vm.goSearch();
                        }
                    }
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            goSearch() {
                const vm = this;
                vm.searchYn = "Y";
                vm.tabPanelName = vm.firstTabName;
                vm.paging.curPage = 1;
                vm.goSearchAjax();
            },
            goAllSearch() {
                const vm = this;
                vm.catCode1 = "";
                vm.tabPanelName = vm.firstTabName;
                vm.allClickYn = "Y";
                vm.paging.curPage = 1;
                vm.goSearchAjax();
            },
            goTabSearch(catCode1, catName) {
                const vm = this;
                vm.catCode1 = catCode1;
                vm.tabPanelName = catName;
                vm.allClickYn = "N";
                vm.paging.curPage = 1;
                vm.goSearchAjax();
            },
			goKeywordSearch(keyword) {
                const vm = this;
                vm.searchYn = "Y";
                vm.tabPanelName = vm.firstTabName;
                vm.schTxt = keyword;
                vm.paging.curPage = 1;
                $(window).scrollTop(0);
                vm.goSearchAjax();
            },
            goSearchAjax() {
                const vm = this;
                vm.loadingYn = "Y";
                ui.loading.open();

                if (vm.schTxt.left > 256) {
                    return;
				}

                const params = {
                    catCode1: vm.catCode1,
                    schTxt: vm.schTxt,
                    searchYn: vm.searchYn,
                    allClickYn: vm.allClickYn,
                    curPage: vm.paging.curPage,
                    rowCount: vm.paging.rowCount,
                    pageCount: vm.paging.pageCount,
                    totalCount: vm.paging.totalCount
                };

                this.$axios.post("/api/diag/retrieveDiagList.ajax",
                    qs.stringify(params)).then((result) => {
                    ui.loading.close();
                    vm.diagList = result.data.diagList;
                    vm.diagCateList = result.data.diagCateList;
                    vm.totCnt = result.data.totCnt;
                    // vm.diagHashTagList = result.data.diagHashTagList;
                    vm.diagResourcePathList = result.data.diagResourcePathList;
                    vm.loadingYn = "N";

                    vm.setResult(result);
                    vm.resetPageList();
                    vm.$nextTick(function() {
                        ui.tab.init();
                        $("#sSearchPage").blur();
                    });
                }).catch((err) => {
                    ui.loading.close();
                    vm.loadingYn = "N";
                    alert("error : " + err);
                });
            },
            goFirstPage() {
                if(this.paging.curMinPage > 1) {
                    this.paging.curPage = this.paging.curMinPage - 1;
                }
                this.goSearchAjax();
            },
            goPrevPage() {
                if(this.paging.curPage > 1) {
                    this.paging.curPage -= 1;
                }
                this.goSearchAjax();
            },
            goNextPage() {
                if(this.paging.curPage < this.paging.maxPage) {
                    this.paging.curPage += 1;
                }
                this.goSearchAjax();
            },
            goLastPage() {
                if(this.paging.curMaxPage < this.paging.maxPage) {
                    this.paging.curPage = this.paging.curMaxPage + 1;
                }
                this.goSearchAjax();
            },
            goPage(page) {
                this.paging.curPage = page;
                this.goSearchAjax();
            },
            setResult(result) {
                this.paging.totalCount = result.data.totalCount;
                this.paging.pageCount = result.data.pageCount;
                this.paging.curPage = result.data.curPage;
                this.paging.rowCount = result.data.rowCount;
            },
            resetPageList() {
                var maxPage = Math.floor(this.paging.totalCount / this.paging.rowCount);
                if(this.paging.totalCount % this.paging.rowCount != 0) {
                    maxPage += 1;
                }
                this.paging.maxPage = maxPage;

                this.paging.curMaxPage = Math.floor((this.paging.curPage - 1) / this.paging.pageCount) * this.paging.pageCount + this.paging.pageCount;
                this.paging.curMinPage = Math.floor((this.paging.curPage - 1) / this.paging.pageCount) * this.paging.pageCount + 1;

                this.paging.pageList = [];
                for(var i = this.paging.curMinPage; i <= this.paging.curMaxPage; ++i) {
                    if(maxPage < i) {
                        break;
                    }
                    this.paging.pageList.push({
                        num: i
                    });
                }

                if(maxPage <= this.paging.curMaxPage) {
                    this.paging.hasLast = false;
                } else {
                    this.paging.hasLast = true;
                }

                if(this.paging.curPage < maxPage) {
                    this.paging.hasNext = true;
                } else {
                    this.paging.hasNext = false;
                }

                if(this.paging.curPage != 1) {
                    this.paging.hasPrev = true;
                } else {
                    this.paging.hasPrev = false;
                }

                if(this.paging.curMinPage != 1) {
                    this.paging.hasFirst = true;
                } else {
                    this.paging.hasFirst = false;
                }
            },
            goRecommendKeywordAjax() {
                const vm = this;
                this.$axios.post("/api/common/retrieveRecommendKeyword.ajax").then((result) => {
                    vm.keywordList = result.data.keywordList;
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            updateViewCnt(seqNo) {
                const vm = this;
                vm.seqNo = seqNo;

                const params = {
                    seqNo: vm.seqNo
                };

                this.$axios.post("/api/diag/updateDiagViewCnt.ajax",
                    qs.stringify(params)).then((result) => {
                    const r = { path : "/main/diag/detail?seqNo=" + vm.seqNo + "&catCode1="
							+ vm.catCode1 + "&searchYn=" + vm.searchYn + "&allClickYn=" + vm.allClickYn
							+ "&schTxt=" + vm.schTxt + "&curPage=" + vm.paging.curPage };
                    this.$router.push(r);
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            afterLeave: function (el) {
                this.$nextTick(function(){
                    $('#ssearchPage').focus();
                });
            },
            deleteKeyword() {
                this.schTxt = '';
                $('#sSearchPage').focus();
            },
			isTabActive(catCode1) {
                if(this.catCode1 == catCode1) {
                    return true;
                } else {
                    return false;
                }
			},
            checkTextLength (event) {
                var strValue = event.target.value;
                var strLength = this.getStrByte(event.target.value);

                if (strLength > this.maxLength) {
                    strValue = this.strCutByByte(strValue, this.maxLength);
                    strLength = this.getStrByte(strValue);
                    this.schTxt = strValue;
                    return;
                }
            },
            strCutByByte (str, max) {
                var byteLength = 0;
                var result = "";

                for (var inx = 0; inx < str.length; inx++) {
                    var oneChar  = str.charAt(inx);
                    var charCode = oneChar.charCodeAt(0);
                    if(charCode)
                        if(charCode != 13){
                            if (charCode <= 0x00007F) {
                                byteLength ++;
                            }else if (charCode <= 0x0007FF) {
                                byteLength += 2;
                            }else if (charCode <= 0x00FFFF) {
                                byteLength += 3;
                            } else {
                                byteLength += 4;
                            }
                        }

                    if (byteLength > max) {
                        break;
                    }
                    result = result + str.charAt(inx);
                }

                return result;
            },
            getStrByte(value) {
                var byteLength = 0, ch;
                var charCode;
                var len = value.length;
                for(var i = 0; i < len; i++) {
                    ch = value.charAt(i);
                    charCode = ch.charCodeAt(0);
                    if(charCode)
                        if(charCode != 13){ // enter값이 2번 넘어온다.10,13 10번은 화면 test 시  나오지만 13번은 나오지 않아 13번을 막음.
                            if (charCode <= 0x00007F) {
                                byteLength ++;
                            }else if (charCode <= 0x0007FF) {
                                byteLength += 2;
                            }else if (charCode <= 0x00FFFF) {
                                byteLength += 3;
                            } else {
                                byteLength += 4;
                            }
                        }
                }
                return byteLength;
            }
        },
        computed: {
            firstTabName: function() {
                if(this.searchYn == "Y") {
                    return this.$t("sdp.mypage.message.tabbuyall");
				} else {
                    return this.$t("sdp.faq.message.tap_top");
				}
			}
        },
        mounted() {

            const vm = this;
            ui.loading.open();

            var clientWidth = document.documentElement.clientWidth;
            console.log('clientWidth ', clientWidth);

            var pageCount = 10;
            var rowCount = 8;
            if(clientWidth < 760) {
                rowCount = 4;
                pageCount = 3;
            }

            var curPage = 1;
            if(vm.$route.query.detailYn != null && vm.$route.query.detailYn != "") {
                vm.searchYn = vm.$route.query.searchYn;
                vm.allClickYn = vm.$route.query.allClickYn;
                vm.catCode1 = vm.$route.query.catCode1;
                vm.schTxt = vm.$route.query.schTxt;
                curPage = vm.$route.query.curPage;
			}

            const params = {
                searchYn: vm.searchYn,
                allClickYn: vm.allClickYn,
				catCode1: vm.$route.query.catCode1,
				schTxt: vm.$route.query.schTxt,
                curPage: curPage,
                rowCount: rowCount,
                pageCount: pageCount,
                totalCount: 0,
            };

            this.$axios.post("/api/diag/retrieveDiagList.ajax",
                qs.stringify(params)).then((result) => {
                ui.loading.close();
                vm.diagList = result.data.diagList;
                vm.diagCateList = result.data.diagCateList;
                vm.totCnt = result.data.totCnt;
                // vm.diagHashTagList = result.data.diagHashTagList;
                vm.diagResourcePathList = result.data.diagResourcePathList;
                vm.loadingYn = "N";
                vm.tabPanelName = vm.firstTabName;

                vm.setResult(result);
                vm.resetPageList();
                vm.$nextTick(function() {
                    ui.init();
                });
            }).catch((err) => {
                ui.loading.close();
                vm.loadingYn = "N";
                alert("error : " + err);
            });

            vm.goRecommendKeywordAjax();
        }
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
