<template>
    <!-- content -->
    <section id="content" class="content selftest-cont">
        <!-- content Header -->
        <div class="content-header sub-visual">
            <div class="sub-visual-bg"></div>
            <div class="in-sec">
                <div class="tit-wrap centered-c">
                    <h2 class="tit-h2">{{ $t('sdp.menu.gnb.self') }}</h2>
                    <p class="explain-h2">{{ $t('sdp.self.message.title1') }}</p>
                </div>
            </div>
        </div>
        <!-- //content Header -->
        <!-- //content Header -->
        <!-- content Body -->
        <div class="content-body">
            <!-- 탭전체영역 -->
            <!-- 고도화 ver2 : 구조 tit 변경 -->
            <div class="tab-type1-wrap in-sec">
                <!-- 탭메뉴 -->
                <nav class="tab-nav tab-type1 tab-responsive blind-selected-wrap"><!-- 웹접근성 논리적인구조 : 선택된탭제목 목차텍스트로 내보내기 JS처리 -->
                    <ul role="tablist">
                        <li role="presentation" :class="{'is-active' : isTabActive('')}" v-show="diagCateList.length > 0">
                            <a href="javascript:;" role="tab" aria-selected="true" @click="goAllSearch()">
                                <span class="tit">{{ firstTabName }}<em v-if="searchYn == 'Y'" class="label-type2">{{ totCnt }}</em></span>
                            </a>
                        </li>
                        <li v-for="item in diagCateList" role="presentation" :class="{'is-active' : isTabActive(item.catCode)}">
                            <a href="javascript:;" role="tab" aria-selected="false" @click="goTabSearch(item.catCode)">
                                <span class="tit">{{ item.catName }}<em class="label-type2">{{ item.cnt }}</em></span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- //탭메뉴 -->
                <div class="tab-body">
                    <p class="blind blind-selected dv-pc-only"></p><!-- 선택된탭제목 목차텍스트로 가져오기 -->
                    <!-- 자가진단 상세그룹 -->
                    <div class="loading-wrap" v-if="loadingYn == 'Y'">
                        <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                    </div>
                    <div class="board-view-wrap selftest-view in-sec" v-else>
                        <div class="board-view" v-for="item in diagInfo">
                            <div class="board-header">
                                <div class="tit-wrap">
                                    <h3 class="tit-h3" v-html="item.titleName"></h3>
                                </div>
                                <div class="txt-wrap">
                                    <dl>
                                        <dt class="tit tit-date" role="text">{{ $t('sdp.support.message.cdate') }}</dt>
                                        <dd class="txt txt-date">{{ item.crtDate }}</dd>
                                    </dl>
                                </div>
                            </div>
                            <div class="board-body">
                                <!-- 미디어그룹 -->
                                <!-- 고도화 ver2 : 컨트롤러 외부로 이동 -->
                                <div v-show="videoYn == 'N'" class="swiper-wrap swiper-selftest">
                                    <div class="swiper-container">
                                        <div class="swiper-wrapper">
                                            <template v-for="(res, index) in diagResource">
                                                <div v-if="index > 0" class="swiper-slide">
                                                    <div class="data-image">
                                                        <img :src="res.resourcePth" :alt="res.description" />
                                                    </div>
                                                    <!-- 데이타그룹 -->
                                                    <div class="data-content" role="text" v-html="lineBreakCntt(res.cntt)">
                                                        <!-- 엔터치면 빈태그로 문단여백처리 -->
                                                    </div>
                                                    <!-- //데이타그룹 -->
                                                </div>
                                            </template>
                                        </div>
                                    </div>
                                    <div class="swiper-pagination"></div>
                                    <button type="button" class="swiper-button-prev"></button>
                                    <button type="button" class="swiper-button-next"></button>
                                </div>
                                <!-- //미디어그룹 -->

                                <!-- 동영상 -->
                                <div v-show="videoYn == 'Y'" class="ytplayer-selftest">
                                    <div id="playerLoading" class="section-body">
                                        <div class="loading-wrap">
                                            <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                                        </div>
                                    </div>
                                    <div id="ytplayerBox" class="ytplayer-wrap" style="display: none">
                                        <div id="ytplayer" class="ytplayer"></div>
                                        <div class="ytplayer-cover">
                                            <button type="button" class="btn-ico ytplayer-play centered-c"><span><i class="ico ico-play-youtube">{{ $t('gwa.alt.diag.wa_label_1', { var1 : item.titleName }) }}</i></span></button>
                                        </div>
                                    </div>
                                    <template v-for="caption in diagCaption">
                                        <div v-if="captionYn == 'Y'" class="ytplayer-btn" data-state="closed">
                                            <button type="button" class="btn btn-type7 folder-open" tabindex="0" aria-controls="mediaFoler" aria-expanded="false" aria-hidden="false" :aria-label="$t('gwa.alt.diag.wa_label_2', { var1 : caption.description })" data-role="fold" data-target="mediaFoler" data-state="opened"><span><i class="ico ico-open-media"></i>{{ caption.description }}</span></button>
                                            <button type="button" class="btn btn-type7 folder-close" tabindex="-1" aria-controls="mediaFoler" aria-expanded="true" aria-hidden="true" :aria-label="$t('gwa.alt.diag.wa_label_3', { var1 : caption.description })" data-role="fold" data-target="mediaFoler" data-state="closed"><span><i class="ico ico-close-media"></i>{{ $t("sdp.message.layerpopup.close") }}</span></button>
                                        </div>
                                    </template>
                                </div>
                                <!-- //동영상 -->

                                <!-- 자막영역 -->
                                <div v-show="videoYn == 'Y' && captionYn == 'Y'" class="media-content">
                                    <div id="mediaFoler" class="media-inner folder-content" aria-hidden="true" data-name="mediaFoler">
                                        <div class="data-content" role="text" v-for="caption in diagCaption" v-html="lineBreakCntt(caption.cntt)"></div>
                                    </div>
                                </div>
                                <!-- //자막영역 -->
                            </div>
                            <div class="board-footer">
                                <!-- 데이타그룹 -->
                                <!--<div class="data-content" role="text" v-html="item.cntt"></div>-->
                                <!-- //데이타그룹 -->
                                <!-- 만족도그룹 -->
                                <!-- 고도화 ver2 : 속성 aria-label 검색 추가 -->
                                <div v-if="diagHashTagList.length > 0" class="tag-wrap">
                                    <template v-for="tag in diagHashTagList">
                                        <a href="javascript:;" class="tag-type1" role="button" @click="goKeywordSearch(tag.hashTag)" :aria-label="tag.hashTag+' '+$t('gwa.alt.main.sch')">
                                            #{{ tag.hashTag }}
                                        </a>
                                    </template>
                                </div>
                                <div class="msg-wrap">
                                    <p class="txt-area"><i class="arw arw-right" aria-hidden="true"></i>{{ $t('sdp.Satisfaction.message.question') }}</p>
                                    <div class="btn-area">
                                        <button type="button" class="btn btn-type4 btn-primary" @click="goSatisf('Y')"><span>{{ $t('sdp.Satisfaction.message.btn1') }}</span></button>
                                        <button type="button" class="btn btn-type4 popup-open" aria-controls="popupFaqQuestion" aria-haspopup="true"><span>{{ $t('sdp.Satisfaction.message.btn2') }}</span></button>
                                    </div>
                                </div>
                                <!-- //만족도그룹 -->
                            </div>
                        </div>

                        <!-- 버튼 -->
                        <div class="btn-wrap in-sec">
                            <a href="javascript:;" class="btn btn-type1" @click="goList()" :aria-label="$t('gwa.alt.common.wa_title_26')"><span>{{ $t('sdp.support.message.listview') }}</span></a>
                        </div>
                        <!-- //버튼 -->
                    </div>
                    <!-- //자가진단 상세그룹 -->
                </div>
            </div>
            <!-- //탭전체영역 -->


            <!-- 팝업_만족도조사 -->
            <FaqSatisfPop></FaqSatisfPop>
            <!-- //팝업_만족도조사 -->

            <div id="popupTabSelect" class="popup-wrap popup-select" role="dialog">
                <div class="popup popup-tab">
                    <nav class="tab-nav tab-type1 tab-responsive">
                        <ul role="tablist">
                            <li role="presentation" :class="{'is-active' : isTabActive('')}" v-show="diagCateList.length > 0">
                                <a href="javascript:;" role="tab" aria-selected="true" @click="goAllSearch()">
                                    <span class="tit">{{ firstTabName }}<em v-show="searchYn == 'Y'" class="label-type2">{{ totCnt }}</em></span>
                                </a>
                            </li>
                            <li v-for="item in diagCateList" role="presentation" :class="{'is-active' : isTabActive(item.catCode)}">
                                <a href="javascript:;" role="tab" aria-selected="false" @click="goTabSearch(item.catCode)">
                                    <span class="tit">{{ item.catName }}<em class="label-type2">{{ item.cnt }}</em></span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <button type="button" class="btn-ico btn-close-select" aria-controls="popupTabSelect"><span><i class="ico ico-close2">{{ $t('gwa.alt.common.wa_label_22') }}</i></span></button>
                </div>
            </div>

        </div>
        <!-- //content Body -->
    </section>
    <!-- //content -->

</template>

<script>
//Youtube Player Init
var tag = document.createElement('script');
tag.src = "https://www.youtube.com/player_api";
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
var yPlayer;
function onYouTubeIframeAPIReady(videoId) {
    yPlayer = new YT.Player('ytplayer', {
        height: '100%',
        width: '100%',
        //videoId: 'XgqkIIt1fMA',
        videoId: videoId,
        playerVars: {
            'controls': 1,
            'showinfo' : 0,
            'nologo' : 1,
        },
        events: {
            'onReady' : onPlayerReady
        }
    })
}
function onPlayerReady(event) {
    document.getElementById("playerLoading").style.display = "none";
    document.getElementById("ytplayerBox").style.display = "block";
}

//Youtube Player Controller
$(function(){
    $(document).on('click', '.ytplayer-play', function(){
        var $this = $(this);
        yPlayer.playVideo();
        $this.parent().addClass('is-active');
        setTimeout(function(){$this.parent().hide()},300);
        //yPlayer.stopVideo();
    })
});

import qs from "qs";
import FaqSatisfPop from '@/components/faq/FaqSatisfPop';

export default {
  name: "DiagDetail",
    components: {
        FaqSatisfPop
    },
  data() {
    return {
        diagInfo: [],
        diagResource: [],
        diagCaption: [],
        diagCateList: [],
        totCnt: 0,
        diagHashTagList: [],
        videoYn: "",
        videoId: "",
        captionYn: "",
        catCode1: "",
        searchYn: "N",
        allClickYn: "Y",
        loadingYn: "Y",
        seqNo: "",
        schTxt: "",
        curPage: 1,
        keywordList: []
    }
  },
  created() {

  },
  watch: {
    $route: "fetchData"
  },
  computed: {
      firstTabName: function() {
          if(this.searchYn == "Y") {
              return this.$t("sdp.mypage.message.tabbuyall");
          } else {
              return this.$t("sdp.faq.message.tap_top");
          }
      }
  },
  methods: {
      track () {
            console.log('@@@@ track:', this.$router.currentRoute.path);
            this.$ga.page(this.$router.currentRoute.path)
        },
      goList() {
          const vm = this;
          const r = { path : "/main/diag?catCode1=" + vm.catCode1 + "&searchYn=" + vm.searchYn + "&allClickYn="
                  + vm.allClickYn + "&schTxt="+ vm.schTxt + "&curPage=" + vm.curPage + "&detailYn=Y" };
          this.$router.push(r);
      },
      goAllSearch() {
          const vm = this;
          const r = { path : "/main/diag?catCode1=&searchYn=" + vm.searchYn +
                  "&allClickYn=Y&schTxt=" + vm.schTxt + "&curPage=" + vm.curPage + "&detailYn=Y" };
          this.$router.push(r);
      },
      goTabSearch(catCode1) {
          const vm = this;
          const r = { path : "/main/diag?catCode1=" + catCode1 + "&searchYn=" + vm.searchYn +
                  "&allClickYn=N&schTxt=" + vm.schTxt + "&curPage=1&detailYn=Y" };
          this.$router.push(r);
      },
      goKeywordSearch(keyword) {
          const vm = this;
          const r = { path : "/main/diag?catCode1=" + vm.catCode1 + "&searchYn=Y&allClickYn="
                  + vm.allClickYn + "&schTxt=" + keyword + "&curPage=" + vm.curPage + "&detailYn=Y" };
          this.$router.push(r);
      },
      isTabActive(catCode1) {
          if(this.catCode1 == catCode1) {
              return true;
          } else {
              return false;
          }
      },
      lineBreakCntt(cntt) {
          if(cntt != null && cntt != "") {
              return cntt.split("\n").join("<br />");
          } else {
              return "";
          }
      },
      goSatisf(clickType) {
          const vm = this;

          const params = {
              clickType: clickType,
              diagSeqNo: vm.seqNo
          };

          this.$axios.post("/api/diag/mergeDiagSatisf.ajax",
              qs.stringify(params)).then((result) => {
              alert(this.$t("sdp.Satisfaction.message.pop_text6"));
          }).catch((err) => {
              alert("error : " + err);
          });
      },
      callSwiper() {
          console.log("callSwiper");
          ui.swiper.selftest();
      }
  },
  mounted() {
      const vm = this;
      ui.loading.open();

      vm.seqNo = vm.$route.query.seqNo;
      vm.catCode1 = vm.$route.query.catCode1;
      if (vm.$route.query.searchYn != undefined || vm.$route.query.searchYn != null) {
          vm.searchYn = vm.$route.query.searchYn;
      }
      if (vm.$route.query.allClickYn != undefined || vm.$route.query.allClickYn != null) {
          vm.allClickYn = vm.$route.query.allClickYn;
      }
      if (vm.$route.query.schTxt != undefined || vm.$route.query.schTxt != null) {
          vm.schTxt = vm.$route.query.schTxt;
      }
      vm.curPage = vm.$route.query.curPage;

      const params = {
          seqNo: vm.seqNo,
          schTxt: vm.schTxt
      };

      this.$axios.post("/api/diag/retrieveDiagInfo.ajax",
          qs.stringify(params)).then((result) => {
          // 만족도 조사
          this.$store.state.satisfType = 'diag';
          this.$store.state.faqSeqNo = vm.seqNo;

          ui.loading.close();
          vm.diagInfo = result.data.diagInfo;
          vm.diagResource = result.data.diagResource;
          vm.diagCaption = result.data.diagCaption;
          vm.diagCateList = result.data.diagCateList;
          vm.totCnt = result.data.totCnt;
          vm.diagHashTagList = result.data.diagHashTagList;
          vm.videoYn = result.data.videoYn;
          vm.videoId = result.data.videoId;
          vm.captionYn = result.data.captionYn;
          vm.loadingYn = "N";
          vm.$nextTick(function() {
              ui.init();
              loadSelected();
              if(vm.videoYn == 'Y') {
                  onYouTubeIframeAPIReady(vm.videoId);
              }
          });
      }).catch((err) => {
          ui.loading.close();
          vm.loadingYn = "N";
          alert("error : " + err);
      });

      vm.callSwiper();
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
