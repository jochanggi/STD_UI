<template>
    <!-- content -->
    <section id="content" class="content tvapp-cont">
        <!-- content Header -->
        <div class="content-header sub-visual">
            <div class="sub-visual-bg"></div>
            <div class="in-sec">
                <div class="tit-wrap centered-c">
                    <h2 class="tit-h2">{{ $t('sdp.menu.gnb.tvapp') }}</h2>
                </div>
            </div>
        </div>
        <!-- //content Header -->

        <!-- content Body -->
        <div class="content-body">
            <!-- 검색메뉴 -->
            <div class="section-wrap in-sec">
                <!-- 앱목록 전체영역 -->
                <section class="section section-category">
                    <div class="section-header">
                        <div class="inner">
                            <h3 class="tit-h3">{{ $t("sdp.menu.topseller") }} | {{ sellrUsrName }}
                                <em class="label-type4" v-if="loadingYn == 'N'"><span class="txt-count">{{ paging.totalCount }}</span></em>
                            </h3>
                        </div>
                    </div>
                    <div class="section-body" v-if="loadingYn == 'Y'">
                        <div class="loading-wrap">
                            <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                        </div>
                    </div>
                    <div class="section-body" v-else-if="appList.length > 0">
                        <div id="tvAppWrap" class="app-lists-wrap">
                            <div class="app-lists" data-type="image">
                                <ul>
                                    <li v-for="item in appList">
                                        <div class="item-wrap">
                                            <p v-if="item.age >= 18 && userAge < 18" class="item-thumb thumbnail"><a href="javascript:;" class="more-focus popup-open" aria-controls="popupInfoGuide" aria-haspopup="true" :title="$t('gwa.alt.common.wa_title_33')" @click="setAdultAppName(item.appName, item.appId)"><img :src="item.appPath" :alt="$t('gwa.alt.tvapp.wa_etc_1', { var1 : item.appName })" onerror="imageResize.reset(this)" /></a></p>
                                            <p v-else class="item-thumb thumbnail"><a href="javascript:;" class="more-focus" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(item.appId)"><img :src="item.appPath" :alt="$t('gwa.alt.tvapp.wa_etc_1', { var1 : item.appName })" /></a></p>
                                            <p class="item-tit"><strong>{{ item.appName }}</strong></p>
                                            <p class="item-part" :aria-label="$t('gwa.alt.tvapp.wa_label_1', { var1 : item.catName })">{{ item.catName }}</p>
                                            <p class="item-txt"><a class="tracking app_list seller" href="javascript:;" :title="$t('gwa.alt.tvapp.wa_title_1')" :aria-label="$t('gwa.alt.tvapp.wa_label_2', { var1 : item.sellrUsrName })">{{ item.sellrUsrName }}</a></p>
                                            <div class="item-star">
                                                <div class="js starRating-label" role="text" aria-valuemax="5" aria-valuemin="0" :aria-valuenow="appStar(item.avgSscr)">
                                                    <span class="blind">{{ $t('gwa.alt.tvapp.wa_label_3', { var1 : appStar(item.avgSscr) }) }}</span>
                                                    <span class="rating"><span class="rating-max"></span><span class="rating-now"></span></span>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <!-- 고도화 ver2 : 속성 aria-label 문구수정 -->
                            <div class="loading-wrap" v-if="pagingYn == 'Y'">
                                <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                            </div>
                            <div class="btn-more-wrap" v-else>
                                <button @click="goNextPage()" type="button" class="btn btn-type9" :aria-label="$t('gwa.alt.common.wa_label_35')+' : '+$t('gwa.alt.common.wa_label_49', { var1 : calTotalPage(), var2 : paging.curPage })"><span>{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-tvapp"></i><em class="label-page">{{ paging.curPage }}/{{ calTotalPage() }}</em></span></button>
                                <!--<button type="button" class="btn-ico"><span><i class="ico ico-more-tvapp"></i></span></button>-->
                            </div>
                        </div>
                    </div>
                    <!-- 미등록게시물 -->
                    <div class="noData-wrap" v-else>
                        <div class="noData">
                            <div class="inner">
                                <p><i class="ico ico-waring2" aria-hidden="true"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
                            </div>
                        </div>
                    </div>
                    <!-- //미등록게시물 -->
                </section>
                <!-- 앱목록 전체영역 -->
            </div>
            <!-- //검색메뉴 -->

            <!-- 팝업_APP이용안내 -->
            <div id="popupInfoGuide" class="popup-wrap" hidden>
                <div class="popup popup-type1" role="dialog" aria-labelledby="popupInfoGuideTitle">
                    <div class="blind-area popup-focus dv-ios-only" role="text" :aria-label="$t('gwa.alt.common.wa_label_55')"><!-- IOS접근성 영역자체에 초점처리 --></div>
                    <div class="popup-container">
                        <div class="popup-header">
                            <h3 class="tit-h3" id="popupInfoGuideTitle">APP {{ $t("sdp.menu.overview") }}</h3>
                        </div>
                        <div class="popup-body popup-scroll">
                            <div class="para-wrap align-c">
                                <p class="para color-primary" v-html="$t('sdp.store.message.minorsapp')"></p>
                                <p class="para" v-html="$t('sdp.store.minorsapp.detailinfo', { var1 : adultAppName })"></p>
                            </div>
                        </div>
                        <div class="popup-footer">
                            <div class="btn-wrap">
                                <button @click="goLgaccount('N')" type="button" class="btn btn-type2 btn-primary"><span>{{ $t("sdp.menu.join_member") }}</span></button>
                                <button @click="goLgaccount('Y')" type="button" class="btn btn-type2 btn-primary"><span>{{ $t("sdp.menu.gnb.lgaccount") }}</span></button>
                                <button type="button" class="btn btn-type2 btn-secondary popup-close" aria-controls="popupInfoGuide" :title="$t('gwa.alt.common.wa_title_58')"><span>{{ $t("sdp.message.layerpopup.close") }}</span></button>
                            </div>
                        </div>
                        <button type="button" class="btn-ico btn-popup-close popup-close" aria-controls="popupInfoGuide" :title="$t('gwa.alt.common.wa_title_58')"><span><i class="ico ico-close2">{{ $t('gwa.alt.common.wa_label_19') }}</i></span></button>
                    </div>
                </div>
            </div>
            <!-- //팝업_APP 이용안내 -->
        </div>
        <!-- //content Body -->
    </section>
    <!-- //content -->
</template>

<script>
    import qs from "qs";

    export default {
        name: "Tvapp",
        data() {
            return {
                appList: [],
                userAge: 0,
                adultAppName: "",
                adultAppId: "",
                sellrUsrNo: "",
                sellrUsrName: "",
                paging: {
                    pageList: [],
                    totalCount: 0,
                    pageCount: 0,
                    rowCount: 0,
                    curPage: 1,
                    hasNext: false,
                    hasLast: false,
                    hasPrev: false,
                    hasFirst: false,
                    curMaxPage: 0,
                    curMinPage: 1
                },
                loadingYn: "Y",
                pagingYn: "N",
                cntryCode: _domainCntryCode
            }
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            goNextPage() {
                const vm = this;
                if(vm.paging.curPage < vm.calTotalPage()) {
                    vm.paging.curPage = vm.paging.curPage + 1;
                    vm.goSearchAjax();
                }
            },
            goSearchAjax() {
                ui.loading.open();
                const vm = this;
                const params = {
                    sellrUsrNo : vm.sellrUsrNo,
                    curPage: vm.paging.curPage,
                    rowCount: vm.paging.rowCount,
                    pageCount: vm.paging.pageCount,
                    totalCount: vm.paging.totalCount
                };
                vm.pagingYn = "Y";
                vm.goSellerAjax(params);
            },
            goSellerAjax(params) {
                const vm = this;
                this.$axios.post("/api/tvapp/retrieveSellerAppList.ajax",
                    qs.stringify(params)).then((result) => {
                    ui.loading.close();
                    vm.appList = result.data.appList;
                    vm.userAge = result.data.userAge;
                    vm.sellrUsrName = result.data.sellrUsrName;
                    vm.loadingYn = "N";
                    vm.pagingYn = "N";
                    vm.setResult(result);
                    vm.$nextTick(function() {
                        ui.popup.init();
                        ui.starRating.init();
                        ui.listsType.init();
                    });
                }).catch((err) => {
                    ui.loading.close();
                    vm.loadingYn = "N";
                    vm.pagingYn = "N";
                    alert("error : " + err);
                });
            },
            appStar(avgSscr) {
                if (avgSscr >= 9.5) {
                    return 5;
                } else if (avgSscr >= 8.5) {
                    return 4.5;
                } else if (avgSscr >= 7.5) {
                    return 4;
                } else if (avgSscr >= 6.5) {
                    return 3.5;
                } else if (avgSscr >= 5.5) {
                    return 3;
                } else if (avgSscr >= 4.5) {
                    return 2.5;
                } else if (avgSscr >= 3.5) {
                    return 2;
                } else if (avgSscr >= 2.5) {
                    return 1.5;
                } else if (avgSscr >= 1.5) {
                    return 1;
                } else if (avgSscr >= 0.5) {
                    return 0.5;
                } else {
                    return 0;
                }
            },
            goTvappDetail(appId) {
                const r = { path : "/main/tvapp/detail?appId=" + appId
                        + "&catCode1=&moreYn=N&cateYn=N&orderType=0&headerName=&appRankCode="
                        + "&sellrUsrNo=" + this.sellrUsrNo + "&curPage=" + this.paging.curPage };
                this.$router.push(r);
            },
            goTvappSeller(sellrUsrNo) {
                const r = { path : "/main/tvapp/seller?sellrUsrNo=" + sellrUsrNo };
                this.$router.push(r);
            },
            setResult(result) {
                this.paging.totalCount = result.data.totalCount;
                this.paging.pageCount = result.data.pageCount;
                this.paging.curPage = result.data.curPage;
                this.paging.rowCount = result.data.rowCount;
            },
            calTotalPage() {
                const vm = this;
                const totalPage = parseInt(vm.paging.totalCount / vm.paging.rowCount);
                if(vm.paging.totalCount % vm.paging.rowCount == 0) {
                    return totalPage;
                } else {
                    return totalPage + 1;
                }
            },
            setAdultAppName(appName, appId) {
                this.adultAppName = appName;
                this.adultAppId = appId;
            },
            goLgaccount(loginYn) {
                const vm = this;

                var _params = {
                    appId: vm.adultAppId,
                    catCode1: "",
                    moreYn: "N",
                    cateYn: "N",
                    orderType: "0",
                    headerName: "",
                    appRankCode: "",
                    sellrUsrNo: vm.sellrUsrNo,
                    curPage: vm.paging.curPage
                };

                const params = {
                    cntryCode: _domainCntryCode,
                    path: "tvapp/detail?" + qs.stringify(_params),
                    loginYn: loginYn
                };

                this.$axios.post('/api/main/retrieveLoginInfo.ajax',
                    qs.stringify(params)).then((result) => {
                    var loginUrl = result.data.loginUrl;
                    window.location = loginUrl;
                }).catch((err) => {
                    alert(err);
                });
            }
        },
        computed: {

        },
        mounted() {

            // ui.searchAll.close('searchAll'); // 검색바 닫힘

            const vm = this;
            $(window).scrollTop(0);

            vm.sellrUsrNo = vm.$route.query.sellrUsrNo;

            var pageCount = 10;
            var rowCount = 24;

            var curPage = 1;
            if(vm.$route.query.curPage != null && vm.$route.query.curPage != "") {
                curPage = vm.$route.query.curPage;
            }

            const params = {
                sellrUsrNo: vm.sellrUsrNo,
                curPage: curPage,
                rowCount: rowCount,
                pageCount: pageCount,
                totalCount: 0,
            };
            vm.loadingYn = "Y";

            vm.goSellerAjax(params);
        }
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
