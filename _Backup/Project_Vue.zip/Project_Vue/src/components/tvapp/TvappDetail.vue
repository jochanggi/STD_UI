<template>
    <!-- Content -->
    <section id="content" class="content tvapp-cont">
        <!-- Content Header -->
        <div class="content-header sub-visual">
            <div class="sub-visual-bg"></div>
            <div class="in-sec">
                <div class="tit-wrap centered-c">
                    <h2 class="tit-h2">{{ $t('sdp.menu.gnb.tvapp') }}</h2>
                </div>
            </div>
        </div>
        <!-- //Content Header -->

        <!-- Content Body -->
        <div class="content-body">
            <!-- 탭메뉴 -->
            <div class="tab-type1-wrap in-sec">
                <nav class="tab-nav tab-type1 tab-responsive blind-selected-wrap"><!-- 웹접근성 논리적인구조 : 선택된탭제목 목차텍스트로 내보내기 JS처리 -->
                    <ul role="tablist">
                        <li role="presentation" :class="{'is-active' : isTabActive('')}" v-show="appCateList.length > 0">
                            <a href="javascript:;" role="tab" aria-selected="true" @click="goAllSearch()">
                                <span class="tit">{{ $t("sdp.mypage.message.tabbuyall") }}</span>
                            </a>
                        </li>
                        <li v-for="item in appCateList" role="presentation" :class="{'is-active' : isTabActive(item.catCode)}">
                            <a href="javascript:;" role="tab" aria-selected="false" @click="goTabSearch(item.catCode, item.catName)">
                                <span class="tit">{{ item.catName }}<em class="label-type2">{{ item.cnt }}</em></span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="section-body" v-if="loadingYn == 'Y'">
                    <div class="loading-wrap">
                        <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                    </div>
                </div>
                <div class="tab-body" v-else>
                    <!-- 상세섹션 -->
                    <p class="blind blind-selected dv-pc-only"></p><!-- 선택된탭제목 목차텍스트로 가져오기 -->
                    <section class="section section-category outline" v-for="item in prodInfo">
                        <div class="section-header">
                            <div class="inner">
                                <h3 class="tit-h3"><span role="text">{{ item.appName }} <i v-for="feat in featureList" :class="'ico ico-category'+feat.icoType">{{ item.cat }}</i></span></h3>
                                <div class="starRating-cate">
                                    <div class="js starRating-label" role="text" aria-valuemax="5" aria-valuemin="0" :aria-valuenow="appStar(item.avgSscr)" :aria-label="$t('gwa.alt.tvapp.wa_label_3', { var1 : appStar(item.avgSscr) })">
                                        <span class="rating"><span class="rating-max"></span><span class="rating-now"></span></span>
                                        <span class="label">{{ appStar(item.avgSscr) }} {{ $t("sdp.store.message.score") }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="section-body">
                            <!-- 앱상세 전체영역 -->
                            <div class="view-app-wrap">
                                <!-- 주요정보 -->
                                <div class="view-header">
                                    <div class="tit-wrap">
                                        <p class="thumbnail"><img :src="item.bigIconFile" :alt="$t('gwa.alt.tvapp.wa_etc_1', { var1 : item.appName })" onerror="imageResize.reset(this)" /></p>
                                    </div>
                                    <div class="tbl-wrap">
                                        <div class="tbl-type2">
                                            <table>
                                                <caption>
                                                    <div class="blind-area" role="text">
                                                        <strong>{{ $t("gwa.alt.common.wa_caption_5", { var1 : item.appName }) }}</strong>
                                                        <p>{{ $t("gwa.alt.common.wa_summary_5") }}</p>
                                                    </div>
                                                </caption>
                                                <tbody>
                                                <tr>
                                                    <th scope="row">{{ $t("sdp.store.message.age") }}</th>
                                                    <td>
                                                        <span v-if="cntryCode == 'BR' && item.age == '4'">{{ item.ageBr }}</span>
                                                        <span v-else>{{ item.appAge }}</span>
                                                    </td>
                                                    <th scope="row">{{ $t("sdp.store.message.version") }}</th>
                                                    <td>{{ item.appVer }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">{{ $t("sdp.store.message.size") }}</th>
                                                    <td>{{ fileSizeReplace(item.appFileSize) }}</td>
                                                    <th scope="row">{{ $t("sdp.store.message.language") }}</th>
                                                    <td>{{ appSuptLangName }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">{{ $t("sdp.store.message.category") }}</th>
                                                    <td>{{ item.cat }}</td>
                                                    <th scope="row">{{ $t("sdp.store.message.seller") }}</th>
                                                    <td>{{ item.sellrUsrName }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" v-html="$t('sdp.store.message.released')"></th>
                                                    <td colspan="3">{{ item.dplyDate }}</td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="explain-footer">
                                            <div class="bul bul-bill">
                                                <p>{{ $t("sdp.store.message.supporteddeviceinfo") }}</p>
                                            </div>                                    
                                        </div>
                                    </div>
                                </div>
                                <!-- //주요정보 -->

                                <!-- 상세정보 -->
                                <div class="view-body">
                                    <div class="tab-wrap">
                                        <div class="tab-nav tab-type3 tab-change">
                                            <ul class="tablist">
                                                <li role="presentation" class="is-active"><a href="#tabViewCont1" id="tabViewNav1" role="tab" aria-controls="tabViewCont1" aria-selected="true">{{ $t('sdp.store.message.overview') }}</a></li>
                                                <li v-show="cntryCode != 'C01'" role="presentation"><a href="#tabViewCont2" id="tabViewNav2" role="tab" aria-controls="tabViewCont2" aria-selected="false">{{ $t('sdp.store.message.devicecompatibility') }}</a></li>
                                            </ul>
                                        </div>
                                        <div class="tab-body">
                                            <!-- 탭내용1 -->
                                            <div id="tabViewCont1" class="tab-content is-active" aria-labelledby="tabViewNav1" aria-hidden="false">
                                                <p class="blind dv-pc-only">{{ $t('sdp.store.message.overview') }}</p>
                                                <!-- DESCRIPTION -->
                                                <div class="view-section view-description">
                                                    <h4 class="tit-h4">{{ $t("sdp.store.message.description") }}</h4>
                                                    <div class="data-content" role="text">
                                                        <p class="para" v-html="lineBreakCntt(item.detailExpln)"></p>
                                                    </div>
                                                </div>
                                                <!-- //DESCRIPTION -->
                                                <!-- SCREENSHOTS -->
                                                <div class="view-section view-screenshots">
                                                    <h4 class="tit-h4">{{ $t("sdp.store.message.screenshot") }}</h4>
                                                    <div class="swiper-wrap swiper-screenshots">
                                                        <!-- 상세그룹  -->
                                                        <!--  대체텍스트 형식 : alt="[앱 제목] + Screenshots + [Index]" -->
                                                        <div class="swiper-container">
                                                            <div class="swiper-wrapper">
                                                                <div class="swiper-slide" v-for="(screenShot, index) in screenShotList">
                                                                    <a href="javascript:;" :data-src="screenShot.orgFilePath" onclick="zommer.open(this); return false"><img :src="screenShot.filePath" :alt="$t('gwa.alt.tvapp.wa_etc_3', { var1 : item.appName, var2 : (index+1) })" /></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="swiper-button-prev"></div>
                                                        <div class="swiper-button-next"></div>
                                                    </div>
                                                </div>
                                                <!-- //SCREENSHOTS -->

                                                <!-- RAINGS -->
                                                <div v-show="cntryCode != 'C01'" class="view-starating">
                                                    <div class="ratings-title">
                                                        <h4 class="tit-h4">{{ $t("sdp.store.message.starscorerating") }}</h4>
                                                        <p class="explain-h4"><strong>{{ $t("gwa.alt.store.ratingtxt") }}</strong></p>
                                                    </div>
                                                    <!-- 만족도평가 -->
                                                    <!-- 개발참고사항
                                                        <legend> 텍스트 : [앱제목] + APP 만족도 평가 (형식으로 제공)
                                                        <button> 타이틀 : [앱제목] + APP 만족도 평가하기 (형식으로 제공)
                                                    -->
                                                    <div class="ratings-content">
                                                        <div class="ratings-inner">
                                                            <fieldset class="ratings-score">
                                                                <legend>{{ $t("gwa.alt.tvapp.wa_etc_4", { var1 : item.appName }) }}</legend>
                                                                <ul>
                                                                    <li>
                                                                        <span class="form-radio">
                                                                            <input v-model="starScr" type="radio" name="sRadioStar" id="sRadioStar5" value="10" />
                                                                            <label for="sRadioStar5">
                                                                                <span><span class="starRating-label sr-5" role="text" :aria-label="$t('gwa.alt.common.wa_label_4', { var1 : 5 })"><span class="blind dv-pc-only">{{ $t('gwa.alt.common.wa_label_4', { var1 : 5 }) }}</span></span></span>
                                                                            </label>
                                                                        </span>
                                                                    </li>
                                                                    <li>
                                                                        <span class="form-radio">
                                                                            <input v-model="starScr" type="radio" name="sRadioStar" id="sRadioStar4" value="8" />
                                                                            <label for="sRadioStar4">
                                                                                <span><span class="starRating-label sr-4" role="text" :aria-label="$t('gwa.alt.common.wa_label_4', { var1 : 4 })"><span class="blind dv-pc-only">{{ $t('gwa.alt.common.wa_label_4', { var1 : 4 }) }}</span></span></span>
                                                                            </label>
                                                                        </span>
                                                                    </li>
                                                                    <li>
                                                                        <span class="form-radio">
                                                                            <input v-model="starScr" type="radio" name="sRadioStar" id="sRadioStar3" value="6" />
                                                                            <label for="sRadioStar3">
                                                                                <span><span class="starRating-label sr-3" role="text" :aria-label="$t('gwa.alt.common.wa_label_4', { var1 : 3 })"><span class="blind dv-pc-only">{{ $t('gwa.alt.common.wa_label_4', { var1 : 3 }) }}</span></span></span>
                                                                            </label>
                                                                        </span>
                                                                    </li>
                                                                    <li>
                                                                        <span class="form-radio">
                                                                            <input v-model="starScr" type="radio" name="sRadioStar" id="sRadioStar2" value="4" />
                                                                            <label for="sRadioStar2">
                                                                                <span><span class="starRating-label sr-2" role="text" :aria-label="$t('gwa.alt.common.wa_label_4', { var1 : 2 })"><span class="blind dv-pc-only">{{ $t('gwa.alt.common.wa_label_4', { var1 : 2 }) }}</span></span></span>
                                                                            </label>
                                                                        </span>
                                                                    </li>
                                                                    <li>
                                                                        <span class="form-radio">
                                                                            <input v-model="starScr" type="radio" name="sRadioStar" id="sRadioStar1" value="2" />
                                                                            <label for="sRadioStar1">
                                                                                <span><span class="starRating-label sr-1" role="text" :aria-label="$t('gwa.alt.common.wa_label_4', { var1 : 1 })"><span class="blind dv-pc-only">{{ $t('gwa.alt.common.wa_label_4', { var1 : 1 }) }}</span></span></span>
                                                                            </label>
                                                                        </span>
                                                                    </li>
                                                                    <li>
                                                                        <span class="form-radio">
                                                                            <input v-model="starScr" type="radio" name="sRadioStar" id="sRadioStar0" value="0" />
                                                                            <label for="sRadioStar0">
                                                                                <span><span class="starRating-label sr-0" role="text" :aria-label="$t('gwa.alt.common.wa_label_4', { var1 : 0 })"><span class="blind dv-pc-only">{{ $t('gwa.alt.common.wa_label_4', { var1 : 0 }) }}</span></span></span>
                                                                            </label>
                                                                        </span>
                                                                    </li>
                                                                </ul>
                                                            </fieldset>
                                                            <div class="ratings-btn">
                                                                <button @click="goEstimate()" type="button" class="btn btn-type8" :class="estimatePopup" :title="$t('gwa.alt.common.wa_title_30', { var1 : item.appName })" aria-controls="popupStarRating" aria-haspopup="true"><span>{{ $t("sdp.store.message.starscorerating") }}</span></button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- //만족도평가 -->
                                                </div>
                                                <!-- //RAINGS -->
                                            </div>
                                            <!-- //탭내용1 -->
                                            <!-- 탭내용2 -->
                                            <div id="tabViewCont2" class="tab-content" aria-hidden="true">
                                                <p class="blind dv-pc-only">{{ $t('sdp.store.message.devicecompatibility') }}</p>
                                                <!-- 호환기기 전체영역 -->
                                                <!-- 고도화 ver1 : 로그인전, 후 클래스 적용 -->
                                                <div class="compatible-wrap" :class="isLoginYn"><!-- 로그인전 : is-loginBefore, 로그인후 : is-loginAfter -->
                                                    <!-- 로그인확인 -->
                                                    <div class="compatible-container">
                                                        <!-- 로그인전 -->
                                                        <div class="login-before">
                                                            <div class="compatible-header" v-html="$t('sdp.store.message.devicecompatibility_login')"></div>
                                                            <div class="compatible-body">
                                                                <div class="inner">
                                                                    <i class="ico ico-sd-1" aria-hidden="true"></i>
                                                                    <div class="para-wrap" v-html="$t('sdp.store.message.devicecompatibility_logindetail')"></div>
                                                                </div>
                                                            </div>
                                                            <div class="compatible-footer">
                                                                <button @click="goLgaccount()" type="button" class="btn btn-type8"><span>{{ $t('sdp.menu.gnb.lgaccount') }}</span></button>
                                                            </div>
                                                        </div>
                                                        <!-- //로그인전 -->

                                                        <!-- 로그인후 -->
                                                        <div v-if="appMyDvcCompatibility == 'ACT_DVC'" class="login-after">
                                                            <div class="compatible-header" v-html="$t('sdp.store.message.devicecompatibility_noact')"></div>
                                                            <div class="compatible-body">
                                                                <div class="inner">
                                                                    <i class="ico ico-sd-2" aria-hidden="true"></i>
                                                                    <div class="para-wrap" v-html="$t('sdp.store.message.devicecompatibility_noactdetail')">
                                                                        <!--<p class="para">고객님의 디바이스에서 <em class="color-primary">동일한 ID</em>로 로그인하신 이력이 있는 경우에만,<br>실행 기능 여부를 확인하실 수 있습니다.</p>
                                                                        <p class="para">고객님의 디바이스에서 <em class="color-primary">로그인</em> 후, 재확인 해주세요.</p>-->
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div v-else-if="appMyDvcCompatibility == 'Y'" class="login-after">
                                                            <div class="compatible-header"></div>
                                                            <div class="compatible-body">
                                                                <div class="inner">
                                                                    <i class="ico ico-sd-4" aria-hidden="true"></i>
                                                                    <div class="para-wrap" v-html="$t('sdp.store.message.devicecompatibility_y')"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div v-else-if="appMyDvcCompatibility == 'Y2'" class="login-after">
                                                            <template v-if="diffOwnedDvcUseDvcYn == 'Y'">
                                                                <div v-if="appUseModelName == 'Unknown'" class="compatible-header" v-html="$t('sdp.store.message.devicecompatibility_y2')"></div>
                                                                <div v-else class="compatible-header" v-html="$t('sdp.store.message.devicecompatibility_y2_in1', { var1 : appUseModelName })"></div>
                                                            </template>
                                                            <template v-else>
                                                                <div class="compatible-header" v-html="$t('sdp.store.message.devicecompatibility_y2')"></div>
                                                            </template>
                                                            <div class="compatible-body">
                                                                <div class="inner">
                                                                    <i class="ico ico-sd-5" aria-hidden="true"></i>
                                                                    <template v-if="diffOwnedDvcUseDvcYn == 'Y'">
                                                                        <div v-if="appUseModelName == 'Unknown'" class="para-wrap" v-html="$t('sdp.store.message.devicecompatibility_y2detail')">
                                                                            {{ $t("sdp.store.message.devicecompatibility_y2detail") }}
                                                                        </div>
                                                                        <div v-else class="para-wrap" v-html="$t('sdp.store.message.devicecompatibility_y2_in1detail', { var1 : appUseModelName })"></div>
                                                                    </template>
                                                                    <template v-else>
                                                                        <div class="para-wrap" v-html="$t('sdp.store.message.devicecompatibility_y2detail')"></div>
                                                                    </template>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div v-else class="login-after">
                                                            <div class="compatible-header"></div>
                                                            <div class="compatible-body">
                                                                <div class="inner">
                                                                    <i class="ico ico-sd-3" aria-hidden="true"></i>
                                                                    <div class="para-wrap" v-html="$t('sdp.store.message.devicecompatibility_n')"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- //로그인후 -->
                                                    </div>
                                                    <!-- //로그인확인 -->

                                                    <!-- 호환정보 -->
                                                    <div class="compatible-area">
                                                    </div>
                                                    <!-- //호환정보 -->
                                                </div>
                                                <!-- //호환기기 전체영역 -->
                                            </div>
                                            <!-- //탭내용2 -->
                                        </div>
                                    </div>
                                </div>
                                <!-- //상세정보 -->
                            </div>
                            <!-- //앱상세 전체영역 -->

                            <!-- 앱상세 버튼영역 -->
                            <div class="view-app-btn">
                                <button @click="goTvapp()" type="button" class="btn btn-type1" :title="$t('gwa.alt.common.wa_label_24')"><span>{{ $t("sdp.support.message.listview") }}</span></button>
                            </div>
                            <!-- //앱상세 버튼영역 -->
                        </div>
                    </section>
                    <!-- //상세섹션 -->

                    <!-- 미등록게시물 -->
                    <div class="noData-wrap" v-if="prodInfo.length == 0">
                        <div class="noData">
                            <div class="inner">
                                <p><i class="ico ico-waring2"></i><span class="noData-txt">No Application Contents</span></p>
                            </div>
                        </div>
                    </div>
                    <!-- //미등록게시물 -->

                    <!-- 관련정보 -->
                    <div class="box-wrap box-relateMenu">
                        <div class="box">
                            <div class="box-header">
                                <p class="para">{{ $t('sdp.self.message.title2') }}</p>
                            </div>
                            <div class="box-body">
                                <div class="grid grid-divieder">
                                    <div class="col col-6">
                                        <router-link to="/main/inquiry/register" tag="a" v-show="loginYn" href="javascript:;" class="relate-link">
                                            <span class="ico-area" aria-hidden="true"><i class="ico ico-ques"></i></span>
                                            <dl>
                                                <dt class="tit">{{ $t('sdp.store.message.quickmenu1') }}</dt>
                                                <dd class="txt" v-html="$t('sdp.support.message.new.qna4')"></dd>
                                            </dl>
                                        </router-link>
                                        <a v-show="!loginYn" href="javascript:;" class="relate-link popup-open" aria-controls="popupConfirm" aria-haspopup="true">
                                            <span class="ico-area" aria-hidden="true"><i class="ico ico-ques"></i></span>
                                            <dl>
                                                <dt class="tit">{{ $t('sdp.store.message.quickmenu1') }}</dt>
                                                <dd class="txt" v-html="$t('sdp.support.message.new.qna4')"></dd>
                                            </dl>
                                        </a>
                                    </div>
                                    <div class="col col-6">
                                        <router-link to="/main/faq?catCode1=1004" tag="a" href="javascript:;" class="relate-link">
                                            <span class="ico-area" aria-hidden="true"><i class="ico ico-faq"></i></span>
                                            <dl>
                                                <dt class="tit">{{ $t('sdp.store.message.quickmenu2') }}</dt>
                                                <dd class="txt" v-html="$t('sdp.faq.message.title')"></dd>
                                            </dl>
                                        </router-link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- //관련정보 -->
                </div>
            </div>
            <!-- //탭메뉴 -->

            <!-- ScreenShot Zommer -->
            <div class="zommer-wrap" onclick="zommer.close(this)">
                <span class="zommer-body">
                    <img src="" class="zommer-img" alt="">
                    <a href="javascript:;" class="btn-ico btn-close" onclick="zommer.close(this);"><i class="ico ico-close-zommer">{{ $t('gwa.alt.common.wa_label_26') }}</i></a>
                </span>
            </div>
            <!-- //ScreenShot Zommer -->

            <!-- 팝업_별점평가 -->
            <div id="popupStarRating" class="popup-wrap" hidden>
                <div class="popup popup-type1" role="dialog" aria-labelledby="popupStarRatingTitle">
                    <div class="blind-area popup-focus dv-ios-only" role="text" :aria-label="$t('gwa.alt.common.wa_label_54')"><!-- IOS접근성 영역자체에 초점처리 --></div>
                    <div class="popup-container">
                        <div class="popup-header">
                            <h3 class="tit-h3" id="popupStarRatingTitle">{{ $t("sdp.store.message.starscorerating") }}</h3>
                        </div>
                        <div class="popup-body popup-scroll loading-wrap" style="height: 100% !important;" v-if="estimatingYn == 'Y'">
                            <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                        </div>
                        <div class="popup-body popup-scroll" v-else>
                            <div class="para-wrap align-c">
                                <p class="para color-primary">{{ getEstimateStr1 }}</p>
                                <p class="para">{{ getEstimateStr2 }}</p>
                            </div>
                        </div>
                        <div class="popup-footer">
                            <div class="btn-wrap">
                                <button type="button" class="btn btn-type2 popup-close btn-secondary" aria-controls="popupStarRating" :title="$t('gwa.alt.common.wa_title_57')"><span>{{ $t("sdp.mypage.message.confirm2") }}</span></button>
                            </div>
                        </div>
                        <button type="button" class="btn-ico btn-popup-close popup-close" aria-controls="popupStarRating" :title="$t('gwa.alt.common.wa_title_57')"><span><i class="ico ico-close2">{{ $t('gwa.alt.common.wa_label_19') }}</i></span></button>
                    </div>
                </div>
            </div>
            <!-- //팝업_별점평가 -->

            <!-- 모달팝업_문의확인 -->
            <InquiryConfirmPop></InquiryConfirmPop>
            <!-- //모달팝업_문의확인 -->

            <div id="popupTabSelect" class="popup-wrap popup-select" role="dialog">
                <div class="popup popup-tab">
                    <nav class="tab-nav tab-type1 tab-responsive">
                        <ul role="tablist">
                            <li role="presentation" :class="{'is-active' : isTabActive('')}" v-show="appCateList.length > 0">
                                <a href="javascript:;" role="tab" aria-selected="true" @click="goAllSearch()">
                                    <span class="tit">{{ $t("sdp.mypage.message.tabbuyall") }}</span>
                                </a>
                            </li>
                            <li v-for="item in appCateList" role="presentation" :class="{'is-active' : isTabActive(item.catCode)}">
                                <a href="javascript:;" role="tab" aria-selected="false" @click="goTabSearch(item.catCode, item.catName)">
                                    <span class="tit">{{ item.catName }}<em class="label-type2">{{ item.cnt }}</em></span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <button type="button" class="btn-ico btn-close-select" aria-controls="popupTabSelect"><span><i class="ico ico-close2">{{ $t('gwa.alt.common.wa_label_22') }}</i></span></button>
                </div>
            </div>
        </div>
        <!-- //Content Body -->
    </section>
    <!-- //Content -->
</template>

<script>
    import qs from "qs";
    import InquiryConfirmPop from '@/components/inquiry/InquiryConfirmPop';

    export default {
        name: "Tvapp",
        components: {
            InquiryConfirmPop
        },
        data() {
            return {
                appId: "",
                appCateList: [],
                prodInfo: [],
                appSuptLangName: "",
                screenShotList: [],
                featureList: [],
                appMyDvcCompatibility: "",
                appUseModelName: "",
                diffOwnedDvcUseDvcYn: "",
                loginYn: false,
                host: "",
                estimated: "",
                cntryCode: "",
                catCode1: "",
                moreYn: "N",
                cateYn: "N",
                loadingYn: "Y",
                estimatingYn: "N",
                starScr: "",
                estimateType: "",
                orderType: "0",
                headerName: "",
                appRankCode: "",
                sellrUsrNo: "",
                curPage: 1
            }
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            goAllSearch() {
                const r = { path : "/main/tvapp?catCode1=&moreYn=N&cateYn=N&orderType=0"
                        + "&headerName=&appRankCode=&curPage=1&detailYn=Y" };
                this.$router.push(r);
            },
            goTabSearch(catCode1, catName) {
                const r = { path : "/main/tvapp?catCode1=" + catCode1 + "&moreYn=N&cateYn=Y&orderType=0&headerName="
                        + catName + "&appRankCode=&curPage=1&detailYn=Y" };
                this.$router.push(r);
            },
            goTvapp() {
                if(this.sellrUsrNo == "") {
                    const r = { path : "/main/tvapp?catCode1=" + this.catCode1 + "&moreYn=" + this.moreYn
                            + "&cateYn=" + this.cateYn + "&orderType=" + this.orderType + "&headerName="
                            + this.headerName + "&appRankCode=" + this.appRankCode + "&curPage="
                            + this.curPage + "&detailYn=Y" };
                    this.$router.push(r);
                } else {
                    const r = { path : "/main/tvapp/seller?sellrUsrNo=" + this.sellrUsrNo
                            + "&curPage=" + this.curPage };
                    this.$router.push(r);
                }
            },
            goEstimate() {
                const vm = this;

                if(vm.loginYn) {
                    vm.goEstimateAjax();
                } else {
                    vm.goLgaccount();
                }
            },
            goEstimateAjax() {
                const vm = this;
                vm.estimateType = "";

                if(vm.starScr != "") {
                    ui.loading.open();
                    vm.estimatingYn = "Y";

                    const params = {
                        appId: vm.appId,
                        starScr: vm.starScr
                    };

                    this.$axios.post("/api/tvapp/createProductEstimate.ajax",
                        qs.stringify(params)).then((result) => {
                        ui.loading.close();
                        vm.estimateType = result.data.estimateType;
                        vm.estimatingYn = "N";
                        /*vm.$nextTick(function() {
                            ui.init();
                        });*/
                    }).catch((err) => {
                        ui.loading.close();
                        vm.estimatingYn = "N";
                        alert("error : " + err);
                    });
                } else {
                    vm.estimateType = "NOSTAR";
                    vm.estimatingYn = "N";
                }
            },
            setProdInfoResult(result) {
                const vm = this;

                vm.prodInfo = result.data.prodInfo;
                vm.appSuptLangName = result.data.appSuptLangName;
                vm.screenShotList = result.data.screenShotList;
                vm.featureList = result.data.featureList;
                vm.appMyDvcCompatibility = result.data.appMyDvcCompatibility;
                vm.appUseModelName = result.data.appUseModelName;
                vm.diffOwnedDvcUseDvcYn = result.data.diffOwnedDvcUseDvcYn;
                vm.host = result.data.input.host;
                vm.estimated = result.data.input.estimated;
                vm.cntryCode = result.data.input.cntryCode;
                vm.loadingYn = "N";

                vm.$nextTick(function() {
                    ui.init();
                    loadSelected();
                });
            },
            goLgaccount() {
                const vm = this;

                var _params = {
                    appId: vm.appId,
                    catCode1: vm.catCode1,
                    moreYn: vm.moreYn,
                    cateYn: vm.cateYn,
                    orderType: vm.orderType,
                    headerName: vm.headerName,
                    appRankCode: vm.appRankCode,
                    sellrUsrNo: vm.sellrUsrNo,
                    curPage: vm.curPage
                };
                
                const params = {
                    cntryCode: _domainCntryCode,
                    path: 'tvapp/detail?' + qs.stringify(_params)
                };

                this.$axios.post('/api/main/retrieveLoginInfo.ajax',
                    qs.stringify(params)).then((result) => {
                    var loginUrl = result.data.loginUrl;
                    window.location = loginUrl;
                }).catch((err) => {
                    alert(err);
                });
            },
            appStar(avgSscr) {
                if (avgSscr >= 9.5) {
                    return 5;
                } else if (avgSscr >= 8.5) {
                    return 4.5;
                } else if (avgSscr >= 7.5) {
                    return 4;
                } else if (avgSscr >= 6.5) {
                    return 3.5;
                } else if (avgSscr >= 5.5) {
                    return 3;
                } else if (avgSscr >= 4.5) {
                    return 2.5;
                } else if (avgSscr >= 3.5) {
                    return 2;
                } else if (avgSscr >= 2.5) {
                    return 1.5;
                } else if (avgSscr >= 1.5) {
                    return 1;
                } else if (avgSscr >= 0.5) {
                    return 0.5;
                } else {
                    return 0;
                }
            },
            fileSizeReplace(size) {
                if(this.cntryCode == "DE") {
                    return size.replace(".", ",");
                } else {
                    return size;
                }
            },
            lineBreakCntt(cntt) {
                if(cntt != null && cntt != "") {
                    return cntt.split("\n").join("<br />");
                } else {
                    return "";
                }
            },
            isTabActive(catCode1) {
                if(this.catCode1 == catCode1) {
                    return true;
                } else {
                    return false;
                }
            }
        },
        computed: {
            isLoginYn: function() {
                if(this.loginYn) {
                    return "is-loginAfter";
                } else {
                    return "is-loginBefore";
                }
            },
            estimatePopup: function() {
                if(this.loginYn) {
                    return "popup-open";
                } else {
                    return "";
                }
            },
            getEstimateStr1: function() {
                if(this.estimateType == "SUCCESS") {
                    return this.$t("sdp.store.message.sucestimate");
                } else if(this.estimateType == "NOBUY") {
                    return this.$t("sdp.store.message.estimatenonbuy1");
                } else if(this.estimateType == "ALREADY") {
                    return this.$t("sdp.store.message.alreadyestimate");
                } else if(this.estimateType == "ERROR") {
                    return this.$t("sdp.store.message.errestimate");
                } else if(this.estimateType == "NOSTAR") {
                    $('#popupStarRating').attr({'data-for':'sRadioStar5'});
                    return this.$t("sdp.store.message.choosestar"); //평점입력을 안한경우
                } else if(this.estimateType == "LOGIN") {
                    return this.$t("sdp.err.cm.authentication"); // 로그인이 풀린 경우
                } else {
                    return "";
                }
            },
            getEstimateStr2: function() {
                if(this.estimateType == "NOBUY") {
                    return this.$t("sdp.store.message.estimatenonbuy2");
                } else {
                    return "";
                }
            }
        },
        mounted() {
            const vm = this;
            ui.loading.open();

            vm.appId = vm.$route.query.appId;
            vm.catCode1 = vm.$route.query.catCode1;
            vm.moreYn = vm.$route.query.moreYn;
            vm.cateYn = vm.$route.query.cateYn;
            vm.orderType = vm.$route.query.orderType;
            vm.headerName = vm.$route.query.headerName;
            vm.appRankCode = vm.$route.query.appRankCode;
            vm.sellrUsrNo = vm.$route.query.sellrUsrNo;

            if(vm.$route.query.curPage != null && vm.$route.query.curPage != "") {
                vm.curPage = vm.$route.query.curPage;
            }

            const params = {
                appId: vm.appId
            };

            this.$axios.post("/api/tvapp/retrieveAppInfo.ajax",
                qs.stringify(params)).then((result) => {
                ui.loading.close();

                vm.appCateList = result.data.appCateList;
                vm.loginYn = result.data.loginYn;

                if(result.data.prodInfo != null) {
                    vm.setProdInfoResult(result);
                } else {
                    vm.loadingYn = "N";
                    vm.$nextTick(function() {
                        ui.init();
                    });
                }
            }).catch((err) => {
                vm.$nextTick(function() {
                    ui.loading.close();
                    vm.loadingYn = "N";
                });
                alert("error : " + err);
            });
        }
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
