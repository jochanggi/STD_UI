<template>
    <!-- content -->
    <section id="content" class="content tvapp-cont">
        <!-- content Header -->
        <div class="content-header sub-visual">
            <div class="sub-visual-bg"></div>
            <div class="in-sec">
                <div class="tit-wrap centered-c">
                    <h2 class="tit-h2">{{ $t('sdp.menu.gnb.tvapp') }}</h2>
                </div>
            </div>
        </div>
        <!-- //content Header -->

        <!-- content Body -->
        <div class="content-body">
            <!-- 검색메뉴 -->
            <div class="tab-type1-wrap in-sec">
                <nav class="tab-nav tab-type1 tab-responsive">
                    <ul role="tablist">
                        <li role="presentation" :class="{'is-active' : isTabActive('')}" v-show="appCateList.length > 0">
                            <a href="javascript:;" role="tab" aria-selected="true" @click="goAllSearch()">
                                <span class="tit">{{ $t("sdp.mypage.message.tabbuyall") }}</span>
                            </a>
                        </li>
                        <li v-for="item in appCateList" role="presentation" :class="{'is-active' : isTabActive(item.catCode)}">
                            <a href="javascript:;" role="tab" aria-selected="false" @click="goTabSearch(item.catCode, item.catName)">
                                <span class="tit">{{ item.catName }}<em class="label-type2">{{ item.cnt }}</em></span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="tab-body">
                    <!-- 앱목록 전체영역 -->
                    <section v-if="moreYn == 'N' && cateYn == 'N'" class="section section-category">
                        <div class="section-header">
                            <div class="inner">
                                <h3 class="tit-h3">{{ headerName }} | Hot Apps</h3>
                            </div>
                        </div>
                        <div class="section-body" v-if="loadingYn == 'Y'">
                            <div class="loading-wrap">
                                <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                            </div>
                        </div>
                        <div class="section-body" v-else>
                            <div class="app-lists-wrap">
                                <div class="app-lists" data-type="image" v-if="hotAppList.length > 0">
                                    <ul>
                                        <li v-for="item in hotAppList">
                                            <div class="item-wrap">
                                                <p v-if="item.age >= 18 && userAge < 18" class="item-thumb thumbnail"><a href="javascript:;" class="more-focus popup-open" :title="$t('gwa.alt.common.wa_title_33')" @click="setAdultAppName(item.appName, item.appId)" aria-controls="popupInfoGuide" aria-haspopup="true"><img :src="item.appPath" :alt="$t('gwa.alt.tvapp.wa_etc_1', { var1 : item.appName })" onerror="imageResize.reset(this)" /></a></p>
                                                <p v-else class="item-thumb thumbnail"><a href="javascript:;" class="more-focus" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(item.appId)"><img :src="item.appPath" :alt="$t('gwa.alt.tvapp.wa_etc_1', { var1 : item.appName })" onerror="imageResize.reset(this)" /></a></p>
                                                <p v-if="item.age >= 18 && userAge < 18" class="item-tit"><a href="javascript:;" class="popup-open" :title="$t('gwa.alt.common.wa_title_33')" @click="setAdultAppName(item.appName, item.appId)" aria-controls="popupInfoGuide" aria-haspopup="true"><strong>{{ item.appName }}</strong></a></p>
                                                <p v-else class="item-tit"><a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(item.appId)"><strong>{{ item.appName }}</strong></a></p>
                                                <p class="item-part" role="text" :aria-label="$t('gwa.alt.tvapp.wa_label_1', { var1 : item.catName })">{{ item.catName }}</p>
                                                <p class="item-txt"><a href="javascript:;" :title="$t('gwa.alt.tvapp.wa_title_1')" @click="goTvappSeller(item.sellrUsrNo)" class="tracking app_list seller" :aria-label="$t('gwa.alt.tvapp.wa_label_2', { var1 : item.sellrUsrName })">{{ item.sellrUsrName }}</a></p>
                                                <div class="item-star">
                                                    <div class="js starRating-label" role="text" aria-valuemax="5" aria-valuemin="0" :aria-valuenow="appStar(item.avgSscr)" :aria-label="$t('gwa.alt.tvapp.wa_label_3', { var1 : appStar(item.avgSscr) })">
                                                        <span class="blind dv-pc-only">{{ $t('gwa.alt.tvapp.wa_label_3', {var1 : appStar(item.avgSscr)}) }}</span>
                                                        <span class="rating"><span class="rating-max"></span><span class="rating-now"></span></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- 미등록게시물 -->
                                <div class="noData-wrap" v-else>
                                    <div class="noData">
                                        <div class="inner">
                                            <p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- //미등록게시물 -->
                            </div>
                        </div>
                        <a v-show="loadingYn == 'N' && hotAppList.length > 0" @click="goMoreSearch('1')" href="javascript:;" class="btn btn-more" role="button" :title="$t('gwa.alt.common.wa_title_27')">{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-cate"></i></a>
                    </section>

                    <section v-if="moreYn == 'N' && cateYn == 'N'" class="section section-category">
                        <div class="section-header">
                            <div class="inner">
                                <h3 class="tit-h3">{{ headerName }} | New Apps</h3>
                            </div>
                        </div>
                        <div class="section-body" v-if="loadingYn == 'Y'">
                            <div class="loading-wrap">
                                <div class="loading"><img src="/img/cmn/loading.png" alt="로딩중"></div>
                            </div>
                        </div>
                        <div class="section-body" v-else>
                            <div class="app-lists-wrap">
                                <div class="app-lists" data-type="image" v-if="newAppList.length > 0">
                                    <ul>
                                        <li v-for="item in newAppList">
                                            <div class="item-wrap">
                                                <p v-if="item.age >= 18 && userAge < 18" class="item-thumb thumbnail"><a href="javascript:;" class="more-focus popup-open" :title="$t('gwa.alt.common.wa_title_33')" @click="setAdultAppName(item.appName, item.appId)" aria-controls="popupInfoGuide" aria-haspopup="true"><img :src="item.appPath" :alt="$t('gwa.alt.tvapp.wa_etc_1', { var1 : item.appName })" onerror="imageResize.reset(this)" /></a></p>
                                                <p v-else class="item-thumb thumbnail"><a href="javascript:;" class="more-focus" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(item.appId)"><img :src="item.appPath" :alt="$t('gwa.alt.tvapp.wa_etc_1', { var1 : item.appName })" onerror="imageResize.reset(this)" /></a></p>
                                                <p v-if="item.age >= 18 && userAge < 18" class="item-tit"><a href="javascript:;" class="popup-open" :title="$t('gwa.alt.common.wa_title_33')" @click="setAdultAppName(item.appName, item.appId)" aria-controls="popupInfoGuide" aria-haspopup="true"><strong>{{ item.appName }}</strong></a></p>
                                                <p v-else class="item-tit"><a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(item.appId)"><strong>{{ item.appName }}</strong></a></p>
                                                <p class="item-part" role="text" :aria-label="$t('gwa.alt.tvapp.wa_label_1', { var1 : item.catName })">{{ item.catName }}</p>
                                                <p class="item-txt"><a href="javascript:;" :title="$t('gwa.alt.tvapp.wa_title_1')" @click="goTvappSeller(item.sellrUsrNo)" class="tracking app_list seller" :aria-label="$t('gwa.alt.tvapp.wa_label_2', { var1 : item.sellrUsrName })">{{ item.sellrUsrName }}</a></p>
                                                <div class="item-star">
                                                    <div class="js starRating-label" role="text" aria-valuemax="5" aria-valuemin="0" :aria-valuenow="appStar(item.avgSscr)" :aria-label="$t('gwa.alt.tvapp.wa_label_3', { var1 : appStar(item.avgSscr) })">
                                                        <span class="blind dv-pc-only">{{ $t('gwa.alt.tvapp.wa_label_3', {var1 : appStar(item.avgSscr)}) }}</span>
                                                        <span class="rating"><span class="rating-max"></span><span class="rating-now"></span></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- 미등록게시물 -->
                                <div class="noData-wrap" v-else>
                                    <div class="noData">
                                        <div class="inner">
                                            <p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- //미등록게시물 -->
                            </div>
                        </div>
                        <a v-show="loadingYn == 'N' && newAppList.length > 0" @click="goMoreSearch('2')" href="javascript:;" class="btn btn-more" role="button" :title="$t('gwa.alt.common.wa_title_28')">{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-cate"></i></a>
                    </section>

                    <section v-if="moreYn == 'N' && cateYn == 'N'" class="section section-category">
                        <div class="section-header">
                            <div class="inner">
                                <h3 class="tit-h3">{{ headerName }} | All Apps</h3>
                            </div>
                        </div>
                        <div class="section-body" v-if="loadingYn == 'Y'">
                            <div class="loading-wrap">
                                <div class="loading"><img src="/img/cmn/loading.png" alt="로딩중"></div>
                            </div>
                        </div>
                        <div class="section-body" v-else>
                            <div class="app-lists-wrap">
                                <div class="app-lists" data-type="image" v-if="allAppList.length > 0">
                                    <ul>
                                        <li v-for="item in allAppList">
                                            <div class="item-wrap">
                                                <p v-if="item.age >= 18 && userAge < 18" class="item-thumb thumbnail"><a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" class="more-focus popup-open" @click="setAdultAppName(item.appName, item.appId)" aria-controls="popupInfoGuide" aria-haspopup="true"><img :src="item.appPath" :alt="$t('gwa.alt.tvapp.wa_etc_1', { var1 : item.appName })" onerror="imageResize.reset(this)" /></a></p>
                                                <p v-else class="item-thumb thumbnail"><a href="javascript:;" class="more-focus" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(item.appId)"><img :src="item.appPath" :alt="$t('gwa.alt.tvapp.wa_etc_1', { var1 : item.appName })" onerror="imageResize.reset(this)" /></a></p>
                                                <p v-if="item.age >= 18 && userAge < 18" class="item-tit"><a href="javascript:;" class="popup-open" :title="$t('gwa.alt.common.wa_title_33')" @click="setAdultAppName(item.appName, item.appId)" aria-controls="popupInfoGuide" aria-haspopup="true"><strong>{{ item.appName }}</strong></a></p>
                                                <p v-else class="item-tit"><a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(item.appId)"><strong>{{ item.appName }}</strong></a></p>
                                                <p class="item-part" role="text" :aria-label="$t('gwa.alt.tvapp.wa_label_1', { var1 : item.catName })">{{ item.catName }}</p>
                                                <p class="item-txt"><a href="javascript:;" :title="$t('gwa.alt.tvapp.wa_title_1')" @click="goTvappSeller(item.sellrUsrNo)" class="tracking app_list seller" :aria-label="$t('gwa.alt.tvapp.wa_label_2', { var1 : item.sellrUsrName })">{{ item.sellrUsrName }}</a></p>
                                                <div class="item-star">
                                                    <div class="js starRating-label" role="text" aria-valuemax="5" aria-valuemin="0" :aria-valuenow="appStar(item.avgSscr)" :aria-label="$t('gwa.alt.tvapp.wa_label_3', { var1 : appStar(item.avgSscr) })">
                                                        <span class="blind dv-pc-only">{{ $t('gwa.alt.tvapp.wa_label_3', {var1 : appStar(item.avgSscr)}) }}</span>
                                                        <span class="rating"><span class="rating-max"></span><span class="rating-now"></span></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- 미등록게시물 -->
                                <div class="noData-wrap" v-else>
                                    <div class="noData">
                                        <div class="inner">
                                            <p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- //미등록게시물 -->
                            </div>
                        </div>
                        <a v-show="loadingYn == 'N' && allAppList.length > 0" @click="goMoreSearch('')" href="javascript:;" class="btn btn-more" role="button" :title="$t('gwa.alt.common.wa_title_29')">{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-cate"></i></a>
                    </section>

					<!-- 고도화 ver2 : 클래스 has-search 추가 -->
					<!-- 고도화 ver2 : 속성 title="정렬순서" 추가 -->
					<!-- 고도화 ver2 : 속성 aria-label 목록보기 수정 -->
                    <section v-if="moreYn == 'Y' || cateYn == 'Y'" class="section section-category">
                        <div class="section-header has-search">
                            <div class="inner">
                                <h3 class="tit-h3" v-if="moreYn == 'Y'">{{ headerName }} | {{ $t(appType) }}</h3>
                                <h3 class="tit-h3" v-else>{{ headerName }}</h3>
                                <!-- 검색영역 -->
                                <div v-show="loadingYn == 'N'" class="search-tvapp-wrap" role="search">
                                    <div class="search-select">
                                        <fieldset>
                                            <legend>{{ $t("gwa.alt.tvapp.wa_etc_2") }}</legend>
                                            <div class="search-form">
												<span class="form-select">
													<select @change="goOrderSearch()" v-model="orderType" :title="$t('gwa.alt.common.wa_title_32')">
														<option value="0" selected>{{ $t("sdp.store.search.category_text5") }}</option>
														<option value="1">{{ $t("sdp.store.search.category_text2") }}</option>
														<option value="2">{{ $t("sdp.store.search.category_text3") }}</option>
														<option value="3">{{ $t("sdp.store.search.category_text4") }}</option>
														<option value="4">{{ $t("sdp.store.search.category_text1") }}</option>
													</select>
												</span>
                                                <button @click="goOrderSearch()" type="button" class="btn-ico btn-search"><span><i class="ico ico-search2">{{ $t('gwa.alt.common.wa_label_27', { var1 : headerName }) }}</i></span></button>
                                            </div>
                                        </fieldset>
                                    </div>
                                    <div class="btn-group">
                                        <button @click="setGridYn('Y')" type="button" class="btn-ico btn-searchGrid" :class="{'is-on' : isGridOn()}" aria-controls="tvAppWrap" aria-selected="true" aria-expanded="true" data-type="image" data-target="app-lists"><span><i class="ico ico-list1">{{ $t('gwa.alt.common.wa_label_29') }}</i></span></button>
                                        <button @click="setGridYn('N')" type="button" class="btn-ico btn-searchGrid" :class="{'is-on' : isListOn()}" aria-controls="tvAppWrap" aria-selected="false" aria-expanded="false" data-type="list" data-target="app-lists"><span><i class="ico ico-list2">{{ $t('gwa.alt.common.wa_label_30') }}</i></span></button>
                                    </div>
                                </div>
                                <!-- //검색영역 -->
                            </div>
                        </div>
                        <div class="section-body" v-if="loadingYn == 'Y'">
                            <div class="loading-wrap">
                                <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                            </div>
                        </div>
                        <div class="section-body" v-else>
                            <div id="tvAppWrap" class="app-lists-wrap">
                                <div class="app-lists" :data-type="setDataType" v-if="appList.length > 0">
                                    <ul>
                                        <li v-for="item in appList">
                                            <div class="item-wrap">
                                                <p v-if="item.age >= 18 && userAge < 18" class="item-thumb thumbnail"><a href="javascript:;" class="more-focus popup-open" :title="$t('gwa.alt.common.wa_title_33')" @click="setAdultAppName(item.appName, item.appId)" aria-controls="popupInfoGuide" aria-haspopup="true"><img :src="item.appPath" :alt="$t('gwa.alt.tvapp.wa_etc_1', { var1 : item.appName })" onerror="imageResize.reset(this)" /></a></p>
                                                <p v-else class="item-thumb thumbnail"><a href="javascript:;" class="more-focus" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(item.appId)"><img :src="item.appPath" :alt="$t('gwa.alt.tvapp.wa_etc_1', { var1 : item.appName })" onerror="imageResize.reset(this)" /></a></p>
                                                <p v-if="item.age >= 18 && userAge < 18" class="item-tit"><a href="javascript:;" class="popup-open" :title="$t('gwa.alt.common.wa_title_33')" @click="setAdultAppName(item.appName, item.appId)" aria-controls="popupInfoGuide" aria-haspopup="true"><strong>{{ item.appName }}</strong></a></p>
                                                <p v-else class="item-tit"><a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(item.appId)"><strong>{{ item.appName }}</strong></a></p>
                                                <p class="item-part" role="text" :aria-label="$t('gwa.alt.tvapp.wa_label_1', { var1 : item.catName })">{{ item.catName }}</p>
                                                <p class="item-txt"><a href="javascript:;" :title="$t('gwa.alt.tvapp.wa_title_1')" @click="goTvappSeller(item.sellrUsrNo)" class="tracking app_list seller" :aria-label="$t('gwa.alt.tvapp.wa_label_2', { var1 : item.sellrUsrName })">{{ item.sellrUsrName }}</a></p>
                                                <div class="item-star">
                                                    <div class="js starRating-label" role="text" aria-valuemax="5" aria-valuemin="0" :aria-valuenow="appStar(item.avgSscr)" :aria-label="$t('gwa.alt.tvapp.wa_label_3', { var1 : appStar(item.avgSscr) })">
                                                        <span class="blind dv-pc-only">{{ $t('gwa.alt.tvapp.wa_label_3', {var1 : appStar(item.avgSscr)}) }}</span>
                                                        <span class="rating"><span class="rating-max"></span><span class="rating-now"></span></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- 미등록게시물 -->
                                <div class="noData-wrap" v-else>
                                    <div class="noData">
                                        <div class="inner">
                                            <p><i class="ico ico-waring2" aria-hidden="true"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- //미등록게시물 -->
                                <!-- 고도화 ver2 : 속성 aria-label 문구수정 -->
                                <template v-if="appList.length > 0">
                                    <div class="loading-wrap" v-if="pagingYn == 'Y'">
                                        <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                                    </div>
                                    <div class="btn-more-wrap" v-else>
                                        <button @click="goNextPage()" type="button" class="btn btn-type9 more-trigger" :aria-label="$t('gwa.alt.common.wa_label_35')+' : '+$t('gwa.alt.common.wa_label_49', { var1 : calTotalPage(), var2 : paging.curPage })"><span>{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-tvapp"></i><em class="label-page">{{ paging.curPage }}/{{ calTotalPage() }}</em></span></button>
                                        <!--<button type="button" class="btn-ico"><span><i class="ico ico-more-tvapp"></i></span></button>-->
                                    </div>
                                </template>
                            </div>
                        </div>
                    </section>
                    <!-- 앱목록 전체영역 -->
                </div>
            </div>
            <!-- //검색메뉴 -->

            <!-- 팝업_APP이용안내 -->
            <div id="popupInfoGuide" class="popup-wrap" hidden>
                <div class="popup popup-type1" role="dialog" aria-labelledby="popupInfoGuideTitle">
                    <div class="blind-area popup-focus dv-ios-only" role="text" :aria-label="$t('gwa.alt.common.wa_label_55')"><!-- IOS접근성 영역자체에 초점처리 --></div>
                    <div class="popup-container">
                        <div class="popup-header">
                            <h3 class="tit-h3" id="popupInfoGuideTitle">APP {{ $t("sdp.menu.overview") }}</h3>
                        </div>
                        <div class="popup-body popup-scroll">
                            <div class="para-wrap align-c">
                                <p class="para color-primary" v-html="$t('sdp.store.message.minorsapp')"></p>
                                <p class="para" v-html="$t('sdp.store.minorsapp.detailinfo', { var1 : adultAppName })"></p>
                            </div>
                        </div>
                        <div class="popup-footer">
                            <div class="btn-wrap">
                                <button @click="goLgaccount('N')" type="button" class="btn btn-type2 btn-primary"><span>{{ $t("sdp.menu.join_member") }}</span></button>
                                <button @click="goLgaccount('Y')" type="button" class="btn btn-type2 btn-primary"><span>{{ $t("sdp.menu.gnb.lgaccount") }}</span></button>
                                <button type="button" class="btn btn-type2 btn-secondary popup-close" aria-controls="popupInfoGuide" :title="$t('gwa.alt.common.wa_title_58')"><span>{{ $t("sdp.message.layerpopup.close") }}</span></button>
                            </div>
                        </div>
                        <button type="button" class="btn-ico btn-popup-close popup-close" aria-controls="popupInfoGuide" :title="$t('gwa.alt.common.wa_title_58')"><span><i class="ico ico-close2">{{ $t('gwa.alt.common.wa_label_19') }}</i></span></button>
                    </div>
                </div>
            </div>
            <!-- //팝업_APP 이용안내 -->

            <div id="popupTabSelect" class="popup-wrap popup-select" role="dialog">
                <div class="popup popup-tab">
                    <nav class="tab-nav tab-type1 tab-responsive">
                        <ul role="tablist">
                            <li role="presentation" :class="{'is-active' : isTabActive('')}" v-show="appCateList.length > 0">
                                <a href="javascript:;" role="tab" aria-selected="true" @click="goAllSearch()">
                                    <span class="tit">{{ $t("sdp.mypage.message.tabbuyall") }}</span>
                                </a>
                            </li>
                            <li v-for="item in appCateList" role="presentation" :class="{'is-active' : isTabActive(item.catCode)}">
                                <a href="javascript:;" role="tab" aria-selected="false" @click="goTabSearch(item.catCode, item.catName)">
                                    <span class="tit">{{ item.catName }}<em class="label-type2">{{ item.cnt }}</em></span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <button type="button" class="btn-ico btn-close-select" aria-controls="popupTabSelect"><span><i class="ico ico-close2">{{ $t('gwa.alt.common.wa_label_22') }}</i></span></button>
                </div>
            </div>
        </div>
        <!-- //content Body -->
    </section>
    <!-- //content -->
</template>

<script>
    import qs from "qs";

    export default {
        name: "Tvapp",
        data() {
            return {
                appList: [],
                hotAppList: [],
                newAppList: [],
                allAppList: [],
                appCateList: [],
                userAge: 0,
                catCode1: "",
                moreYn: "N",
                cateYn: "N",
                orderType: "0",
                headerName: "",
                appRankCode: "",
                appType: "",
                adultAppName: "",
                adultAppId: "",
                loadingYn: "Y",
                pagingYn: "N",
                gridYn: "Y",
                cntryCode: _domainCntryCode,
                paging: {
                    pageList: [],
                    totalCount: 0,
                    pageCount: 0,
                    rowCount: 0,
                    curPage: 1,
                    hasNext: false,
                    hasLast: false,
                    hasPrev: false,
                    hasFirst: false,
                    curMaxPage: 0,
                    curMinPage: 1
                },
                busy: false
            }
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            goAllSearch() {
               if(this.busy == true) {
                   return;
               }
               this.busy = true;

               const vm = this;
               vm.loadingYn = "Y";
                vm.headerName = this.$t("sdp.mypage.message.tabbuyall");

               vm.catCode1 = "";
               vm.moreYn = "N";
               vm.cateYn = "N";
               vm.orderType = "0";
               vm.hotAppList = [];
               vm.newAppList = [];
               vm.allAppList = [];
               vm.paging.rowCount = 12;
               vm.paging.curPage = 1;

               vm.goSearchAjax();
            },
            goTabSearch(catCode1, catName) {
                if(this.busy == true) {
                    return;
                }
                this.busy = true;

                const vm = this;
                vm.loadingYn = "Y";
                //vm.gridYn = "Y";

                vm.catCode1 = catCode1;
                vm.moreYn = "N";
                vm.cateYn = "Y";
                vm.orderType = "0";
                vm.headerName = catName;
                vm.appList = [];
                vm.paging.rowCount = 24;
                vm.paging.curPage = 1;

                vm.goSearchAjax();
            },
            goMoreSearch(appRankCode) {
                if(this.busy == true) {
                    return;
                }
                this.busy = true;

                const vm = this;
                vm.loadingYn = "Y";
                //vm.gridYn = "Y";
                $(window).scrollTop(0);

                vm.moreYn = "Y";
                vm.cateYn = "N";
                vm.orderType = "0";
                vm.appRankCode = appRankCode;

                vm.headerName = this.$t("sdp.mypage.message.tabbuyall");
                if(appRankCode == "1") {
                    vm.appType = "Hot Apps";
                } else if(appRankCode == "2") {
                    vm.appType = "New Apps";
                } else {
                    vm.appType = "All Apps";
                }

                vm.appList = [];
                vm.paging.rowCount = 24;
                vm.paging.curPage = 1;

                vm.goSearchAjax();
            },
            goOrderSearch() {
                if(this.busy == true) {
                    return;
                }
                this.busy = true;

                const vm = this;
                vm.loadingYn = "Y";
                //vm.gridYn = "Y";

                vm.appList = [];
                vm.paging.rowCount = 24;
                vm.paging.curPage = 1;

                vm.goSearchAjax();
            },
            goNextPage() {
                if(this.busy == true) {
                    return;
                }
                this.busy = true;

                const vm = this;
                if(vm.paging.curPage < vm.calTotalPage()) {
                    vm.pagingYn = "Y";
                    vm.paging.curPage = vm.paging.curPage + 1;
                    vm.goSearchAjax();
                } else {
                    vm.busy = false;
                }
            },
            goSearchAjax() {
                const vm = this;
                ui.loading.open();

                const params = {
                    catCode1: vm.catCode1,
                    moreYn: vm.moreYn,
                    orderType: vm.orderType,
                    appRankCode: vm.appRankCode,
                    curPage: vm.paging.curPage,
                    rowCount: vm.paging.rowCount,
                    pageCount: vm.paging.pageCount,
                    totalCount: vm.paging.totalCount
                };

                if(vm.moreYn == "Y") {
                    vm.goMoreSearchAjax(params);
                } else if(vm.cateYn == "Y") {
                    vm.goTabSearchAjax(params);
                } else {
                    vm.goAllSearchAjax(params);
                }
            },
            goAllSearchAjax(params) {
                const vm = this;
                this.$axios.post("/api/tvapp/retrieveAllAppList.ajax",
                    qs.stringify(params)).then((result) => {
                    ui.loading.close();
                    vm.hotAppList = result.data.hotAppList;
                    vm.newAppList = result.data.newAppList;
                    vm.allAppList = result.data.allAppList;
                    vm.appCateList = result.data.appCateList;
                    vm.userAge = result.data.userAge;
                    vm.catCode1 = "";
                    vm.loadingYn = "N";
                    vm.pagingYn = "N";

                    vm.setResult(result);
                    vm.$nextTick(function() {
                        ui.popup.init();
                        ui.starRating.init();
                        ui.tabFolder.init();
                        dimmer.init();
                        ui.common.title();
                        vm.busy = false;
                    });
                }).catch((err) => {
                    ui.loading.close();
                    vm.loadingYn = "N";
                    vm.pagingYn = "N";
                    alert("error : " + err);
                    vm.busy = false;
                });
            },
            goTabSearchAjax(params) {
                const vm = this;
                this.$axios.post("/api/tvapp/retrieveCateAppList.ajax",
                    qs.stringify(params)).then((result) => {
                    ui.loading.close();
                    vm.appList = result.data.appList;
                    vm.appCateList = result.data.appCateList;
                    vm.userAge = result.data.userAge;
                    vm.catCode1 = result.data.catCode1;
                    vm.loadingYn = "N";
                    vm.pagingYn = "N";

                    vm.setResult(result);
                    vm.$nextTick(function() {
                        ui.popup.init();
                        ui.starRating.init();
                        ui.listsType.init();
                        ui.moreLists.init();
                        ui.tabFolder.init();
                        dimmer.init();
                        ui.common.title();
                        vm.busy = false;
                    });
                }).catch((err) => {
                    ui.loading.close();
                    vm.loadingYn = "N";
                    vm.pagingYn = "N";
                    alert("error : " + err);
                    vm.busy = false;
                });
            },
            goMoreSearchAjax(params) {
                const vm = this;
                this.$axios.post("/api/tvapp/retrieveMoreAppList.ajax",
                    qs.stringify(params)).then((result) => {
                    ui.loading.close();
                    vm.appList = result.data.appList;
                    vm.appCateList = result.data.appCateList;
                    vm.userAge = result.data.userAge;
                    vm.catCode1 = "";
                    vm.loadingYn = "N";
                    vm.pagingYn = "N";

                    vm.setResult(result);
                    vm.$nextTick(function() {
                        ui.popup.init();
                        ui.starRating.init();
                        ui.listsType.init();
                        ui.moreLists.init();
                        ui.tabFolder.init();
                        dimmer.init();
                        ui.common.title();
                        vm.busy = false;
                    });
                }).catch((err) => {
                    ui.loading.close();
                    vm.loadingYn = "N";
                    vm.pagingYn = "N";
                    alert("error : " + err);
                    vm.busy = false;
                });
            },
            appStar(avgSscr) {
                if (avgSscr >= 9.5) {
                    return 5;
                } else if (avgSscr >= 8.5) {
                    return 4.5;
                } else if (avgSscr >= 7.5) {
                    return 4;
                } else if (avgSscr >= 6.5) {
                    return 3.5;
                } else if (avgSscr >= 5.5) {
                    return 3;
                } else if (avgSscr >= 4.5) {
                    return 2.5;
                } else if (avgSscr >= 3.5) {
                    return 2;
                } else if (avgSscr >= 2.5) {
                    return 1.5;
                } else if (avgSscr >= 1.5) {
                    return 1;
                } else if (avgSscr >= 0.5) {
                    return 0.5;
                } else {
                    return 0;
                }
            },
            goTvappDetail(appId) {
                const r = { path : "/main/tvapp/detail?appId=" + appId + "&catCode1=" + this.catCode1
                        + "&moreYn=" + this.moreYn + "&cateYn=" + this.cateYn + "&orderType=" + this.orderType
                        + "&headerName=" + this.headerName + "&appRankCode=" + this.appRankCode + "&sellrUsrNo="
                        + "&curPage=" + this.paging.curPage };
                this.$router.push(r);
            },
            goTvappSeller(sellrUsrNo) {
                const r = { path : "/main/tvapp/seller?sellrUsrNo=" + sellrUsrNo };
                this.$router.push(r);
            },
            setResult(result) {
                this.paging.totalCount = result.data.totalCount;
                this.paging.pageCount = result.data.pageCount;
                this.paging.curPage = result.data.curPage;
                this.paging.rowCount = result.data.rowCount;
            },
            calTotalPage() {
                const vm = this;
                const totalPage = parseInt(vm.paging.totalCount / vm.paging.rowCount);
                if(vm.paging.totalCount % vm.paging.rowCount == 0) {
                    return totalPage;
                } else {
                    return totalPage + 1;
                }
            },
            isTabActive(catCode1) {
                if(this.catCode1 == catCode1) {
                    return true;
                } else {
                    return false;
                }
            },
            isGridOn() {
                if(this.gridYn == "Y") {
                    return true;
                } else {
                    return false;
                }
            },
            isListOn() {
                if(this.gridYn == "Y") {
                    return false;
                } else {
                    return true;
                }
            },
            setAdultAppName(appName, appId) {
                this.adultAppName = appName;
                this.adultAppId = appId;
            },
            setGridYn(gridYn) {
                this.gridYn = gridYn;
            },
            goLgaccount(loginYn) {
                const vm = this;

                var _params = {
                    appId: vm.adultAppId,
                    catCode1: vm.catCode1,
                    moreYn: vm.moreYn,
                    cateYn: vm.cateYn,
                    orderType: vm.orderType,
                    headerName: vm.headerName,
                    appRankCode: vm.appRankCode,
                    sellrUsrNo: "",
                    curPage: vm.paging.curPage
                };

                const params = {
                    cntryCode: _domainCntryCode,
                    path: "tvapp/detail?" + qs.stringify(_params),
                    loginYn: loginYn
                };

                this.$axios.post('/api/main/retrieveLoginInfo.ajax',
                    qs.stringify(params)).then((result) => {
                    var loginUrl = result.data.loginUrl;
                    window.location = loginUrl;
                }).catch((err) => {
                    alert(err);
                });
            }
        },
        computed: {
            setDataType: function() {
                if(this.gridYn == "Y") {
                    return "image";
                } else {
                    return "list";
                }
            }
        },
        mounted() {

            // ui.searchAll.close('searchAll'); // 검색바 닫힘

            const vm = this;
            vm.loadingYn = "Y";
            vm.headerName = this.$t("sdp.mypage.message.tabbuyall");
            $(window).scrollTop(0);

            var pageCount = 10;
            var rowCount = 12;

            if(vm.$route.query.detailYn != null && vm.$route.query.detailYn != "") {
                vm.catCode1 = vm.$route.query.catCode1;
                vm.moreYn = vm.$route.query.moreYn;
                vm.cateYn = vm.$route.query.cateYn;
                vm.orderType = vm.$route.query.orderType;

                if(vm.$route.query.headerName != null && vm.$route.query.headerName != "") {
                    vm.headerName = vm.$route.query.headerName;
                }

                vm.appRankCode = vm.$route.query.appRankCode;

                vm.paging.pageCount = pageCount;
                vm.paging.curPage = vm.$route.query.curPage;

                if(vm.moreYn == "Y" && vm.cateYn == "N") {
                    vm.paging.rowCount = 24;
                    vm.headerName = this.$t("sdp.mypage.message.tabbuyall");
                    if(vm.$route.query.appRankCode == "1") {
                        vm.appType = "Hot Apps";
                    } else if(vm.$route.query.appRankCode == "2") {
                        vm.appType = "New Apps";
                    } else {
                        vm.appType = "All Apps";
                    }
                } else if(vm.moreYn == "N" && vm.cateYn == "Y") {
                    vm.paging.rowCount = 24;
                } else {
                    vm.paging.rowCount = rowCount;
                }

                vm.goSearchAjax();
            } else if(vm.$route.query.legacyAllYn != null && vm.$route.query.legacyAllYn != "") {
                vm.goMoreSearch("");
            } else {
                ui.loading.open();

                const params = {
                    moreYn: vm.moreYn,
                    curPage: 1,
                    rowCount: rowCount,
                    pageCount: pageCount,
                    totalCount: 0,
                };

                this.$axios.post("/api/tvapp/retrieveAllAppList.ajax",
                    qs.stringify(params)).then((result) => {
                    ui.loading.close();
                    vm.hotAppList = result.data.hotAppList;
                    vm.newAppList = result.data.newAppList;
                    vm.allAppList = result.data.allAppList;
                    vm.appCateList = result.data.appCateList;
                    vm.userAge = result.data.userAge;
                    vm.loadingYn = "N";

                    vm.setResult(result);
                    vm.$nextTick(function() {
                        ui.searchAll.close('searchAll');
                        ui.popup.init();
                        ui.starRating.init();
                        ui.listsType.init();
                        ui.moreLists.init();
                        ui.tabFolder.init();
                        ui.common.title();
                        dimmer.init();
                        loadSelected();
                    });
                }).catch((err) => {
                    ui.loading.close();
                    vm.loadingYn = "N";
                    alert("error : " + err);
                });
            }
        }
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
