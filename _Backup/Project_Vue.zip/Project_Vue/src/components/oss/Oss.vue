<template>
    <div id="tv-wrapper" :class="isArabiaLang">
        <div class="tv-header">
            <h1><img src="/img/support/tv_logo.png" :alt="$t('gwa.alt.oss.wa_etc_1')"></h1>
        </div>
        <div class="tv-container">
            <!-- 컨텐츠영역 -->
            <section class="tv-content">
                <div class="tv-content-header">
                    <h2 class="tv-tit-h2">{{ $t("sdp.oss.message.title") }}</h2>
                    <p class="tv-explain-h2">{{ $t("sdp.oss.message.description") }}</p>
                </div>
                <div class="tv-content-body">
                    <!-- 리스트영역 -->
                    <div class="tv-form-wrap">
                        <dl>
                            <dt><label for="cntryCode" class="bul bul-remote">{{ $t("sdp.oss.message.country") }}</label></dt>
                            <dd>
                                <span class="form-select">
                                    <select id="cntryCode" name="cntryCode" :title="$t('gwa.alt.oss.wa_title_1')" v-model="cntryCode" @change="selectCntry(cntryCode)">
                                        <option value="">-- {{ $t("sdp.oss.message.selection") }} --</option>
                                        <template v-for="(cntry) in cntryList">
                                            <option :value="cntry.code">{{ cntry.value }}</option>
                                        </template>
                                    </select>
                                </span>
                            </dd>
                        </dl>
                        <dl>
                            <dt><label for="dvcType" class="bul bul-remote">{{ $t("sdp.oss.message.deviceType") }}</label></dt>
                            <dd>
                                <span class="form-select">
                                    <select id="dvcType" name="dvcType" :title="$t('gwa.alt.oss.wa_title_2')" v-model="dvcType">
                                        <option value="">-- {{ $t("sdp.oss.message.selection") }} --</option>
                                        <template v-for="dvc in dvcTypeList">
                                            <option :value="dvc.code">{{ dvc.value }}</option>
                                        </template>
                                    </select>
                                </span>
                            </dd>
                        </dl>
                        <dl>
                            <dt><label for="svcNameList" class="bul bul-remote">{{ $t("sdp.oss.message.tvservice") }}</label></dt>
                            <dd>
                                <span class="form-select">
                                    <select id="svcNameList" :title="$t('gwa.alt.oss.wa_title_3')" :disabled="isSvcListDisabled()" v-model="svcName">
                                        <option value="">-- {{ $t("sdp.oss.message.selection") }} --</option>
                                        <template v-for="svc in svcNameList">
                                            <option>{{ svc.value }}</option>
                                        </template>
                                    </select>
                                </span>
                            </dd>
                            <dd>
                                <input type="text" id="svcName" name="svcName" class="side_input" v-model="svcOtherName" :disabled="isNameDisabled('SVC')" @blur="checkLength(svcOtherName, 'SVC')">
                            </dd>
                        </dl>
                        <dl>
                            <dt><label for="mkrNameList" class="bul bul-remote">{{ $t("sdp.oss.message.manufacturer") }}</label></dt>
                            <dd>
                                <span class="form-select">
                                    <select id="mkrNameList" name="mkrNameList" :title="$t('gwa.alt.oss.wa_title_4')" v-model="mkrName">
                                        <option value="">-- {{ $t("sdp.oss.message.selection") }} --</option>
                                        <template v-for="mkr in mkrNameList">
                                            <option>{{ mkr.value }}</option>
                                        </template>
                                    </select>
                                </span>
                            </dd>
                            <dd>
                                <input type="text" id="mkrName" name="mkrName" class="side_input" v-model="mkrOtherName" :disabled="isNameDisabled('MKR')" @blur="checkLength(mkrOtherName, 'MKR')">
                            </dd>
                        </dl>
                        <dl>
                            <dt><label for="dvcModelName" class="bul bul-remote">{{ $t("sdp.oss.message.modelname") }}</label></dt>
                            <dd><input type="text" id="dvcModelName" name="dvcModelName" :title="$t('gwa.alt.oss.wa_title_5')" v-model="dvcModel" @blur="checkLength(dvcModel, 'DVC')"></dd>
                        </dl>
                    </div>
                    <!-- //리스트영역 -->
                    <!-- 버튼영역 -->
                    <div class="tv-btn-wrap">
                        <ul>
                            <li><a href="javascript:;" class="tv_send btn" @click="registOss()">{{ $t("sdp.oss.message.send") }}</a></li>
                            <li><a href="javascript:;" class="tv_cancel btn" @click="resetForm()">{{ $t("sdp.oss.message.cancel") }}</a></li>
                        </ul>
                    </div>
                    <!-- //버튼영역 -->
                </div>
            </section>
            <!-- //컨텐츠영역 -->
        </div>
        <footer class="tv-footer">
            <p>
                <span class="form-select">
                    <select id="locale" :title="$t('gwa.alt.common.wa_label_42')" v-model="locale" @change="changeLang(locale)">
                        <option value="">Language</option>
                        <template v-for="lang in langList">
                            <option :value="lang.code">{{ lang.value }}</option>
                        </template>
                    </select>
                </span>
            </p>
        </footer>
    </div>
</template>

<script>
    import qs from "qs";

    export default {
        name: "Oss",
        data() {
            return {
                cntryList: [],
                dvcTypeList: [],
                svcNameList: [],
                mkrNameList: [],
                langList: [],
                locale: "",
                cntryCode: "",
                dvcType: "",
                svcName: "",
                svcOtherName: "",
                mkrName: "",
                mkrOtherName: "",
                dvcModel: ""
            }
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            changeLang(locale) {
                const langCode = locale.split("_")[0];
                this.$i18n.locale = langCode;
                this.resetForm();
            },
            selectCntry(cntryCode) {
                this.svcNameList = [];
                this.mkrNameList = [];

                if(cntryCode == "") {
                    this.svcName = "";
                    this.mkrName = "";
                } else {
                    this.getSvcMkrList(cntryCode);
                }
            },
            getSvcMkrList(cntryCode) {
                const vm = this;

                const params = {
                    cntryCode: cntryCode
                };

                this.$axios.post("/api/oss/retrieveSvcMkrList.ajax",
                    qs.stringify(params)).then((result) => {
                    vm.svcNameList = result.data.svcNameList;
                    vm.mkrNameList = result.data.mkrNameList;
                    vm.$nextTick(function() {
                        ui.init();
                    });
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            checkValidation() {
                const vm = this;
                console.log(vm.svcName);
                console.log(vm.mkrName);

                if(vm.cntryCode == "") {
                    return false;
                }
                if(vm.dvcType == "") {
                    return false;
                }
                if(vm.dvcType == "STB") {
                    if(vm.svcName == "") {
                        return false;
                    }
                    if(vm.svcName == "Others" && vm.svcOtherName.trim() == "") {
                        return false;
                    }
                }
                if(vm.mkrName == "") {
                    return false;
                }
                if(vm.mkrName == "Others" && vm.mkrOtherName.trim() == "") {
                    return false;
                }
                if(vm.dvcModel.trim() == "") {
                    return false;
                }

                return true;
            },
            registOss() {
                if(this.checkValidation()) {
                    this.registOssAjax();
                } else {
                    alert(this.$t("sdp.oss.message.validation1"));
                }
            },
            registOssAjax() {
                const vm = this;

                if(vm.svcName == "Others") {
                    vm.svcName = vm.svcOtherName;
                }
                if(vm.mkrName == "Others") {
                    vm.mkrName = vm.mkrOtherName;
                }

                const params = {
                    cntryCode: vm.cntryCode,
                    dvcType: vm.dvcType,
                    svcName: vm.svcName,
                    mkrName: vm.mkrName,
                    dvcModel: vm.dvcModel
                };

                this.$axios.post("/api/oss/registOss.ajax",
                    qs.stringify(params)).then((result) => {
                    vm.resetForm();
                    alert(this.$t("sdp.suc.com.process"));
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            isSvcListDisabled() {
                if(this.dvcType == "STB") {
                    return false;
                } else {
                    this.svcName = "";
                    return true;
                }
            },
            isNameDisabled(type) {
                if(type == "SVC") {
                    if(this.svcName == "Others") {
                        return false;
                    } else {
                        return true;
                    }
                } else if(type == "MKR") {
                    if(this.mkrName == "Others") {
                        return false;
                    } else {
                        return true;
                    }
                } else {
                    // error
                }
            },
            resetForm() {
                this.cntryCode = "";
                this.dvcType = "";
                this.svcName = "";
                this.svcOtherName = "";
                this.mkrName = "";
                this.mkrOtherName = "";
                this.dvcModel = "";
            },
            checkLength(str, type) {
                var stringByteLength = (function(s,b,i,c) {
                    for(b=i=0;c=s.charCodeAt(i++);b+=c>>11?3:c>>7?2:1);
                    return b;
                })(str);
                if(stringByteLength > 100) {
                    var replaceVal = this.cutInUTF8(str, 100);
                    if(type == "SVC") {
                        this.svcOtherName = replaceVal;
                    } else if(type == "MKR") {
                        this.mkrOtherName = replaceVal;
                    } else if(type == "DVC") {
                        this.dvcModel = replaceVal;
                    } else {
                        // error;
                    }
                }
            },
            cutInUTF8(str, n) {
                var len = Math.min(n, str.length);
                var i, cs, c = 0, bytes = 0;
                for (i = 0; i < len; i++) {
                    c = str.charCodeAt(i);
                    cs = 1;
                    if (c >= 128) cs++;
                    if (c >= 2048) cs++;
                    if (n < (bytes += cs)) break;
                }
                return str.substr(0, i);
            }
        },
        computed: {
            isArabiaLang: function() {
                if(this.locale == "ara_EG") {
                    return "lang-ar";
                } else {
                    return "";
                }
            }
        },
        mounted() {
            const vm = this;

            const params = {
                locale: vm.$route.query.locale
            };

            this.$axios.post("/api/oss/retrieveOssList.ajax",
                qs.stringify(params)).then((result) => {
                vm.cntryList = result.data.cntryList;
                vm.dvcTypeList = result.data.dvcTypeList;
                vm.langList = result.data.langList;
                vm.locale = result.data.locale;
                vm.changeLang(vm.locale);
                vm.$nextTick(function() {
                    ui.init();
                    //customSelect();
                });
            }).catch((err) => {
                alert("error : " + err);
            });
        }
    }
</script>

<style scoped>

</style>