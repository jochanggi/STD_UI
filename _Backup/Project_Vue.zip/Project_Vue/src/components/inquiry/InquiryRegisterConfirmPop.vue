<template>
	<!-- 팝업_문의등록확인 -->
	<div id="popupRegisterComp" class="popup-wrap" hidden>
		<div class="popup popup-type1" role="dialog" aria-labelledby="popupRegisterCompTitle">
			<div class="blind-area popup-focus dv-ios-only" role="text" :aria-label="$t('gwa.alt.common.wa_label_53')"><!-- IOS접근성 영역자체에 초점처리 --></div>
			<div class="popup-container">
				<div class="popup-header">
					<h3 class="tit-h3" id="popupRegisterCompTitle" v-html="$t('sdp.main.qna.link')"></h3>
				</div>
				<div class="popup-body popup-scroll">
					<div class="para-wrap">
						<p class="para color-primary">{{ $t('sdp.support.message.qnapopup1') }}</p>
						<p class="para" v-html="$t('sdp.support.message.qnapopup2') + '<br>' + $t('sdp.support.message.qnapopup5')"></p>
						<p class="para">{{ $t('sdp.support.message.qnapopup6') }}</p>
					</div>
				</div>
				<div class="popup-footer">
					<div class="btn-wrap">
						<button type="button" @click="retrieveMain()" class="btn btn-type2 popup-close btn-secondary" aria-controls="popupRegisterComp"  :title="$t('gwa.alt.common.wa_title_56')"><span>{{ $t('sdp.mypage.message.confirm2') }}</span></button>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //팝업_문의등록확인 -->
</template>

<script>
    import qs from "qs";
    
    export default {
        name: "InquiryRegisterConfirmPop",
        data() {
            return {

            }
        },
        created() {
        },
        watch: {
        },
        computed: {
        },
        methods: {
			track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            retrieveMain() {
                const r = { path : `/main`};
                this.$router.push(r);
			}
        },
        mounted() {
        }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
