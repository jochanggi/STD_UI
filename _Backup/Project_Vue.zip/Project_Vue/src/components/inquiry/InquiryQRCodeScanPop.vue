<template>
	<!-- QR코드_촬영 -->
		<div id="QRCodeScan" class="cameraZone-wrap" hidden>
			<div class="cameraZone">
				<div class="frame">
					<div class="row top">
						<div class="col bg right"></div>
						<div class="col bg"></div>
						<div class="col bg right"></div>
					</div>
					<div class="row mid">
						<div class="col bg left"></div>
						<div><canvas id="canvas" :title="$t('gwa.alt.common.wa_title_22')" class="cameraZone-focus" aria-describedby="cameraDesc" width="300" height="300"></canvas></div>
						<div class="col bg right"></div>
					</div>
					<div class="row btm">
						<div class="col bg right"></div>
						<div class="col bg content" id="cameraDesc" v-html="$t('sdp.qr.message.pop_text1')">
						</div>
						<div class="col bg right"></div>
					</div>
				</div>
			</div>
		</div>
	<!-- 닫기호출 : ui.cameraZone.close('QRCodeScan') -->
	<!-- //QR코드_촬영 -->
</template>

<script>
	import qs from "qs";
	
	var g_video = null;
    
    export default {
        name: "InquiryQRCodeScanPop",
        data() {
            return {
            }
        },
        created() {
			console.log('InquiryQRCodeScanPop created');
		},
		destroyed() {
			
		},
        watch: {
        },
        computed: {
        },
        methods: {
			track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
			open() {
				console.log('InquiryQRCodeScanPop.vue', 'open');
				this.$nextTick(function() {
					this.openQRCodeScanner();
				})
			},
			close() {
				console.log('InquiryQRCodeScanPop.vue', 'close');
				this.$nextTick(function() {
					this.closeQRCodeScanner();
				})
			},

			closeQRCodeScanner() {
				console.log('InquiryQRCodeScanPop destroyed');
				var videoList = document.getElementsByTagName("video");
				console.log(videoList);
				if(videoList.length != 0) {
					var video = videoList[0];
					console.log(video);
				}

				console.log(g_video);

				if(g_video != null) {
					g_video.pause();
				}

				g_video = null;
			},
			openQRCodeScanner() {

				g_video = null;
            
				g_video = document.createElement("video");

				var canvasElement = document.getElementById("canvas");
				var canvas = canvasElement.getContext("2d");

				function drawLine(begin, end, color) {
					canvas.beginPath();
					canvas.moveTo(begin.x, begin.y);
					canvas.lineTo(end.x, end.y);
					canvas.lineWidth = 4;
					canvas.strokeStyle = color;
					canvas.stroke();
				}

				var errorCallback = function(e) {
					alert('error !');
				};
				
				var md = new MobileDetect(window.navigator.userAgent);

				console.log('md', md);

				var hasFront = false;
				var hasBack = false;
				
				navigator.mediaDevices.enumerateDevices()
				.then(function(devices) {
					devices.forEach(function(device) {
						if(device.kind == 'videoinput') {
							if(device.label.includes("back")) {
								hasBack = true;
							}
							if(device.label.includes("front")) {
								hasFront = true;
							}
						}
					// alert('kind : [' + device.kind + "]: [" + device.label + "] id = [" + device.deviceId + ']');
					});
				})
				.catch(function(e) {
					console.log(e.name + ": " + e.message);
				});
				

				console.log('hasFront', hasFront);
				console.log('hasBack', hasBack);

				navigator.getUserMedia = navigator.getUserMedia ||
								navigator.webkitGetUserMedia ||
								navigator.mozGetUserMedia;
								
				console.log('navigator.getUserMedia', navigator.getUserMedia);

				var _exact = 'user';
				if(md.mobile() != null || md.tablet() != null) {
					_exact = 'environment';
				}
				
				navigator.mediaDevices.getUserMedia({ video: {
						facingMode: {
							width: 640,
							// width: {max: canvasElement.width},
							// height: {max: canvasElement.height},
							exact: _exact
							}
						}
					}).then(function(stream) {

					g_video.srcObject = stream;
					g_video.setAttribute("playsinline", true); // required to tell iOS safari we don't want fullscreen
					g_video.play();
					
					// requestAnimationFrame(tick);
					
				}).catch(function(err) {
					console.log(err);
				})


			}

        },
        mounted() {
			console.log('InquiryQRCodeScanPop mounted');

			

        }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
