<template>
	<div id="QRCodeScan" class="cameraZone-page">
		<div class="cameraZone">
			<div class="frame">
				<div class="row top">
					<div class="col bg right"></div>
					<div class="col bg"></div>
					<div class="col bg right"></div>
				</div>
				<div class="row mid">
					<div class="col bg left"></div>
					<div class="col canvas">
						<canvas id="canvas"
                            :title="$t('gwa.alt.common.wa_title_22')"
                            class="cameraZone-focus" aria-describedby="cameraDesc"></canvas>
					</div>
					<div class="col bg right"></div>
				</div> 
				<div class="row btm">
					<div class="col bg right"></div>
					<div class="col bg content" id="cameraDesc" v-html="$t('sdp.qr.message.pop_text1')">
					</div>
					<div class="col bg right"></div>
				</div>
			</div>
			<button @click="$router.go(-1)" type="button" class="btn-ico btn-popup-close" aria-controls="QRCodeScan" :title="$t('gwa.alt.common.wa_title_23')"><span><i class="ico ico-close3">{{ $t('gwa.alt.common.wa_label_19') }}</i></span></button>
		</div>
	</div>
</template>

<script>

    // import CashedData from "./CashedData";

    var g_video = null;
    
    export default {
        name: "DemoQRCodeReader",
        data() {
            return {}
        },
        created() {
            console.log("QRCodeScanner.created");
        },
        destroyed() {
            console.log('QRCodeScanner destroyed');

            var videoList = document.getElementsByTagName("video");
            console.log(videoList);
            if(videoList.length != 0) {
                var video = videoList[0];
                console.log(video);
            }

            console.log(g_video);

            if(g_video != null) {
                g_video.pause();
            }

            g_video = null;
        },
        watch: {
            $route: "fetchData"
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            fetchData() {
                // console.log("fetchData");
            },
            detectQRCode(data) {
                var path = "/main/inquiry/register?qrcodedata=" + data
                this.$router.push({ path: path });
            }
        },
        mounted() {
            // console.log('mounted');

            // document.getElementsByTagName("video");
            
            g_video = null;
            
            g_video = document.createElement("video");

            var canvasElement = document.getElementById("canvas");
            var canvas = canvasElement.getContext("2d");
            var loadingMessage = document.getElementById("loadingMessage");
            var outputContainer = document.getElementById("output");
            // var outputMessage = document.getElementById("outputMessage");
            var outputData = document.getElementById("outputData");

            function drawLine(begin, end, color) {
                canvas.beginPath();
                canvas.moveTo(begin.x, begin.y);
                canvas.lineTo(end.x, end.y);
                canvas.lineWidth = 4;
                canvas.strokeStyle = color;
                canvas.stroke();
            }

            var errorCallback = function(e) {
                alert('error !');
            };

            var md = new MobileDetect(window.navigator.userAgent);
            
            // alert('mobile : ' + md.mobile());
            // alert('phone : ' + md.phone());
            // alert('tablet : ' + md.tablet());
            // alert('userAgent : ' + md.userAgent());
            // alert('is : ' + md.is('iPhone'));
            

            var hasFront = false;
            var hasBack = false;

            navigator.mediaDevices.enumerateDevices()
            .then(function(devices) {
                devices.forEach(function(device) {
                    if(device.kind == 'videoinput') {
                        if(device.label.includes("back")) {
                            hasBack = true;
                        }
                        if(device.label.includes("front")) {
                            hasFront = true;
                        }
                    }
                // alert('kind : [' + device.kind + "]: [" + device.label + "] id = [" + device.deviceId + ']');
                });
            })
            .catch(function(e) {
                console.log(e.name + ": " + e.message);
            });

            navigator.getUserMedia = navigator.getUserMedia ||
                              navigator.webkitGetUserMedia ||
                              navigator.mozGetUserMedia;

            // environment

            // var _exact = 'user';
            // if( this.$route.query.mode == 'front') {
            //     _exact = 'user';
            // } else {
            //     _exact = 'environment';
            // }

            var _exact = 'user';
            if(md.mobile() != null || md.tablet() != null) {
                _exact = 'environment';
            }
            // if(hasBack == true) {
            //     _exact = 'environment';
            // }

            if( this.$route.query.platform == 'ios') {

                // alert('ios');
                // alert(navigator);
                // alert(navigator.mediaDevices);
                // alert(navigator.getUserMedia);

                navigator.mediaDevices.getUserMedia({ video: { width: 640/*320-640-1280*/ } })
                    .then(function(stream) {

                        alert('###########');

                    g_video.srcObject = stream;
                    g_video.setAttribute("playsinline", true); // required to tell iOS safari we don't want fullscreen
                    g_video.play();
                    
                    requestAnimationFrame(tick);
                    
                }).catch(function(err) {
                    alert(err);
                })

            } else {

                // alert(navigator);
                // alert(navigator.mediaDevices);
                // alert(navigator.getUserMedia);

                navigator.mediaDevices.getUserMedia({ video: {
                        facingMode: {
                            width: {max: canvasElement.width},
                            height: {max: canvasElement.height},
                            exact: _exact
                            }
                        }
                    }).then(function(stream) {

                    g_video.srcObject = stream;
                    g_video.setAttribute("playsinline", true); // required to tell iOS safari we don't want fullscreen
                    g_video.play();
                    
                    requestAnimationFrame(tick);
                    
                }).catch(function(err) {
                    alert(err);
                })
            }


            var This = this;
            function tick() {
                if(g_video == null) {
                    return;
                }

                console.log('tick...');

                // loadingMessage.innerText = "⌛ Loading video..."
                if (g_video.readyState === g_video.HAVE_ENOUGH_DATA) {

                    // loadingMessage.hidden = true;
                    canvasElement.hidden = false;
                    // outputContainer.hidden = false;

                    // canvasElement.height = video.videoHeight;
                    // canvasElement.width = video.videoWidth;
                    // video.videoHeight = canvasElement.height;
                    // video.videoWidth = canvasElement.width;

                    canvas.drawImage(g_video, 0, 0, canvasElement.width, canvasElement.height);

                    var imageData = canvas.getImageData(0, 0, canvasElement.width, canvasElement.height);
                    var code = jsQR(imageData.data, imageData.width, imageData.height, {
                        inversionAttempts: "dontInvert",
                    });

                    if (code) {

                        drawLine(code.location.topLeftCorner, code.location.topRightCorner, "#FF3B58");
                        drawLine(code.location.topRightCorner, code.location.bottomRightCorner, "#FF3B58");
                        drawLine(code.location.bottomRightCorner, code.location.bottomLeftCorner, "#FF3B58");
                        drawLine(code.location.bottomLeftCorner, code.location.topLeftCorner, "#FF3B58");
                        // outputMessage.hidden = true;
                        // outputData.parentElement.hidden = false;
                        // outputData.innerText = code.data;

                        This.detectQRCode(code.data);

                        return;

                    } else {
                        // outputMessage.hidden = false;
                        // outputData.parentElement.hidden = true;
                    }
                }
                requestAnimationFrame(tick);
            }

        }
    }

</script>

<style scoped>
.center {
  margin: auto;
}

canvas {
    border: 3px solid blue;
}

</style>