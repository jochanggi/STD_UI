<template>
	<!-- Content -->
		<section id="content" class="content mypage-cont">
			<!-- Content Header -->
			<!-- 고도화 ver2 : 클래스 has-search삭제, centered-c추가 -->
			<div class="content-header sub-visual">
                <div class="sub-visual-bg"></div>
				<div class="in-sec">
					<div class="tit-wrap centered-c">
						<h2 class="tit-h2">{{ $t('sdp.menu.qna') }}</h2>
						<p class="explain-h2">{{ $t('sdp.inpuiry.message.title1') }}</p>
					</div>
				</div>
			</div>
			<!-- //Content Header -->
			<!-- Content Body -->
			<div class="content-body">
				<!-- 상세그룹 -->
				<div class="ques-detail-wrap in-sec">
					<div class="section-body" v-if="loadingYn == 'Y'">
						<div class="loading-wrap">
							<div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
						</div>
					</div>
					<div class="tbl-regist-wrap" v-else>
						<div class="tbl-regist">
							<table v-if="inquiryDetail.cnttTypeNm1 != null && inquiryDetail.cnttTypeNm1 != ''">
								<caption>
									<div class="blind-area" role="text">
										<strong>{{ $t('gwa.alt.inquiry.wa_caption_3') }}</strong>
										<p>{{ $t('gwa.alt.inquiry.wa_caption_4') }}</p>
									</div>
								</caption>
								<colgroup>
									<col class="col-index1">
									<col class="col-index2">
									<col>
								</colgroup>
								<tbody>
									<tr>
										<th id="registTh1" colspan="2">{{ $t('sdp.support.message.idOrEmailId') }}</th>
										<td headers="registTh1" v-if="inquiryDetail.emailIdCertFlag == 'Y'">
											<span class="form-static">{{ inquiryDetail.emailId }}</span>
										</td>
										<td headers="registTh1" v-else>
											<span class="form-static">{{ inquiryDetail.userId }}</span>
										</td>
									</tr>
									<tr>
										<th id="registTh2" colspan="2">{{ $t('sdp.support.message.recvEmail') }}</th>
										<td headers="registTh2"><span class="form-static">{{ inquiryDetail.usrEmail }}</span></td>
									</tr>
								</tbody><!-- 고도화 ver2 : 영역구분 -->
								<tbody>
									<tr>
										<th id="registTh3" rowspan="3" class="tit-dep1" v-html="$t('sdp.support.message.type')"></th>
										<th id="registTh31">{{ $t('sdp.support.message.catType1') }}</th>
										<td headers="registTh3 registTh31"><span class="form-static">{{ inquiryDetail.cnttTypeNm1 }}</span></td>
									</tr>
									<tr>
										<th id="registTh32">{{ $t('sdp.support.message.catType2') }}</th>
										<td headers="registTh3 registTh32"><span class="form-static">{{ inquiryDetail.cnttTypeNm2 }}</span></td>
									</tr>
									<tr>
										<th id="registTh33" v-html="$t('sdp.support.message.catType3')"></th>
										<td headers="registTh3 registTh33"><span class="form-static">{{ inquiryDetail.cnttTypeNm3 }}</span></td>
									</tr>
								</tbody>
								<tbody>
									<tr>
										<th id="registTh4" colspan="2">{{ $t('sdp.support.message.maddr') }}</th>
										<td headers="registTh4"><span class="form-static">{{ inquiryDetail.maddr }}</span></td>
									</tr>
									<tr>
										<th id="registTh5" colspan="2">{{ $t('gwa.alt.support.inquiry.tvModel') }}</th>
										<td headers="registTh5"><span class="form-static">{{ inquiryDetail.modelName }}</span></td>
									</tr>
									<tr>
										<th id="registTh6" colspan="2">{{ $t('gwa.alt.support.inquiry.serviceName') }}</th>
										<td headers="registTh6"><span class="form-static">{{ inquiryDetail.appName }}</span></td>
									</tr>
									<tr>
										<th id="registTh7" colspan="2">{{ $t('sdp.support.message.inquiryStatus') }}</th>
										<td headers="registTh7"><span class="form-static">{{ inquiryDetail.replStatCodeName }}</span></td>
									</tr>
									<tr>
										<th id="registTh8" colspan="2">{{ $t('sdp.support.message.title') }}</th>
										<td headers="registTh8"><span class="form-static">{{ inquiryDetail.titleName }}</span></td>
									</tr>
									<tr>
										<th id="registTh9" colspan="2">{{ $t('sdp.support.message.content') }}</th>
										<td headers="registTh9">
											<div class="form-static" v-html="lineBreakCntt(inquiryDetail.questCntt)"></div>
										</td>
									</tr>
									<tr>
										<th id="registTh10" colspan="2">{{ $t('sdp.support.message.mantoman.attachfile') }}</th><!-- 고도화 ver2 : 파일첨부로 변경 -->
										<td headers="registTh10">
											<div class="attach-view-wrap">
												<ul class="attach-view" v-if="inquiryFileListCnt > 0">
													<li class="item" v-for="file in inquiryFileList">
														<span class="item-label" id="fileItem1"><a @click="fileDownload(file.seqNo, file.fileSeqNo)" href="javascript:;"><i class="ico ico-file" :aria-label="$t('gwa.alt.common.wa_label_16')"></i><span class="txt">{{ file.fileName }}</span></a></span>
													</li>
												</ul>
											</div>
										</td>
									</tr>
								</tbody>
							</table>
							<table v-else>
								<caption>
									<div class="blind-area" role="text">
										<strong>{{ $t('gwa.alt.inquiry.wa_caption_3') }}</strong>
										<p>{{ $t('gwa.alt.inquiry.wa_caption_4') }}</p>
									</div>
								</caption>
								<colgroup>
									<col class="col-index1">
									<col class="col-index2">
									<col>
								</colgroup>
								<tbody>
									<tr>
										<th colspan="2">{{ $t('sdp.support.message.idOrEmailId') }}</th>
										<td headers="registTh1" v-if="inquiryDetail.emailIdCertFlag == 'Y'">
											<span class="form-static">{{ inquiryDetail.emailId }}</span>
										</td>
										<td headers="registTh1" v-else>
											<span class="form-static">{{ inquiryDetail.userId }}</span>
										</td>
									</tr>
									<tr>
										<th colspan="2">{{ $t('gwa.alt.support.notice.date') }}</th>
										<td headers="registTh2"><span class="form-static">{{ inquiryDetail.cDate }}</span></td>
									</tr>
									<tr>
										<th colspan="2">{{ $t('sdp.support.message.recvEmail') }}</th>
										<td headers="registTh2"><span class="form-static">{{ inquiryDetail.usrEmail }}</span></td>
									</tr>
								</tbody><!-- 고도화 ver2 : 영역구분 -->
								<tbody>
									<tr>
										<th colspan="2">{{ $t('sdp.support.message.type') }}</th>
										<td headers="registTh4"><span class="form-static">{{ inquiryDetail.cnttTypeName }}</span></td>
									</tr>
									<tr>
										<th colspan="2">{{ $t('sdp.support.message.inquiryStatus') }}</th>
										<td headers="registTh7"><span class="form-static">{{ inquiryDetail.replStatCodeName }}</span></td>
									</tr>
									<tr>
										<th colspan="2">{{ $t('sdp.support.message.title') }}</th>
										<td headers="registTh8"><span class="form-static">{{ inquiryDetail.titleName }}</span></td>
									</tr>
									<tr>
										<th colspan="2">{{ $t('sdp.support.message.content') }}</th>
										<td headers="registTh9">
											<div class="form-static" v-html="lineBreakCntt(inquiryDetail.questCntt)"></div>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>

					<div class="tbl-reply-wrap" v-if="inquiryRepList.length > 0 && loadingYn == 'N'">
						<!-- 페이저 -->
						<div class="tbl-reply">
							<table>
								<caption>
									<div class="blind-area" role="text">
										<strong>{{ $t('gwa.alt.common.wa_caption_4') }}</strong>
										<p>{{ $t('gwa.alt.common.wa_summary_4', {var1:inquiryRepList.length}) }}</p>
									</div>
								</caption>
								<tbody v-for="(rep, index) in inquiryRepList">
									<tr>
										<th id="boardReplay1">{{ $t('sdp.support.message.reply') + (index+1) }}</th>
										<td headers="boardReplay1" v-if="inquiryDetail.replStatCode == 'PM6102'">
										</td>
										<td headers="boardReplay1" v-if="inquiryDetail.replStatCode == 'PM6104'">
												{{ $t('sdp.support.message.status1') }}
										</td>
										<td headers="boardReplay1" v-if="inquiryDetail.replStatCode != 'PM6102' && inquiryDetail.replStatCode != 'PM6104'">
											<div class="form-static" v-html="rep.replCntt"><!--rep.cDate-->
											</div>
										</td>
									</tr>
									<tr v-if="inquiryReplFileListCnt > 0">
										<th id="boardReplay2">{{ $t('sdp.support.message.mantoman.attachfile') + (index+1) }}</th>
										<td headers="boardReplay2">
											<div class="attach-view-wrap">
												<ul class="attach-view">
													<li class="item">
														<span class="item-label"><a href="#"><i class="ico ico-file" :aria-label="$t('gwa.alt.common.wa_label_16')"></i><span class="txt">{{ inquiryReplFileList[index].fileName }}</span></a></span>
													</li>
												</ul>
											</div>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
						<!-- //페이저 -->
					</div>

					<div class="board-pager-wrap" v-if="loadingYn == 'N'">
						<!-- 페이저 -->
						<div class="board-pager">
							<table>
								<caption>
									<div class="blind-area" role="text">
										<strong>{{ $t('gwa.alt.inquiry.wa_caption_5') }}</strong>
										<p>{{ $t('gwa.alt.common.wa_summary_2') }}</p>
									</div>
								</caption>
								<tbody>
									<tr v-if="inquiryDetail.nextSeq != null">
										<th id="boardPrev">{{ $t('sdp.support.message.pre') }}<i class="arw arw-pager-prev centered-r" aria-hidden="true"></i></th>
										<td headers="boardPrev">
											<a href="javascript:;" class="link-wrap" :title="$t('gwa.alt.common.wa_title_6')" @click="retrieveInquiryDetail(inquiryDetail.nextSeq)">
												<span class="link-text">{{ inquiryDetail.nextTitleName }}</span>
											</a>
										</td>
									</tr>
									<tr v-if="inquiryDetail.preSeq != null">
										<th id="boardNext">{{ $t('sdp.support.message.next') }}<i class="arw arw-pager-next centered-r" aria-hidden="true"></i></th>
										<td headers="boardNext">
											<a href="javascript:;" class="link-wrap" :title="$t('gwa.alt.common.wa_title_6')" @click="retrieveInquiryDetail(inquiryDetail.preSeq)">
												<span class="link-text">{{ inquiryDetail.preTitleName }}</span>
											</a>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
						<!-- //페이저 -->
					</div>

					<!-- 버튼 -->
					<div class="btn-wrap in-sec">
						<router-link tag="a" to="/main/inquiry/list" class="btn btn-type1" :aria-label="$t('gwa.alt.common.wa_label_14')"><span>{{ $t('sdp.support.message.listview') }}</span></router-link>
					</div>
					<!-- //버튼 -->
				</div>
				<!-- //상세그룹 -->
			</div>
			<!-- //Content Body -->
		</section>
	<!-- //Content -->
</template>

<script>
    import qs from "qs";
    
    export default {
        name: "InquiryDetail",
        data() {
            return {
				seqNo : 0,
				inquiryDetail : [],
                inquiryFileList : [],
                inquiryFileCnt : 0,
                inquiryRepList : [],
                inquiryRepListCnt : 0,
                inquiryReplFileList : [],
                inquiryReplFileListCnt : 0,
				loadingYn: "Y"
            }
        },
        created() {
        },
        watch: {
        },
        computed: {
        },
        methods: {
			track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            _setResult(result) {
                ui.loading.close();

                const vm = this;

                vm.inquiryDetail = result.data.inquiryDetail;

                vm.inquiryFileList = result.data.inquiryFileList;
                vm.inquiryFileListCnt = result.data.inquiryFileListCnt;

                vm.inquiryRepList = result.data.inquiryRepList;
                vm.inquiryRepListCnt = result.data.inquiryRepListCnt;
                vm.inquiryReplFileList = result.data.inquiryReplFileList;
                vm.inquiryReplFileListCnt = result.data.inquiryReplFileListCnt;

                vm.loadingYn = "N";
        	},
			retrieveInquiryDetail(seqNo) {
                $(window).scrollTop(0);
			    ui.loading.open();

                const vm = this;
                vm.loadingYn = "Y";

                const params = {
                    seqNo : seqNo
				};

                this.$axios.post("/api/inquiry/retrieveInquiryDetail.ajax", qs.stringify(params)).then((result) => {
                    vm.$nextTick(function() {
                        vm._setResult(result);
                    })
                }).catch((err) => {
                    ui.loading.close();
                    vm.loadingYn = "N";
                    alert("error");
                });
			},
			fileDownload(seqNo, fileSeqNo) {
                const params = {
                    seqNo: seqNo,
					fileSeqNo: fileSeqNo
                };
                this.$axios.post('/api/inquiry/inquiryFileDownload.ajax', qs.stringify(params)).then((result) => {
                    if(result.data.modulationYn == "Y") {
                        const r = { path : "/main" };
                        this.$router.push(r);
                        return;
                    }
                    var filePath = result.data.filePath;
                    window.location = filePath;
                }).catch((err) => {
                    alert('error ' + err);
                });
			},
            lineBreakCntt(cntt) {
                if(cntt != null && cntt != "") {
                    cntt = cntt.split("<").join("&lt;");
                    cntt = cntt.split(">").join("&gt;");
                    cntt = cntt.split("\n").join("<br />");
                    return cntt;
                } else {
                    return "";
                }
            }
        },
        mounted() {
            $(window).scrollTop(0);
            ui.loading.open();

            const vm = this;

            const params = {
                seqNo: vm.$route.query.seqNo,
            };
            this.$axios.post('/api/inquiry/retrieveInquiryDetail.ajax', qs.stringify(params)).then((result) => {
                ui.loading.close();

                if(result.data.modulationYn == "Y") {
                    const r = { path : "/main" };
                    this.$router.push(r);
                    return;
				}

				vm.inquiryDetail = result.data.inquiryDetail;

				vm.inquiryFileList = result.data.inquiryFileList;
                vm.inquiryFileListCnt = result.data.inquiryFileListCnt;

                vm.inquiryRepList = result.data.inquiryRepList;
                vm.inquiryRepListCnt = result.data.inquiryRepListCnt;
                vm.inquiryReplFileList = result.data.inquiryReplFileList;
                vm.inquiryReplFileListCnt = result.data.inquiryReplFileListCnt;

                vm.loadingYn = "N";
            }).catch((err) => {
                ui.loading.close();
                vm.loadingYn = "N";
                alert('error ' + err);
            })

        }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
