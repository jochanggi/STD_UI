<template>
    <!-- content -->
    <section id="content" class="content ques-cont">
        <!--macAddress : {{ macAddress }} modelName {{ modelName }}-->
        <!-- content Header -->
        <div class="content-header sub-visual">
            <div class="sub-visual-bg"></div>
            <div class="in-sec">
                <div class="tit-wrap centered-c">
                    <h2 class="tit-h2">{{ $t('sdp.menu.qna') }}</h2>
                    <p class="explain-h2" v-html="$t('sdp.support.message.new.qna4_explain')"></p>
                </div>
            </div>
        </div>
        <!-- //content Header -->
        <!-- content Body -->
        <div class="content-body">
            <!-- 문의등록 전체영역 -->
            <div class="section-body" v-if="loadingYn == 'Y'">
                <div class="loading-wrap">
                    <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                </div>
            </div>
            <div class="ques-regist-wrap in-sec" v-else>
                <!-- 등록 입력영역 -->
                <div class="tbl-regist-wrap">
                    <div class="explain-header">
                        <p role="text" v-html="$t('sdp.support.message.checkItem', {var1: '<span aria-label=\'필수입력\'>\'<span class=\'txt-required\'>*</span>\'</span>'})"></p>                        
                    </div>
                    <!-- 입력정보 -->
                    <div class="tbl-regist">
                        <table>
                            <caption>
                                <div class="blind-area" role="text">
                                    <strong v-show="memberYn == 'Y'">{{ $t('gwa.alt.common.wa_caption_3') }}</strong>
                                    <p>{{ $t('gwa.alt.common.wa_summary_3') }}</p>
                                </div>
                            </caption>
                            <colgroup>
                                <col class="col-index1">
                                <col class="col-index2">
                                <col>
                            </colgroup>
                            <tbody>
                                <!-- CASE 회원등록 -->
                                <tr v-if="memberYn == 'Y'">
                                    <th id="registTh1" colspan="2"><span class="form-label">{{ $t('sdp.support.message.idOrEmailId') }}</span></th>
                                    <td headers="registTh1"><span class="form-static">{{ userId }}</span></td>
                                </tr>
                                <!-- //CASE 회원등록 -->
                                <tr>
                                    <th id="registTh2" colspan="2"><label class="form-label" role="text">{{ $t('sdp.support.message.recvEmail') }} <span class="txt-required" :aria-label="$t('gwa.alt.common.wa_label_15')">*</span></label></th>
                                    <td headers="registTh2">
                                        <div class="grid-form type-email">
                                            <span class="col"><input type="text" v-model="preEmail" name="preEmail" id="preEmail" value="" placeholder="" :title="$t('gwa.alt.common.wa_title_14')" class="form-text form-size-md" required/></span>
                                            <span class="col form-split">@</span>
                                            <span class="col"><input type="text" v-model="endEmail" name="endEmail" id="endEmail" value="" placeholder="" :title="$t('gwa.alt.common.wa_title_15')" class="form-text form-size-md" required/></span>
                                        </div>
                                        <!-- CASE 비회원등록 -->
                                        <div class="link-wrap" v-show="memberYn == 'N'">
                                            <span class="link-type1 not-link">{{ $t('sdp.inpuiry.message.email_text1') }}</span>
                                            <button type="button" @click="goLgaccount()" class="btn btn-type5 btn-primary" :aria-label="$t('gwa.alt.common.wa_title_16')" :title="$t('gwa.alt.common.wa_title_16')"><span>{{ $t('sdp.menu.gnb.lgaccount') }}</span></button>
                                        </div>
                                        <!-- //CASE 비회원등록 -->
                                        <div class="form-desc bul bul-star">
                                            <p>{{ $t('sdp.support.message.qna2') }}</p>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    <th id="registTh3" rowspan="3" class="tit-dep1">
                                        <span v-html="$t('sdp.support.message.type')"></span>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-type5 btn-secondary popup-open" aria-controls="popupQuseAll" aria-haspopup="true"><span v-html="$t('sdp.support.message.totalView')"></span></button>
                                        </div>
                                    </th>
                                    <th id="registTh31"><label for="cateCode1" role="text">{{ $t('sdp.support.message.catType1') }} <span class="txt-required" :aria-label="$t('gwa.alt.common.wa_label_15')">*</span></label></th>
                                    <td headers="registTh3 registTh31">
                                        <span class="form-select form-size-lg">
                                            <select name="cateCode1" id="cateCode1" @change="changeService($event, 2);" v-model="cateCode1" required>
                                                <option value="" selected>{{ $t('sdp.support.combo.default') }}</option>
                                                <option v-for="service in serviceList" :value="service.catCode">{{ service.catName }}</option>
                                            </select>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th id="registTh32"><label for="cateCode2" role="text" v-html="$t('sdp.support.message.catType2') + '<span class=\'txt-required\' :aria-label=\'$t(\'gwa.alt.common.wa_label_15\')\'>*</span>'"> </label></th>
                                    <td headers="registTh3 registTh32">
                                        <span class="form-select form-size-lg">
                                            <select name="cateCode2" id="cateCode2" @change="changeService($event, 3);" v-model="cateCode2" required>
                                                <option value="" selected>{{ $t('sdp.support.combo.default') }}</option>
                                                <option v-for="category in categoryList" :value="category.catCode">{{ category.catName }}</option>
                                            </select>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th id="registTh33"><label for="cateCode3" role="text" v-html="$t('sdp.support.message.catType3') + '<span class=\'txt-required\' :aria-label=\'$t(\'gwa.alt.common.wa_label_15\')\'>*</span>'"></label></th>
                                    <td headers="registTh3 registTh33">
                                        <span class="form-select form-size-lg">
                                            <select name="cateCode3" id="cateCode3" @change="changeType();"  v-model="cateCode3" required>
                                                <option value="" selected>{{ $t('sdp.support.combo.default') }}</option>
                                                <option v-for="type in typeList" :value="type.catCode">{{ type.catName }}</option>
                                            </select>
                                        </span>
                                    </td>
                                </tr>
                            </tbody>
                            <!-- 고도화 ver2 : 클래스 tbl-regist-result -->

                            <tbody v-if="typeShow == true" class="tbl-regist-result">
                                <tr>
                                    <td colspan="3">
                                        <!-- 탭영역 -->
                                        <div class="tab-type1-wrap">
                                            <!-- 탭메뉴 (퍼블참고 : 검색결과 펼치면서 첫번째 요소에 포커스처리를 위한 클래스 적용 folder-focus) -->
                                            <!-- 고도화 ver2 : 구조 tit 변경1 -->
                                            <nav class="tab-nav tab-change tab-type1 tab-cols-2">
                                                <ul role="tablist">
                                                    <li role="presentation" class="item1" :class="isDiagActive"><a href="#tabContentSelftest" id="tabContentSelftestNav" class="folder-focus" role="tab" aria-controls="tabContentSelftest" aria-selected="true" aria-expanded="true"><span class="tit">{{ $t('sdp.menu.gnb.self') }}<em class="label-type2">{{ typeDiagCount }}</em></span></a></li>
                                                    <li role="presentation" class="item2" :class="isFaqActive"><a href="#tabContentFaq" id="tabContentFaqNav" role="tab" aria-controls="tabContentFaq" aria-selected="false" aria-expanded="false"><span class="tit">{{ $t('sdp.menu.faq') }}<em class="label-type2">{{ typeFaqCount }}</em></span></a></li>
                                                </ul>
                                            </nav>
                                            <!-- //탭메뉴 -->

                                            <!-- 탭내용 -->
                                            <div class="tab-body">
                                                <!-- 탭내용_자가진단 -->
                                                <div id="tabContentSelftest" class="tab-content" :class="isDiagActive" aria-labelledby="tabContentSelftestNav">
                                                    <!-- 자가진단 전체영역 -->
                                                    <h3 class="blind dv-pc-only">{{ $t('sdp.menu.gnb.self') }}</h3>
                                                    <div id="selftestAjaxWrap" class="selftest-lists-wrap">
                                                        <!-- 목록그룹 (대체텍스트 형식 : alt="[제목] + Thumbnail") -->
                                                        <div class="selftest-lists" data-type="image">
                                                            <ul>
                                                                <li v-for="diag in typeDiagList">
                                                                    <a href="javascript:;" class="item-wrap" :title="$t('gwa.alt.common.wa_title_33')" @click="updateDiagViewCnt(diag.seqNo, diag.catCode1)">
                                                                        <div role="text">
                                                                            <p class="item-thumb thumbnail" aria-hidden="true"><img :src="diag.resourcePth" :alt="$t('gwa.alt.inquiry.wa_alt_1')"></p>
                                                                            <p class="item-tit"><strong>{{ diag.titleName }}</strong></p>
                                                                            <p class="item-date">{{ diag.crtDate }}</p>
                                                                        </div>
                                                                    </a>
                                                                    <!--<div class="item-tag" v-if="typeDiagHashTag.length > 0">
                                                                        <template v-for="hashTag in typeDiagHashTag">
                                                                            <a href="#" class="tag-type1" role="button" v-if="hashTag.seqNo == diag.seqNo" @click="keywordClick(hashTag.hashTag);">{{ hashTag.hashTag }}</a>
                                                                        </template>
                                                                    </div>-->
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <!-- //자가진단 전체영역 -->
                                                    <!-- 미등록게시물 -->
                                                    <div class="noData-wrap" v-if="typeDiagList.length == 0">
                                                        <div class="noData">
                                                            <div class="inner">
                                                                <p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- //미등록게시물 -->
                                                </div>
                                                <!-- //탭내용 -->

                                                <!-- 탭내용_FAQ -->
                                                <div id="tabContentFaq" class="tab-content" :class="isFaqActive" aria-labelledby="tabContentFaqNav">
                                                    <h3 class="blind dv-pc-only">{{ $t('sdp.menu.gnb.faq') }}</h3>
                                                    <!-- FAQ 전체영역 -->
                                                    <div id="faqAjaxWrap" class="faq-wrap">
                                                        <!-- FAQ 목록그룹 -->
                                                        <div class="accordion-wrap faq-accordion">
                                                            <!-- 반복영역 -->
                                                            <div class="accordion" v-for="(faq, index) in typeFaqList">
                                                                <div class="accordion-title">
                                                                    <a :href="'#faqContent2_'+index" class="accordion-toggle" role="button" :aria-controls="'faqContent2_'+index" aria-expanted="false" @click="readCntt(faq.seqNo)">
                                                                        <em class="tit-qusetion" aria-label="Qusetion">Q</em>
                                                                        <em class="tit-part">{{ faq.catName }}</em>
                                                                        <span class="tit-label">{{ faq.titleName }}</span>
                                                                        <i class="arw arw-toggle" aria-hidden="true"></i>
                                                                    </a>
                                                                </div>
                                                                <div :id="'faqContent2_'+index" class="accordion-content" aria-hidden="true">
                                                                    <em class="tit-answer" aria-label="Answer">A</em>
                                                                    <div class="data-content" role="text" v-html="lineBreakCntt(faq.cntt)"></div>
                                                                    <!-- 고도화 ver2 : 속성 aria-label 검색 추가 -->
                                                                    <div class="tag-wrap">
                                                                        <template v-for="hashTag in typeFaqHashTag">
                                                                            <a class="tag-type1" role="button" v-if="hashTag.seqNo == faq.seqNo" @click="keywordClick(hashTag.hashTag);" :aria-label="hashTag.hashTag+' '+$t('gwa.alt.main.sch')">
                                                                                #{{ hashTag.hashTag }}
                                                                            </a>
                                                                        </template>
                                                                    </div>
                                                                    <div class="msg-wrap">
                                                                        <p class="txt-area"><i class="arw arw-right" aria-hidden="true"></i>{{ $t('sdp.Satisfaction.message.question') }}</p>
                                                                        <div class="btn-area">
                                                                            <button type="button" class="btn btn-type4 btn-primary" @click="goSatisf('Y')"><span>{{ $t('sdp.Satisfaction.message.btn1') }}</span></button>
                                                                            <button type="button" class="btn btn-type4 popup-open" aria-controls="popupFaqQuestion" aria-haspopup="true"><span>{{ $t('sdp.Satisfaction.message.btn2') }}</span></button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- //반복영역 -->
                                                        </div>
                                                    </div>
                                                    <!-- //FAQ 전체영역 -->
                                                    <!-- 미등록게시물 -->
                                                    <div class="noData-wrap" v-if="typeFaqList.length == 0">
                                                        <div class="noData">
                                                            <div class="inner">
                                                                <p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- //미등록게시물 -->
                                                </div>
                                                <!-- //탭내용_FAQ -->
                                            </div>
                                            <!-- //탭내용 -->
                                        </div>
                                        <!-- //탭영역 -->
                                    </td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    <th id="registTh4" colspan="2"><label>{{ $t('sdp.support.message.maddr') }}</label></th>
                                    <td headers="registTh4">
                                        <div class="grid-form type-model">
                                            <span class="col" v-if="memberYn == 'Y'">
                                                <span class="form-select form-size-md">
                                                    <select v-model="macSelectChk" name="sTypes" id="sMacAdd" :title="$t('gwa.alt.common.wa_title_17')" @change="changeMacAddress()">
                                                        <option value="" selected>{{ $t('sdp.support.combo.default') }}</option>
                                                        <option v-for="maddr in maddrList">{{ maddr.maddr }}</option>
                                                        <option value="enterInfo" >{{ $t('sdp.support.message.enterInfo') }}</option>
                                                    </select>
                                                </span>
                                            </span>
                                            <span class="col"><input type="text" v-model="macAddress" name="sMacAdd2"  value="" placeholder="" :title="$t('gwa.alt.common.wa_title_18')" class="form-text form-size-md" :disabled="isDisabled('maddr')" /></span>
                                        </div>
                                        <div class="link-wrap">
                                            <a href="javascript:;" class="link-type1" @click="retrieveFaqInfo('MAC')" :title="$t('gwa.alt.common.wa_title_4')">{{ $t('sdp.support.message.maddrConfirm') }}</a>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th id="registTh5" colspan="2"><label>{{ $t('sdp.support.message.tvModel') }}</label></th>
                                    <td headers="registTh5">
                                        <div class="grid-form type-model">
                                            <span class="col" v-if="memberYn == 'Y'">
                                                <span class="form-select form-size-md">
                                                    <select v-model="modelSelectChk" name="sModel1" id="sModel1" :title="$t('gwa.alt.common.wa_title_19')" @change="changeTvModel()">
                                                        <option value="" selected>{{ $t('sdp.support.combo.default') }}</option>
                                                        <option v-if="modelList.length != 0">{{ modelList.modelName }}</option>
                                                        <option value="enterInfo" >{{ $t('sdp.support.message.enterInfo') }}</option>
                                                    </select>
                                                </span>
                                            </span>
                                            <span class="col"><input type="text" v-model="modelName" name="sModel2" value="" placeholder="" :title="$t('gwa.alt.common.wa_title_20')" class="form-text form-size-md" :disabled="isDisabled('model')" /></span>
                                        </div>
                                        <div class="link-wrap">
                                            <a href="javascript:;" class="link-type1" @click="retrieveFaqInfo('MODEL')" :title="$t('gwa.alt.common.wa_title_4')">{{ $t('sdp.support.message.tvModelConfirm') }}</a>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th id="registTh6" colspan="2"><label for="sAPP" role="text">{{ $t('sdp.support.message.serviceName') }} <span class="txt-required" :aria-label="$t('gwa.alt.common.wa_label_15')" v-show="appStoreYn == 'Y'">*</span></label></th>
                                    <td headers="registTh6">
                                        <div class="grid-form ac-form-wrap">
                                            <div class="col">
                                                <input type="text" v-model="appName" name="sAPP" id="sAPP" placeholder="" class="form-text ac-keyword" @keyup="keyPress" />
                                                <!-- Auto Complete -->
                                                <div class="ac-form ac-search-static2"></div>
                                                <!-- todo
                                                <div class="ac-form" v-if="completeCheck == true">
                                                    <div class="ac-scroll">
                                                        <ul>
                                                            <li tabindex="0" v-for="value in completeKeywordList" @click="completeClick(value)" @keyup.enter="completeClick(value)">{{ value }}</li>
                                                        </ul>
                                                    </div>
                                                </div>-->
                                                <!-- //Auto Complete -->
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th id="registTh7" colspan="2"><label for="titleName" role="text">{{ $t('sdp.support.message.title') }} <span class="txt-required" :aria-label="$t('gwa.alt.common.wa_label_15')">*</span></label></th>
                                    <td headers="registTh7">
                                        <div class="grid-form">
                                            <span class="col"><input type="text" v-model="titleName" name="titleName" id="titleName" value="" placeholder="" class="form-text" required/></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th id="registTh8" colspan="2"><label for="tCntt" role="text">{{ $t('sdp.support.message.content') }} <span class="txt-required" :aria-label="$t('gwa.alt.common.wa_label_15')">*</span></label></th>
                                    <td headers="registTh8">
                                        <div class="form-textarea-wrap">
                                            <textarea name="tCntt" id="tCntt" v-model="tCntt" @keyup="checkTextLength($event);" rows="5" cols="30" :placeholder="$t('gwa.alt.support.inquiry.content.info')" class="form-textarea" required></textarea>
                                            <div class="info-area">
                                                <div class="info-desc">
                                                    <div class="form-desc bul bul-star">
                                                        <p>{{ $t('sdp.support.message.qna5') }}</p>
                                                    </div>
                                                </div>
                                                <div class="info-byte">
                                                    <div class="form-desc bul bul-star">
                                                        <p>[<span class="byte-now">{{ tCnttLength }}</span>/<span class="byte-total">{{ tMaxLength }}</span>] byte</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th id="registTh9" colspan="2"><label for="files">{{ $t('sdp.support.message.attachment') }}</label></th>
                                    <td headers="registTh1">
                                        <div class="form-file" v-show="files.length < 3">
                                            <!-- <input type="file" ref="files" id="files" value="찾아보기" tabindex="-1" aria-hidden="true" @change="handleFilesUpload()" /> multiple -->
                                            <input type="file" ref="file0" id="file0" value="찾아보기" :title="$t('gwa.alt.common.wa_title_59')+'1'" tabindex="-1" aria-hidden="true" @change="handleFilesUpload(0)" />
                                            <input type="file" ref="file1" id="file1" value="찾아보기" :title="$t('gwa.alt.common.wa_title_59')+'1'" tabindex="-1" aria-hidden="true" @change="handleFilesUpload(1)" />
                                            <input type="file" ref="file2" id="file2" value="찾아보기" :title="$t('gwa.alt.common.wa_title_59')+'1'" tabindex="-1" aria-hidden="true" @change="handleFilesUpload(2)" />

                                            <button type="button" class="btn btn-type3" @click="addFiles()" :aria-label="$t('sdp.support.message.mantoman.attachfile')" aria-describedby="AttachDescription"><span>{{ $t('sdp.support.message.mantoman.attachfile') }}</span></button>
                                            <!-- 개발참고사항 : 파일목록이 추가된 경우 hidden 속성제거-->
                                            <span class="form-static" aria-hidden="false" v-if="files.length == 0">{{ $t('sdp.inf.com.noselect') }}</span>
                                        </div>
                                        <!-- 개발참고사항 : id, aria-labelledby 연결 (컨트롤요소만 이동하는 경우 기능의 설명이 필요 -->
                                        <div class="attach-list-wrap" v-if="files.length > 0">
                                            <ul class="attach-list" id="attach-list">
                                                <li class="item" v-for="(file, key) in files">
                                                    <span class="item-label" id="fileItem1" role="text"><i class="ico ico-file" :aria-label="$t('gwa.alt.common.wa_label_16')"></i><span class="txt">{{ file.name }}</span></span>
                                                    <button type="button" class="btn-ico" aria-labelledby="fileItem1" @click="removeFile(key, file.id)"><span><i class="ico ico-del">{{ $t('gwa.alt.common.wa_label_17') }}</i></span></button>
                                                    <span class="item-size" role="text"><span :aria-label="$t('gwa.alt.common.wa_label_18')" v-html="convertFileSize(file.size)"></span><!--{{ file.size }}--></span>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="form-desc bul bul-star" id="AttachDescription">
                                            <p>{{ $t('sdp.inpuiry.message.file_text1') }}</p>
                                            <p>{{ $t('sdp.support.message.fileAttachMsg2') }}</p>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- CASE 비회원등록 -->
                    <div class="explain-footer">
                        <div class="bul bul-star">
                            <p>{{ $t('sdp.inpuiry.message.agreed_text1') }}</p>
                        </div>
                    </div>
                    <!-- //CASE 비회원등록 -->
                </div>
                <!-- //등록 입력영역 -->

                <!-- CASE 회원등록 약관동의 -->
                <div class="terms-wrap" v-show="memberYn == 'N'">
                    <!-- //입력정보 표 -->
                    <div class="explain-header">
                        <div class="bul bul-star">
                            <p>{{ $t('sdp.support.message.inquiryChk') }}</p>
                        </div>
                    </div>
                    <div class="terms-body">
                    <!-- GDPR EEA -->
                    <div class="terms-group" v-show="gdprFlag == 'Y'">
                        <div class="terms-content type2">
                            <div class="terms-inner" v-html="$t('sdp.message.memberjoin.terms.gdpr.overview1')"> <!-- sdp.message.memberjoin.terms.gdpr.overview1 -->
                            </div>
                        </div>
                    </div>
                    <div class="terms-group" v-show="perTerm.length > 0" v-for="(perData) in perTerm">
                        <div class="terms-content type2" v-show="gdprFlag == 'Y'">
                            <div class="terms-inner" v-html="perData.termsCntt">
                            </div>
                        </div>
                        <div class="terms-agree">
                            <span class="form-check">
                                <input type="checkbox" name="agree" id="agreeGdpr" v-model="agreeGdpr"/>
                                <label for="agreeGdpr"><span>{{ $t('sdp.message.memberjoin.terms.gdpr.iagree') }}</span></label> <!--sdp.message.memberjoin.terms.gdpr.iagre-->
                            </span>
                        </div>
                    </div>
                    <!-- //GDPR EEA -->
                    <template v-if="langCode == 'KOR'">
                        <!-- KR -->
                        <div class="terms-group" v-for="(prvData, index) in prvTerm">
                            <div class="terms-title" v-if="index == 0">
                                {{ $t('sdp.message.memberjoin.titleprivacy1') }}
                            </div>
                            <div class="terms-title" v-if="index == 1">
                                {{ $t('sdp.message.memberjoin.titleprivacy2') }}
                            </div>
                            <div class="terms-content" role="text">
                                <div class="terms-inner" v-html="prvData.termsCntt">
                                </div>
                            </div>
                            <div class="terms-agree">
                                <span class="form-check">
                                    <input type="checkbox" name="agree" id="agreeKOR1" v-model="agreeKOR1" v-if="index == 0"/>
                                    <label v-show="index == 0" for="agreeKOR1"><span>{{ $t('sdp.message.memberjoin.term3') }}</span></label>
                                    <input type="checkbox" name="agree" id="agreeKOR2" v-model="agreeKOR2" v-if="index == 1"/>
                                    <label v-show="index == 1" for="agreeKOR2"><span>{{ $t('sdp.message.memberjoin.term4') }}</span></label>
                                </span>
                            </div>
                        </div>
                    </template>
                    <template v-else>
                        <!-- KR이 아니면서 GDPR 국가 -->
                        <div class="terms-group" v-show="gdprFlag == 'Y'" v-for="(prvData, index) in prvTerm">
                            <div class="terms-title" v-show="index == 0">
                                {{ $t('sdp.message.memberjoin.terms.gdpr.title4') }}
                            </div>
                            <div class="terms-title" v-show="index == 1">
                                {{ $t('sdp.menu.device.menutop2.gdpr.04') }}
                            </div>
                            <div class="terms-content" role="text">
                                <div class="terms-inner" v-html="prvData.termsCntt">
                                </div>
                            </div>
                        </div>
                        <!-- KR이 아니면서 GDPR가 아닌 국가 -->
                        <div class="terms-group" v-show="gdprFlag == 'N'" v-for="(prvData, index) in prvTerm">
                            <div class="terms-title">
                                {{ $t('sdp.support.message.agreeMsg1') }}
                            </div>
                            <div class="terms-content" role="text">
                                <div class="terms-inner" v-html="prvData.termsCntt">
                                </div>
                            </div>
                            <div class="terms-agree">
                                <span class="form-check">
                                    <input type="checkbox" name="agree" id="agreeNotKOR" v-model="agreeNotKOR"/>
                                    <label v-show="index == 0" for="agreeNotKOR"><span>{{ $t('sdp.support.message.agreeMsg2') }}</span></label>
                                </span>
                            </div>
                        </div>
                    </template>
                </div>
                </div>
                <!-- //CASE 회원등록 약관동의 -->

                <!-- 등록 버튼영역 -->
                <div class="btn-wrap align-c">
                    <div class="btn-group">
                        <span class="col"><router-link to="/main/inquiry" tag="button" type="button" class="btn btn-type1" :aria-label="$t('gwa.alt.support.inquiry.cancel.001')"><span>{{ $t('sdp.support.message.cancel') }}</span></router-link></span>
                        <span class="col"><button type="button" @click="inquiryCheck();" class="btn btn-type1 btn-primary" :aria-label="$t('gwa.alt.support.inquiry.confirm.001')"><span>{{ $t('sdp.support.message.submit') }}</span></button></span>
                    </div>
                </div>
                <!-- //등록 버튼영역 -->
            </div>
            <!-- //문의등록 전체영역 -->

            <!-- 팝업_만족도조사 -->
            <FaqSatisfPop></FaqSatisfPop>
            <!-- //팝업_만족도조사 -->

            <!-- 팝업_문의등록확인 -->
            <InquiryRegisterConfirmPop></InquiryRegisterConfirmPop>
            <!-- //팝업_문의등록확인 -->

            <!-- 팝업_약관체크확인 -->
            <!--<InquiryTermValidationPop></InquiryTermValidationPop>-->
            <div id="popupTermValidation" class="popup-wrap" hidden>
                <div class="popup popup-type1" role="dialog" aria-labelledby="popupTermValidationTitle">
                    <div class="blind-area popup-focus dv-ios-only" role="text" :aria-label="$t('gwa.alt.inquiry.wa_label_1')"><!-- IOS접근성 영역자체에 초점처리 --></div>
                    <div class="popup-container">
                        <div class="popup-header">
                            <!-- 한국 + GDPR = N -->
                            <h3 class="tit-h3" v-if="termValidate != 'agreeGdpr'">{{ $t('gwa.alt.member.layerpopupagreeterm') }}</h3>
                            <!-- GDPR = Y -->
                            <h3 class="tit-h3" v-else>{{ $t('sdp.memberterm.policy.gdpr.inquiry.title') }}</h3>
                        </div>
                        <div class="popup-body popup-scroll">
                            <div class="para-wrap">
                                <!-- 한국 - 취급위탁 -->
                                <p class="para color-primary" v-if="termValidate == 'agreeKOR1'">{{ $t('refund.agree.message.confirm') }}</p>
                                <!-- 한국 - 개인정보 -->
                                <p class="para color-primary" v-if="termValidate == 'agreeKOR2'">{{ $t('gwa.alt.member.regist.terms10') }}</p>
                                <!-- GDPR 국가 -->
                                <p class="para color-primary" v-if="termValidate == 'agreeGdpr'">{{ $t('sdp.memberterm.policy.gdpr.inquiry') }}</p>
                                <!-- GDPR 및 한국 이외의 국가 -->
                                <p class="para color-primary" v-if="termValidate == 'agreeNotKOR'">{{ $t('sdp.memberterm.policy') }}</p>
                            </div>
                        </div>
                        <div class="popup-footer">
                            <div class="btn-wrap">
                                <button type="button" class="btn btn-type2 popup-close btn-secondary" aria-controls="popupTermValidation"  :title="$t('gwa.alt.common.wa_title_56')"><span>{{ $t('gwa.alt.top.payregbtn') }}</span></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- //팝업_약관체크확인 -->
            <!-- 팝업_문의구분_전체보기 -->
            <InquiryAllCategoryPop></InquiryAllCategoryPop>
            <!-- //팝업_문의확인 -->
        </div>
        <!-- //content Body -->
    </section>
    <!-- //content -->

</template>

<style>
</style>

<script>

    import qs from "qs";
    import InquiryRegisterConfirmPop from '@/components/inquiry/InquiryRegisterConfirmPop';
    import FaqSatisfPop from '@/components/faq/FaqSatisfPop';
    import InquiryAllCategoryPop from '@/components/inquiry/InquiryAllCategoryPop';


    export default {
        name: "inquiryRegister",
        components: {
            InquiryRegisterConfirmPop,
            FaqSatisfPop,
            InquiryAllCategoryPop
        },
        data() {
            return {
                preEmail : "", // 비회원 이메일
                endEmail : "", // 비회원 이메일
                userId : "", // 회원 아이디
                email : "", // 회원 이메일
                maddrList : [],
                modelList : [],
                macAddress : "", // MAX Address
                modelName : "", // TV Model No
                maddrYn : "N",
                modelYn : "N",
                appName : "", // appName
                titleName : "", // 제목
                tCntt : "", // 내용
                files : [], // 첨부파일
                serviceList : [], // 서비스
                categoryList : [], // 항목
                typeList : [], // 유형
                typeFaqList : [],
                typeDiagList : [],
                typeFaqHashTag : [],
                typeDiagHashTag : [],
                typeFaqCount : 0,
                typeDiagCount : 0,
                typeShow : false,
                memberYn : "N",
                macInfoSeq : 0,
                modelInfoSeq : 0,
                cateCode1 : "", // 서비스
                cateCode2 : "", // 항목
                cateCode3 : "", // 유형
                // 약관  -------- 비회원
                perTerm : [],
                perTermSize : 0,
                prvTerm : [],
                prvTermSize : [],
                langCode : "",
                gdprFlag : "N",
                gdprTermsData : false,
                agreeNotKOR : false, // KR이 아닐 경우 약관 체크
                agreeKOR1 : false, // KR일 경우 1 약관 체크
                agreeKOR2 : false, // KR일 경우 2 약관 체크
                agreeGdpr : false, // GDPR 국가 약관 체크
                tCnttLength : 0,
                tMaxLength : 4000,
                sMaxLength : 500,
                titleClickYn: "N",
                appStoreYn : "N",
                termValidate : "",
                loadingYn: "N",
                diagActiveYn : true,
                completeKeywordList : [],
                completeCheck : false,
                macSelectChk : "",
                modelSelectChk : "",
                cntryCode: _domainCntryCode
            }
        },
        created() {
        },
        destroyed() {
        },
        watch: {
        },
        computed: {
            isDiagActive () {
                if (this.diagActiveYn) {
                    return "is-active";
                } else {
                    return "";
                }
            },
            isFaqActive () {
                if (this.diagActiveYn == false) {
                    return "is-active";
                } else {
                    return "";
                }
            }
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            keyPress(e) {
                // arrow key down, up
                if(e.which == 40 || e.which == 38 ) {
                    return;
                } else if (e.which == 13) {
                    this.appName = $('#sAPP').val();
                } else {
                    this.autoSearchText();
                }
            },
            goLgaccount() {
                var params = {
                    cntryCode: _domainCntryCode,
                    path: 'inquiry'
                }
                this.$axios.post('/api/main/retrieveLoginInfo.ajax', qs.stringify(params)).then((result) => {
                    var loginUrl = result.data.loginUrl;
                    window.location = loginUrl;
                }).catch((err) => {
                    alert(err);
                });
            },
            isDisabled (type) {
                if (type == 'maddr') {
                    if (this.memberYn == "Y" && this.maddrYn == 'N') {
                        return true;
                    } else {
                        return false;
                    }
                } else if (type == 'model') {
                    if (this.memberYn == "Y" && this.modelYn == 'N') {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    if (this.satisf.rsnType == "ETC") {
                        return false;
                    } else {
                        return true;
                    }
                }
            },
            changeService(event, lowLevelNo) {
                const vm = this;

                // 초기화
                if (lowLevelNo == 2) {
                    vm.categoryList = [];
                    vm.cateCode2 = "";
                    if (event.target.value == 1003) { // 앱 스토어 / 콘텐츠일 경우 서비스명 필수값
                        vm.appStoreYn = 'Y'
                    } else {
                        vm.appStoreYn = 'N'
                    }
                }
                vm.typeList = [];
                vm.cateCode3 = "";
                vm.searchType = "";

                const params = {
                    highCatCode: event.target.value,
                    catLevelNo: lowLevelNo
                };
                this.$axios.post("/api/inquiry/retrieveInquiryCategoryList.ajax", qs.stringify(params)).then((result) => {
                    if(lowLevelNo == 2) {
                        vm.categoryList = result.data.categoryList;
                    }
                    if(lowLevelNo == 3) {
                        vm.typeList = result.data.categoryList;
                    }
                }).catch((error) => {
                    alert("error");
                });
            },
            changeType() {
                const vm = this;

                const params = {
                    perQuestCatCode : vm.cateCode3
                };

                this.$axios.post("/api/inquiry/retrieveInquiryTypeList.ajax", qs.stringify(params)).then((result) => {

                    vm.typeFaqList = result.data.faqList;
                    vm.typeDiagList = result.data.diagList;
                    vm.typeFaqCount = result.data.faqCount;
                    vm.typeDiagCount = result.data.diagCount;

                    if (vm.typeFaqList.length > 0) {
                        vm.typeFaqHashTag = result.data.faqHashTag;
                    }

                    if (vm.typeDiagList.length > 0) {
                        vm.typeDiagHashTag = result.data.diagHashTag;
                    }

                    if (vm.typeDiagList.length > 0) {
                        vm.diagActiveYn = true;
                    } else {
                        if (vm.typeFaqList.length > 0) {
                            vm.diagActiveYn = false;
                        } else {
                            vm.diagActiveYn = true;
                        }
                    }

                    if (vm.typeFaqList != null || vm.typeDiagList != null) {
                        vm.typeShow = true; // 항목 리스트 노출
                    }

                    vm.$nextTick(function() {
                        ui.tab.init();
                        ui.faqAccordion.init();
                    });

                }).catch((error) => {
                    alert("error");
                });
            },
            changeMacAddress() {

                if (event.target.value == 'enterInfo') {
                    this.maddrYn = 'Y';
                    isDisabled ('maddr');
                } else if (event.target.value != ''){

                    this.macAddress = event.target.value;

                    const params = {
                        maddr: this.macAddress,
                    };

                    this.$axios.post("/api/inquiry/retrieveModelList.ajax", qs.stringify(params)).then((result) => {
                        this.modelList = result.data.modelList;
                    }).catch((err) => {
                        alert("error : " + err);
                    });
                }

            },
            changeTvModel() {

                if (event.target.value == 'enterInfo') {
                    this.modelYn = 'Y';
                    isDisabled ('model');
                } else {
                    this.modelName = event.target.value;
                }

            },
            readCntt(seqNo) {
                this.$store.state.faqSeqNo = seqNo;
                this.$store.state.satisfType = 'faq';

                const vm = this;
                if(seqNo != vm.faqSeqNo) {
                    vm.faqSeqNo = seqNo;
                    vm.updateViewCnt(seqNo);
                } else {
                    if(vm.titleClickYn == 'Y') {
                        vm.titleClickYn = 'N';
                    } else {
                        vm.updateViewCnt(seqNo);
                    }
                }
            },
            goSatisf(clickType) {
                const vm = this;

                const params = {
                    clickType: clickType,
                    faqSeqNo: vm.faqSeqNo
                };

                this.$axios.post("/api/faq/mergeFaqSatisf.ajax",
                    qs.stringify(params)).then((result) => {
                    alert(this.$t('sdp.Satisfaction.message.pop_text6'));
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            updateDiagViewCnt(seqNo, catCode1) {
                const vm = this;
                vm.diagSeqNo = seqNo;
                vm.diagCatCode1 = catCode1;

                const params = {
                    seqNo: vm.diagSeqNo
                };

                this.$axios.post("/api/diag/updateDiagViewCnt.ajax",
                    qs.stringify(params)).then((result) => {
                    const r = { path : "/main/diag/detail?seqNo=" + vm.diagSeqNo + "&catCode1="
                    + vm.diagCatCode1 + "&searchYn=N&allClickYn=N&schTxt=&curPage=1" };
                    this.$router.push(r);
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            updateViewCnt(seqNo) {
                const vm = this;
                const params = {
                    seqNo: seqNo
                };
                this.$axios.post("/api/faq/updateFaqViewCnt.ajax", qs.stringify(params)).then((result) => {
                    vm.titleClickYn = 'Y';
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            retrieveFaqInfo (type) {
                if (type == 'MAC') {
                    const macUrl = window.location.protocol + "//" + window.location.host + '/main/faq?seqNo=' + this.macInfoSeq;
                    window.open(macUrl, '_blank');
                    /*const r = { path : `/main/faq?seqNo=${this.macInfoSeq}`};
                    this.$router.push(r);*/
                } else {
                    const modelUrl = window.location.protocol + "//" + window.location.host + '/main/faq?seqNo=' + this.modelInfoSeq;
                    window.open(modelUrl, '_blank');
                    /*const r = { path : `/main/faq?seqNo=${this.modelInfoSeq}`};
                    this.$router.push(r);*/
                }
            },
            checkSubjectLength (subject) {
                var strLength = this.getStrByte(subject);
                if (strLength > this.sMaxLength) {
                    return true;
                } else {
                    return false;
                }
            },
            checkTextLength (event) {
                var strValue = event.target.value;
                var strLength = this.getStrByte(event.target.value);

                /*alert(event.target.value);*/
                if (strLength <= this.tMaxLength) {
                    this.tCnttLength = strLength;
                } else {
                    strValue = this.strCutByByte(strValue, this.tMaxLength);
                    strLength = this.getStrByte(strValue);
                    this.tCntt = strValue;
                    this.tCnttLength = strLength;

                    return;
                }
            },
            strCutByByte (str, max) {
                var byteLength = 0;
                var result = "";

                for (var inx = 0; inx < str.length; inx++) {
                    var oneChar  = str.charAt(inx);
                    var charCode = oneChar.charCodeAt(0);
                    if(charCode)
                        if(charCode != 13){
                            if (charCode <= 0x00007F) {
                                byteLength ++;
                            }else if (charCode <= 0x0007FF) {
                                byteLength += 2;
                            }else if (charCode <= 0x00FFFF) {
                                byteLength += 3;
                            } else {
                                byteLength += 4;
                            }
                        }

                    if (byteLength > max) {
                        break;
                    }
                    result = result + str.charAt(inx);
                }

                return result;
            },
            getStrByte(value) {

                console.log('getStrByte ' + 'Enter');
                var byteLength = 0, ch;
                var charCode;
                var len = value.length;
                for(var i = 0; i < len; i++) {
                    ch = value.charAt(i);
                    charCode = ch.charCodeAt(0);
                    if(charCode)
                        if(charCode != 13){ // enter값이 2번 넘어온다.10,13 10번은 화면 test 시  나오지만 13번은 나오지 않아 13번을 막음.
                            if (charCode <= 0x00007F) {
                                byteLength ++;
                            }else if (charCode <= 0x0007FF) {
                                byteLength += 2;
                            }else if (charCode <= 0x00FFFF) {
                                byteLength += 3;
                            } else {
                                byteLength += 4;
                            }
                        }
                }
                return byteLength;
            },
            completeClick(valueText) {
                this.appName = valueText;
                this.completeCheck = false;
            },
            autoSearchText() {

                const keyword = $('#sAPP').val().toLowerCase();

                var params = {
                    searchText : keyword
                };

                const vm = this;

                this.$axios.post("/api/integratedSearch/retrieveAutoSearch.ajax", qs.stringify(params)).then((result) => {

                    if(result.data.completeKeywordList == undefined) {
                        vm.completeKeywordList = []
                    } else {
                        vm.completeKeywordList = result.data.completeKeywordList;
                    }

                    $("#sAPP").autocomplete("option", "source", vm.completeKeywordList);
                    $("#sAPP").autocomplete( "search", keyword );

                    /*this.$nextTick(function() {
                        vm.completeKeywordList = result.data.completeKeywordList;
                        console.log("completeKeywordList", vm.completeKeywordList);

                        $("#sAPP").autocomplete({
                            appendTo: ".ac-search-static2",
                            source : vm.completeKeywordList,
                            messages: {
                                noResults: '',
                                results: function() {}
                            }
                        });
                    })*/
                }).catch((error) => {
                    alert("error");
                });
            },
            handleFilesUpload(id) {
                let uploadFiles = this.$refs['file' + id].files[0];
                uploadFiles.id = id;

                let fileSize = 10458760; // 10MB
                const fileExt = uploadFiles.name.slice(uploadFiles.name.indexOf(".") + 1).toLowerCase(); // 파일 Name

                if ('png' != fileExt && 'gif' != fileExt && 'jpg' != fileExt) {
                    // png, gif, jpg만
                    alert(this.$t('sdp.support.message.fileAttachMsg2'));
                    return;
                }

                if (this.files.length >= 3) {
                    // MAX 3개까지
                    alert(this.$t("sdp.support.message.attachInfoMsg2"));
                    return;
                }

                if (uploadFiles.size > fileSize) {
                    // 10MB 까지
                    alert(this.$t("sdp.support.message.fileAttachMsg1"));
                    return;
                }

                this.files.push(uploadFiles);

            },
            convertFileSize(size) {
                //MB로 단위 변경
                var fileSize = size / 1024.0 / 1024.0;
                fileSize = fileSize.toFixed(2) + "MB";
                return fileSize;
            },
            addFiles() {
                var file0 = false;
                var file1 = false;
                var file2 = false;
                for(var i = 0; i < this.files.length; ++i) {
                    var file = this.files[i];
                    if(file.id == 0) {
                        file0 = true;
                    }
                    if(file.id == 1) {
                        file1 = true;
                    }
                    if(file.id == 2) {
                        file2 = true;
                    }
                }

                if(file0 == false) {
                    this.$refs.file0.click();
                    return
                }
                if(file1 == false) {
                    this.$refs.file1.click();
                    return
                }
                if(file2 == false) {
                    this.$refs.file2.click();
                    return
                }
            },
            removeFile(key, id) {
                // console.log(key, id)
                this.$refs['file' + id].value = ''
                this.files.splice(key, 1);
            },
            lineBreakCntt(cntt) {
                if(cntt != null && cntt != "") {
                    return cntt.split("\n").join("<br />");
                } else {
                    return "";
                }
            },
            inquiryCheck() {
                ui.loading.open();
                const vm = this;
                var email = "";
                var nChk = 0; // 약관동의 갯수

                if (vm.gdprFlag == "Y" && vm.gdprTermsData == false) {
                    alert(this.$t('sdp.member.message.termpolicyerror'));
                    ui.loading.close();
                    return;
                }

                // 필수값 validation
                if (vm.preEmail == null || vm.preEmail == "") {
                    alert(this.$t('sdp.warn.com.input', { var1 : this.$t('sdp.support.message.recvEmail') }));
                    ui.loading.close();
                    //document.getElementById("preEmail").focus();
                    setFocusScroll('#preEmail');
                    return;
                }
                if (vm.endEmail == null || vm.endEmail == "") {
                    alert(this.$t('sdp.warn.com.input', { var1 : this.$t('sdp.support.message.recvEmail') }));
                    ui.loading.close();
                    //document.getElementById("endEmail").focus();
                    setFocusScroll('endEmail');
                    return;
                }
                if (vm.cateCode1 == null || vm.cateCode1 == "") {
                    alert(this.$t('sdp.warn.com.input', { var1 : this.$t('sdp.support.message.catType1') }));
                    ui.loading.close();
                    //document.getElementById("cateCode1").focus();
                    setFocusScroll('#cateCode1');
                    return;
                } else if(vm.cateCode1 == 1003 && vm.appName == '') {
                    // 서비스 -> 앱 스토어 / 콘텐츠일 경우 서비스명 필수값
                    alert(this.$t('sdp.warn.com.input', { var1 : this.$t('sdp.support.message.serviceName') }));
                    ui.loading.close();
                    //document.getElementById("sAPP").focus();
                    setFocusScroll('#sAPP');
                    return;
                }
                if (vm.cateCode2 == null || vm.cateCode2 == "") {
                    alert(this.$t('sdp.warn.com.input', { var1 : this.$t('sdp.support.message.catType2') }));
                    ui.loading.close();
                   // document.getElementById("cateCode2").focus();
                    setFocusScroll('#cateCode2');
                    return;
                }
                if (vm.cateCode3 == null || vm.cateCode3 == "") {
                    alert(this.$t('sdp.warn.com.input', { var1 : this.$t('sdp.support.message.catType3').replace("<span class=\"dis-ib\">","").replace("</span>", "") }));
                    ui.loading.close();
                    //document.getElementById("cateCode3").focus();
                    setFocusScroll('#cateCode3');
                    return;
                }
                if (vm.titleName == null || vm.titleName == "") {
                    alert(this.$t('sdp.warn.com.input', { var1 : this.$t('sdp.support.message.title') }));
                    ui.loading.close();
                    //document.getElementById("titleName").focus();
                    setFocusScroll('titleName');
                    return;
                }
                if (this.checkSubjectLength(vm.titleName)) {
                    alert(this.$t('requisite.maxlength', { var1 : this.$t('sdp.support.message.title'), var2 : this.sMaxLength }));
                    ui.loading.close();
                    //document.getElementById("titleName").focus();
                    setFocusScroll('#titleName');
                    return;
                }
                if (vm.tCntt == null || vm.tCntt == "") {
                    alert(this.$t('sdp.warn.com.input', { var1 : this.$t('sdp.support.message.content') }));
                    ui.loading.close();
                    //document.getElementById("tCntt").focus();
                    setFocusScroll('#tCntt');
                    return;
                }

                //email check
                if (vm.memberYn == "Y") {
                    // 회원인 경우
                    email = vm.preEmail + "@" + vm.endEmail;

                } else {
                    // 비회원인 경우
                    if (vm.gdprFlag == "Y") {
                        nChk = parseInt(vm.perTermSize);
                    } else {
                        nChk = parseInt(vm.prvTermSize);
                    }

                    const checkboxAll = document.querySelectorAll('input[name=agree]:checked').length;

                    if (checkboxAll != nChk) { // 약관동의 미완료
                        if (vm.langCode == 'KOR') {
                            // 한국
                            if (vm.agreeKOR1 == false) {
                                // 개인정보 수집 이용
                                this.termValidate = "agreeKOR1";
                                ui.loading.close();
                                ui.popup.open("popupTermValidation");
                                return;
                            }
                            if (vm.agreeKOR2 == false) {
                                // 개인정보 취급위탁
                                this.termValidate = "agreeKOR2";
                                ui.loading.close();
                                ui.popup.open("popupTermValidation");
                                return;
                            }
                        } else {
                            // 한국 이외 국가
                            if (vm.gdprFlag == "Y") {
                                // gfpr 국가
                                if (vm.agreeGdpr == false) {
                                    this.termValidate = "agreeGdpr";
                                    ui.loading.close();
                                    ui.popup.open("popupTermValidation");
                                    return;
                                }
                            } else {
                                if (vm.agreeNotKOR == false) {
                                    this.termValidate = "agreeNotKOR";
                                    ui.loading.close();
                                    ui.popup.open("popupTermValidation");
                                    return;
                                }
                            }
                        }
                    }

                    email = vm.preEmail + "@" + vm.endEmail;
                }

                vm.inquiryEmailCheck(email);

            },
            inquiryEmailCheck (email) {
                const params = {
                    email : email
                };

                var resultFlag;

                this.$axios.post("/api/inquiry/emailValidation.ajax", qs.stringify(params)).then((result) => {

                    resultFlag = result.data.resultFlag;
                    if (!resultFlag) {
                        // 비정상이메일
                        alert(this.$t('sdp.support.message.email') + " : " + this.$t('sdp.member.message.emailfail2'));
                        ui.loading.close();
                        document.getElementById("preEmail").focus();
                        return;
                    }
                    this.inquirySetting(email);

                }).catch((error) => {
                    alert("error");
                });

            },
            inquirySetting(email) {

                const vm = this;
                vm.loadingYn = "Y";

                let formData = new FormData();

                // file Setting
                for (var i = 0; i < vm.files.length; i++) {
                    let file = vm.files[i];

                    formData.append("files", file);
                }

                var macAddressUpper = vm.macAddress.toUpperCase();

                formData.append("email", email);
                formData.append("catType1", vm.cateCode1);
                formData.append("catType2", vm.cateCode2);
                formData.append("catType3", vm.cateCode3);
                formData.append("titleName", vm.titleName);
                formData.append("cntt", vm.tCntt);
                formData.append("tvModel", vm.modelName);
                formData.append("maddr", macAddressUpper);
                formData.append("purchaseAppInput", $('#sAPP').val()); // autoComplete 처리
                formData.append("agreeKOR1", vm.agreeKOR1);
                formData.append("agreeKOR2", vm.agreeKOR2);
                formData.append("agreeNotKOR", vm.agreeNotKOR);
                formData.append("agreeGdpr", vm.agreeGdpr);
                formData.append("macSelectChk", vm.macSelectChk);
                formData.append("modelSelectChk", vm.modelSelectChk);
                formData.append("totalFileNum", vm.files.length);


                var url = "";
                /*var params = {};*/
                var header = {};

                if (this.memberYn == 'Y') {
                    url = "/api/inquiry/inquiryRegisterMember.ajax";
                } else {
                    url = "/api/inquiry/inquiryRegisterNonMember.ajax";
                }

                header = {
                    headers : {
                        'Content-Type': 'multipart/form-data'
                    }
                };

                vm.InquiryRegister(url, formData, header);
            },
            InquiryRegister(url, formData, header) {

                this.$axios.post(url, formData, header).then((result) => {
                    ui.loading.close();

                    const successFlag = result.data.message;

                    console.log("successFlag" + successFlag);
                    if (successFlag) {
                        // 성공할 경우
                        console.log("등록완료");

                        // Vuex 초기화
                        this.$store.state.inquiryCateCode1 = "";
                        this.$store.state.inquiryCateCode2 = "";
                        this.$store.state.inquiryCateCode3 = "";

                        ui.popup.open("popupRegisterComp");
                    } else {
                        // 실패할 경우
                        console.log("등록실패");
                        this.loadingYn = "N";
                        alert(this.$t('sdp.err.cm.authentication'));
                    }
                }).catch((error) => {
                    ui.loading.close();
                    this.loadingYn = "N";
                    alert("error");
                });
            }
        },
        mounted() {

            const vm = this;
            /*vm.$nextTick(function() {
                ui.init();
            });*/

            if (typeof vm.$route.query.cateCode1 == 'undefined') {
                vm.cateCode1 = "";
            } else {
                vm.cateCode1 = vm.$route.query.cateCode1;
            }
            if (typeof vm.$route.query.cateCode2 == 'undefined') {
                vm.cateCode2 = "";
            } else {
                vm.cateCode2 = vm.$route.query.cateCode2;
            }

            if (typeof vm.$route.query.cateCode3 == 'undefined') {
                vm.cateCode3 = "";
            } else {
                vm.cateCode3 = vm.$route.query.cateCode3;
            }

            if (vm.cateCode3 != "") {
                vm.changeType();
            }

            var qrcodeData = this.$route.query.qrcodedata;

            const params = {
                cateCode1 : vm.cateCode1,
                cateCode2 : vm.cateCode2,
                cateCode3 : vm.cateCode3,
                qrcodeData: qrcodeData
            };

            this.$axios.post("/api/inquiry/retrieveInquiryRegister.ajax", qs.stringify(params)).then((result) => {
                vm.memberYn = result.data.memberYn;
                vm.userId = result.data.userId;
                if (vm.memberYn == 'Y') {
                    vm.email = result.data.userEmail;
                    var preEmail = vm.email.split("@")[0];
                    var endEmail = vm.email.split("@")[1];

                    vm.preEmail = preEmail;
                    vm.endEmail = endEmail;

                    vm.maddrList = result.data.maddrList;
                }

                vm.serviceList = result.data.serviceList;

                if(result.data.categoryList != null && result.data.categoryList.length > 0) {
                    vm.categoryList = result.data.categoryList;
                }

                if(result.data.typeList != null && result.data.typeList.length > 0) {
                    vm.typeList = result.data.typeList;
                }

                vm.perTerm = result.data.perTerm;
                vm.perTermSize = result.data.perTermSize;
                vm.prvTerm = result.data.prvTerm;
                vm.prvTermSize = result.data.prvTermSize;
                vm.langCode = result.data.langCode;
                vm.gdprFlag = result.data.gdprFlag;
                vm.gdprTermsData = result.data.gdprTermsData;

                // Info Seq No (FAQ)
                vm.macInfoSeq = result.data.macInfoSeq;
                vm.modelInfoSeq = result.data.modelInfoSeq;


                var qrcode = result.data.qrcode;
                if(qrcode != undefined || qrcode != null) {
                    vm.macAddress = qrcode.macAddress;
                    vm.modelName = qrcode.modelName;
                }

                if (vm.$route.query.cateCode1 == 1003) { // 앱 스토어 / 콘텐츠일 경우 서비스명 필수값
                    vm.appStoreYn = 'Y'
                } else {
                    vm.appStoreYn = 'N'
                }

                vm.$nextTick(function() {
                    ui.init();
                    ui.faqAccordion.init();

                    $("#sAPP").autocomplete({
                        appendTo: ".ac-search-static2",
                        source : vm.completeKeywordList,
                        messages: {
                            noResults: '',
                            results: function() {}
                        }
                    });

                    ui.searchAll.closeCallback = function() {
                        vm.searchText = '';
                    }
                });

            }).catch((error) => {
                alert("error");
            });
        }
    }
</script>