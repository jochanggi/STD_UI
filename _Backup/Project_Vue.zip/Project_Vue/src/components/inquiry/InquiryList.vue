<template>
	<!-- Content -->
		<section id="content" class="content mypage-cont">
			<!-- Content Header -->
			<!-- 고도화 ver2 : 클래스 has-search삭제, centered-c추가 -->
			<div class="content-header sub-visual">
                <div class="sub-visual-bg"></div>
				<div class="in-sec">
					<div class="tit-wrap centered-c">
						<h2 class="tit-h2">{{ $t('sdp.menu.qna') }}</h2>
						<p class="explain-h2" v-html="$t('sdp.inpuiry.message.title1')"></p>
					</div>
				</div>
			</div>
			<!-- //Content Header -->

			<!-- Content Body -->
			<div class="content-body">
				<!-- 게시판 전체영역 -->
				<div class="board-wrap in-sec">
					<!-- 목록게시판 -->
					<div class="board-list-wrap">
						<!-- 목록그룹
							개발참고 클래스명 구분
							문의접수 : label-state1
							문의확인 : label-state2
							담당부서 확인중 : label-state3
							답변완료 : label-state4
							처리완료 : label-state5
						-->
						<div class="section-body" v-if="loadingYn == 'Y'">
							<div class="loading-wrap">
								<div class="loading"><img src="/img/cmn/loading.png" alt="로딩중"></div>
							</div>
						</div>
						<div class="board-list" v-else-if="inquiryList.length > 0">
							<table class="tbl-responsive">
								<caption>
									<div class="blind-area" role="text">
										<strong>1:1문의안내 목록</strong>
										<p>번호, 제목, 작성일자, 문의상태로 구성되었습니다.</p>
									</div>
								</caption>
								<thead>
									<tr>
										<th id="boardListNo">{{ $t('gwa.alt.support.inquiry.no') }}</th>
										<th id="boardListSubject">{{ $t('sdp.support.message.title') }}</th>
										<th id="boardListDate">{{ $t('sdp.support.message.date') }}</th>
										<th id="boardListState">{{ $t('sdp.support.message.inquiryStatus') }}</th>
									</tr>
								</thead>
								<tbody>
									<!-- 등록된 게시물 -->
									<tr v-for="(inquiry, index) in inquiryList">
										<td headers="boardListNo">{{ index+1 }}</td>
										<td headers="boardListSubject" class="align-l">
											<a href="javascript:;" @click="retrieveInquiryDetail(inquiry.seqNo)" class="link-wrap has-state" title="상세페이지로 이동">
												<!--<em class="label-type1" role="text">공지</em>--><span class="link-text">{{ inquiry.titleName }}</span><span :class="'link-state '+changeStatus(inquiry.replStatCode)">{{ inquiry.replStatCodeName }}</span>
												<i class="arw arw-next2 centered-r" aria-hidden="true"></i>
											</a>
										</td>
										<td headers="boardListDate">{{ inquiry.cDate }}</td>
										<td headers="boardListState"><span :class="changeStatus(inquiry.replStatCode)">{{ inquiry.replStatCodeName }}</span></td>
									</tr>
									<!-- //등록된 게시물 -->
								</tbody>
							</table>
						</div>
						<!-- //목록그룹 -->
						<!-- 미등록게시물 -->
						<div class="noData-wrap" v-else>
							<div class="noData">
								<div class="inner">
									<p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
								</div>
							</div>
						</div>
						<!-- //미등록게시물 -->

						<!-- 게시판설명 -->
						<!-- 고도화 ver1 : 구조 안내보기 수정 -->
						<div class="explain-footer" v-if="langCode =='KOR'">
							<div class="bul bul-bill">
								<p>장기 미사용 고객의 계정 삭제로 인한 로그인 불가 현상</p>
							</div>
							<div class="btn-wrap align-c">
								<a :href="url.pcNoticeUrl" class="btn btn-type5">안내보기</a>
							</div>
						</div>
						<!-- //게시판설명 -->
					</div>
					<!-- //목록게시판 -->

					<!-- 페이징 개발참고(선택된 현재페이지 번호)
							1. span태그로 변경
							2. aria-current="true"를 추가
							3. role="text"로 변경
					-->
					<div class="pagination-wrap" v-if="paging.totalCount > 0">
						<div class="pagination">
							<div class="btn-wrap">
								<a v-show="paging.hasFirst" @click="goFirstPage()" href="javascript:;" class="btn-ico btn-page first" role="button"><span><i class="ico ico-page-first">{{ $t('sdp.menu.qna') }} 처음 페이지</i></span></a>
								<a v-show="paging.hasPrev" @click="goPrevPage()" href="javascript:;" class="btn-ico btn-page prev" role="button"><span><i class="ico ico-page-prev">{{ $t('sdp.menu.qna') }} 이전 페이지</i></span></a>
							</div>
							<ul class="num-wrap">
								<li v-for="page in paging.pageList">
									<span v-show="page.num == paging.curPage" class="btn btn-num" aria-current="true" role="text" :aria-label="$t('sdp.menu.qna')+' '+page.num+' 페이지'"><span>{{ page.num }}</span></span>
									<a v-show="page.num != paging.curPage" @click="goPage(page.num)" href="javascript:;" class="btn btn-num" role="button" :aria-label="$t('sdp.menu.qna')+' '+page.num+' 페이지'"><span>{{ page.num }}</span></a>
								</li>
							</ul>
							<div class="btn-wrap">
								<a v-show="paging.hasNext" @click="goNextPage()" href="javascript:;" class="btn-ico btn-page next" role="button"><span><i class="ico ico-page-next">{{ $t('sdp.menu.qna') }} 다음 페이지</i></span></a>
								<a v-show="paging.hasLast" @click="goLastPage()" href="javascript:;" class="btn-ico btn-page last" role="button"><span><i class="ico ico-page-last">{{ $t('sdp.menu.qna') }} 마지막 페이지 </i></span></a>
							</div>
						</div>
					</div>
					<!-- //페이징 -->

					<!-- 버튼영역 -->
					<div class="board-btn-wrap">
						<button type="button" @click="retrieveInquiryRegister()" class="btn btn-type1 btn-lg"><span>{{ $t('sdp.inpuiry.message.btn_inquiry') }}</span></button>
					</div>
					<!-- //버튼영역 -->
				</div>
				<!-- //게시판 전체영역 -->

				<!-- 문의상태 안내 -->
				<div class="csinfo-wrap in-sec">
					<div class="csinfo-box">
						<div class="inner">
							<div class="csinfo-header">
								<h3 class="tit-h3">{{ $t('sdp.support.message.qnastatusinfo') }}</h3>
							</div>
							<div class="csinfo-body">
								<dl class="define bul-dt bul-dot bul-primary" v-html="$t('sdp.support.message.qnastatusdesc1')">
								</dl>
								<dl class="define bul-dt bul-dot bul-primary" v-html="$t('sdp.support.message.qnastatusdesc2')">
								</dl>
								<dl class="define bul-dt bul-dot bul-primary" v-html="$t('sdp.support.message.qnastatusdesc3')">
								</dl>
								<dl class="define bul-dt bul-dot bul-primary" v-html="$t('sdp.support.message.qnastatusdesc4')">
								</dl>
								<dl class="define bul-dt bul-dot bul-primary" v-html="$t('sdp.support.message.qnastatusdesc5')">
								</dl>
							</div>
						</div>
					</div>
				</div>
				<!-- //문의상태 안내 -->

				<!-- 제휴문의안내 -->
				<div class="ques-coalition-wrap in-sec">
					<div class="ques-coalition">
						<ul class="grid">
							<li class="col">
								<a :href="url.mobileSmartWorldUrl" target="_blank" :title="$t('gwa.alt.common.wa_title_4')" class="item" role="button">
									<dl>
										<dt class="tit">LG Smart World <span class="dis-ib">(Mobile)</span></dt>
										<dd class="txt" role="text" v-html="$t('sdp.inpuiry.message.link1') + '<i class=\'ico ico-mobile\' aria-hidden=\'true\'></i>'"></dd>
									</dl>
								</a>
							</li>
							<li class="col">
								<a :href="url.slUrl" target="_blank" :title="$t('gwa.alt.common.wa_title_4')" class="item" role="button">
									<dl>
										<dt class="tit">Seller Lounge</dt>
										<dd class="txt" role="text">{{ $t('sdp.inpuiry.message.link2') }} <i class="ico ico-seller" aria-hidden="true"></i></dd>
									</dl>
								</a>
							</li>
							<li class="col">
								<a :href="url.devUrl" target="_blank" :title="$t('gwa.alt.common.wa_title_4')" class="item" role="button">
									<dl>
										<dt class="tit">LG Developer</dt>
										<dd class="txt" role="text" v-html="$t('sdp.inpuiry.message.link3') + '<i class=\'ico ico-developer\' aria-hidden=\'true\'></i>'"></dd>
									</dl>
								</a>
							</li>
						</ul>
					</div>
				</div>
				<!-- //제휴문의안내 -->
			</div>
			<!-- //Content Body -->
		</section>
	<!-- //Content -->
</template>

<script>
    import qs from "qs";
    
    export default {
        name: "InquiryList",
        data() {
            return {
                url : {
					slUrl : "",
					devUrl : "",
					pcNoticeUrl : "",
                    mobileSmartWorldUrl : "",
				},
                langCode : "",
				inquiryList : [],
                paging: {
                    pageList: [],
                    totalCount: 0,
                    pageCount: 0,
                    curPage: 1,
                    hasNext: false,
                    hasLast: false,
                    hasPrev: false,
                    hasFirst: false,
                    curMaxPage: 0,
                    curMinPage: 1
                },
				loadingYn: "Y"
            }
        },
        created() {
        },
        watch: {
        },
        computed: {
        },
        methods: {
			track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            changeStatus(status) {
                if (status == 'PM6103') {
					// 문의 접수
					return 'label-state1'
				} else if (status == 'PM6102') {
                    // 문의 확인
					return 'label-state2'
				} else if (status == 'PM6107') {
                    // 담당부서 확인중
                    return 'label-state3'
				} else if (status == 'PM6101') {
                    // 답변완료
                    return 'label-state4'
                } else if (status == 'PM6102') {
                    // 처리완료
                    return 'label-state5'
                }
            },
            goFirstPage() {
				console.log('goFirstPage');
				this.paging.curPage = this.paging.curMinPage - 1;
				this.retrieveMemberInquiryList();
			},
            goPrevPage() {
                console.log('goPrevPage');
                this.paging.curPage -= 1;
                this.retrieveMemberInquiryList();
            },
            goNextPage() {
                console.log('goNextPage');
                this.paging.curPage += 1;
                this.retrieveMemberInquiryList();
            },
            goLastPage() {
                console.log('goLastPage');
                this.paging.curPage = this.paging.curMaxPage + 1;
                this.retrieveMemberInquiryList();
            },
            goPage(page) {
                this.paging.curPage = page;
                this.retrieveMemberInquiryList();
            },
            _setResult(result) {
                this.inquiryList = result.data.inquiryList;
                this.paging.totalCount = result.data.totalCount;
                this.paging.pageCount = result.data.pageCount;
                this.paging.curPage = result.data.curPage;
                this.paging.rowCount = result.data.rowCount;

                this.langCode = result.data.langCode;

                ui.loading.close();
                this.loadingYn = "N";
            },
            retrieveMemberInquiryList() {
                const vm = this;
                console.log('retrieveMemberInquiryList');

                ui.loading.open();
                vm.loadingYn = "Y";

                const params = {

                    curPage: this.paging.curPage,
                    rowCount: this.paging.rowCount,
                    pageCount: this.paging.pageCount,
                    totalCount: this.paging.totalCount
                };
                console.log('retrieveMemberInquiryList', params);
                this.$axios.post('/api/inquiry/retrieveMemberInquiryList.ajax', qs.stringify(params)).then((result) => {
                    vm._setResult(result);
                    vm._resetPageList();
                }).catch((err) => {
                    ui.loading.close();
                    vm.loadingYn = "N";
                    alert('error ' + err);
                });
            },
            retrieveInquiryDetail(seqNo) {
                const r = { path : "/main/inquiry/detail?seqNo=" + seqNo };
                this.$router.push(r);
			},
            _resetPageList() {

                var maxPage = Math.floor(this.paging.totalCount / this.paging.rowCount);
                if(this.paging.totalCount % this.paging.rowCount != 0) {
                    maxPage += 1;
                }

                this.paging.curMaxPage = Math.floor((this.paging.curPage - 1) / this.paging.pageCount) * this.paging.pageCount + this.paging.pageCount;
                this.paging.curMinPage = Math.floor((this.paging.curPage - 1) / this.paging.pageCount) * this.paging.pageCount + 1;

                console.log('curPage ', this.paging.curPage);
                console.log('curMaxPage ', this.paging.curMaxPage);
                console.log('curMinPage ', this.paging.curMinPage);

                this.paging.pageList = [];
                for(var i = this.paging.curMinPage; i <= this.paging.curMaxPage; ++i) {
                    if(maxPage < i) {
                        break;
                    }
                    this.paging.pageList.push({
                        num: i
                    })
                }

                if(maxPage <= this.paging.curMaxPage) {
                    this.paging.hasLast = false;
                } else {
                    this.paging.hasLast = true;
                }

                if(this.paging.curPage < maxPage) {
                    this.paging.hasNext = true;
                } else {
                    this.paging.hasNext = false;
                }

                if(this.paging.curPage != 1) {
                    this.paging.hasPrev = true;
                } else {
                    this.paging.hasPrev = false;
                }

                if(this.paging.curMinPage != 1) {
                    this.paging.hasFirst = true;
                } else {
                    this.paging.hasFirst = false;
                }

                console.log(this.paging);
            },
            retrieveInquiryRegister() {
                const r = { path : `/main/inquiry/register`};
                this.$router.push(r);
			}
        },
        mounted() {
            const vm = this;
            var clientWidth = document.documentElement.clientWidth;
            console.log('clientWidth ', clientWidth);

            var pageCount = 10;
            var rowCount = 10;
            if(clientWidth < 760) {
                rowCount = 5;
                pageCount = 3;
            }

            $(window).scrollTop(0);
            ui.loading.open();

            const params = {
                curPage: 1,
                rowCount: rowCount,
                pageCount: pageCount,
                totalCount: 0,
            };
            this.$axios.post('/api/inquiry/retrieveMemberInquiryList.ajax', qs.stringify(params)).then((result) => {
                ui.loading.close();

                if(result.data.modulationYn == "Y") {
                    const r = { path : "/main" };
                    this.$router.push(r);
                    return;
                }

                // URL Setting
                vm.url.slUrl = result.data.slUrl;
                vm.url.devUrl = result.data.devUrl;
                vm.url.pcNoticeUrl = result.data.pcNoticeUrl;
                vm.url.mobileSmartWorldUrl = result.data.mobileSmartWorldUrl;

                vm.loadingYn = "N";

                vm.$nextTick(function () {
                    vm._setResult(result);
                    vm._resetPageList();
                })
            }).catch((err) => {
                ui.loading.close();
                vm.loadingYn = "N";
                alert('error ' + err);
            })

        }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
