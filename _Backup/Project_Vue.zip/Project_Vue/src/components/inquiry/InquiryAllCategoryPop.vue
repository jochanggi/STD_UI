<template>
	<!-- 팝업_문의구분_전체보기 -->
	<div id="popupQuseAll" class="popup-wrap" hidden>
		<div class="popup popup-type1 popup-quseAll" role="dialog" aria-labelledby="popupQuseAllTitle">
			<div class="blind-area popup-focus dv-ios-only" role="text" :aria-label="$t('gwa.alt.support.inquiry.type')"><!-- IOS접근성 영역자체에 초점처리 --></div>
			<div class="popup-container">
				<div class="popup-header">
					<h3 class="tit-h3" id="popupQuseAllTitle">{{ $t('sdp.support.message.qnaServiceInfo') }}</h3><!--{{ $t('gwa.alt.support.inquiry.type') }}-->
				</div>
				<div class="popup-body popup-scroll">
					<template v-for="(service) in serviceInfoList">
					<section class="pop-sec" v-if="service.upperCatCode == 0">
						<!--<div class="para-wrap">
							<p class="para">{{ $t('sdp.support.message.qnaServiceInfo') }}</p>
						</div>-->
						<div class="tit-wrap" v-if="service.catLevelNo == 1">
							<h4 class="tit-h4">{{ service.catName }}</h4>
						</div>
						<div class="tbl-wrap">
							<div class="tbl tbl-type1">
								<table v-if="service.upperCatCode == 0">
									<caption v-if="service.upperCatCode == 0">
										<span>{{ service.catName }}{{ $t('gwa.alt.inquiry.wa_caption_1') }}</span>
										<p>{{ $t('gwa.alt.inquiry.wa_caption_2') }}</p>
									</caption>
									<thead v-if="service.upperCatCode == 0">
										<tr>
											<th scope="col" :abbr="$t('sdp.support.message.catType2')"><span v-html="$t('sdp.support.message.catType2')"></span></th>
											<th scope="col" :abbr="$t('sdp.support.message.catType3')"><span v-html="$t('sdp.support.message.catType3')"></span></th>
										</tr>
									</thead>
									<template v-for="(service2, index2) in serviceInfoList2">
									<tbody v-if="service2.catLevelNo == 2 && service.catCode == service2.upperCatCode">
										<tr>
											<td :rowspan="service2.lvl2Cnt" class="tit-cell">{{ service2.catName }}</td>
											<td v-if="serviceInfoList2[index2+1].catLevelNo == 3 && level3Chk[index2+1] == true"><span>{{ serviceInfoList2[index2+1].catName }}</span></td>
										</tr>
										<template v-for="(service3, index3) in serviceInfoList3">
											<tr v-if="service3.catLevelNo == 3 && service2.catCode == service3.upperCatCode && level3Chk[index3] == false">
												<td><span>{{ service3.catName }} </span></td>
											</tr>
										</template>
									</tbody>
								</template>
								</table>
							</div>
						</div>
					</section>
					</template>
				</div>
				<div class="popup-footer">
					<div class="btn-wrap">
						<button type="button" class="btn btn-type2 btn-primary popup-close" aria-controls="popupQuseAll" :title="$t('gwa.alt.inquiry.wa_title_1')"><span>{{ $t('sdp.mypage.message.confirm2') }}</span></button>
					</div>
				</div>
				<button type="button" class="btn-ico btn-popup-close popup-close" aria-controls="popupQuseAll" :title="$t('gwa.alt.inquiry.wa_title_1')"><span><i class="ico ico-close2">{{ $t('gwa.alt.common.wa_label_19') }}</i></span></button>
			</div>
		</div>
	</div>
	<!-- //팝업_문의확인 -->
</template>

<script>
    import qs from "qs";
    
    export default {
        name: "InquiryAllCategoryPop",
        data() {
            return {
				serviceInfoList : [],
                serviceInfoList2 : [],
                serviceInfoList3 : [],
                level3Chk : []
            }
        },
        created() {
        },
        watch: {
        },
        computed: {
        },
        methods: {

        },
        mounted() {
            this.$axios.post('/api/inquiry/retrieveInquiryServiceInfoList.ajax').then((result) => {

                this.serviceInfoList = result.data.serviceInfoList;
				this.serviceInfoList2 = result.data.serviceInfoList;
                this.serviceInfoList3 = result.data.serviceInfoList;
                var level3 = "";
                for (var i = 0; i < this.serviceInfoList.length; i++) {
					if (this.serviceInfoList[i].catLevelNo == 3 && this.serviceInfoList[i-1].catLevelNo == 2) {
                        level3 = true;
					} else {
                        level3 = false;
					}
                    this.level3Chk[i] = level3;
				}

            }).catch((err) => {
                alert('error ' + err);
            })
        }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
