<template>
	<!-- 모달팝업_문의확인 -->
	<div id="popupConfirm" class="popup-wrap" hidden>
		<div class="popup popup-type1" role="dialog" aria-labelledby="popupConfirmTitle">
			<div class="blind-area popup-focus dv-ios-only" role="text" :aria-label="$t('gwa.alt.inquiry.wa_label_1')"><!-- IOS접근성 영역자체에 초점처리 --></div>
			<div class="popup-container">
				<div class="popup-header">
					<h3 class="tit-h3">{{ $t('sdp.menu.qna') }}</h3>
				</div>
				<div class="popup-body popup-scroll">
					<div class="para-wrap">
						<p class="para" v-html="$t('sdp.inpuiry.message.pop_text1')"></p>
						<div class="bul bul-star">
							<p>{{ $t('sdp.support.message.qnaInfo3') }}</p>
						</div>
					</div>
				</div>
				<div class="popup-footer">
					<div class="btn-wrap">
						<button type="button" @click="goLgaccount()" class="btn btn-type2 btn-primary" :title="$t('gwa.alt.inquiry.wa_title_2')"><span>{{ $t('sdp.menu.gnb.lgaccount') }}</span></button>
						<button type="button" @click="retrieveInquiryRegister()" class="btn btn-type2 btn-secondary popup-close" aria-controls="popupConfirm" :title="$t('gwa.alt.inquiry.wa_title_3')"><span>{{ $t('sdp.inpuiry.message.pop_btn1') }}</span></button>
					</div>
				</div>
				<button type="button" class="btn-ico btn-popup-close popup-close" aria-controls="popupConfirm" :title="$t('gwa.alt.inquiry.wa_title_4')"><span><i class="ico ico-close2">{{ $t('gwa.alt.common.wa_label_19') }}</i></span></button>
			</div>
		</div>
	</div>
	<!-- //모달팝업_문의확인 -->
</template>

<script>
    import qs from "qs";
    
    export default {
        name: "InquiryConfirmPop",
        data() {
            return {
                cntryCode: _domainCntryCode
            }
        },
        created() {
        },
        watch: {
        },
        computed: {
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
			retrieveInquiryRegister() {
                //dimmer.close('dimmer-popup', 0.6);
                var param = "?";
                if (typeof this.$store.state.inquiryCateCode1 == 'undefined') {
                } else {
                    param += `cateCode1=${this.$store.state.inquiryCateCode1}`;
                }
                if (typeof this.$store.state.inquiryCateCode2 == 'undefined') {
                } else {
                    param += `&cateCode2=${this.$store.state.inquiryCateCode2}`;
                }
                if (typeof this.$store.state.inquiryCateCode3 == 'undefined') {
                } else {
                    param += `&cateCode3=${this.$store.state.inquiryCateCode3}`;
                }
                const r = { path : `/main/inquiry/register`+param};
                this.$router.push(r);
			},
            goLgaccount() {
                console.log('goLgaccount');

                var params = {
                    cntryCode: _domainCntryCode,
                    path: 'inquiry'
                }

                this.$axios.post('/api/main/retrieveLoginInfo.ajax', qs.stringify(params)).then((result) => {
                    var loginUrl = result.data.loginUrl;
                    window.location = loginUrl;
                }).catch((err) => {
                    alert(err);
                });
            }
        },
        mounted() {
        }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
