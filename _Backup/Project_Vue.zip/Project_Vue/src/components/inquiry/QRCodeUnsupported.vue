<template>
	<!-- Content -->
		<section id="content" class="content alim-cont">
			<!-- Content Body -->
			<div class="content-body">
				<!-- 미지원국가안내 -->
				<div class="alim-wrap">
					<div class="alim-section">
						<h3 hidden>{{ $t('gwa.alt.inquiry.wa_caption_10') }}</h3>
						<div class="para-wrap">
							<p>This feature is not supported in your service region.</p>
							<p>We apologize for the inconvenience. </p>
							<p>For questions, please contact us via the LG Electronics Service Center or our main website.</p>
						</div>
						<div class="tit-wrap">
							<h4 class="tit-h4">Inquiring via the website</h4>
						</div>
						<div class="para-wrap">
							<p>Go to <a href="http://www.lg.com/common" target="_blank" title="새창">www.lg.com/common</a> &gt; Select your region &gt; Support &gt; Select Email &gt; Send your inquiry</p>
						</div>
					</div>
				</div>
				<!-- //미지원국가안내 -->
			</div>
			<!-- //Content Body -->
		</section>
	<!-- //Content -->
</template>

<script>
    
    export default {
        name: "QRCodeNotSupport",
        data() {
            return {}
        },
        created() {
        },
        destroyed() {

        },
        watch: {
            $route: "fetchData"
        },
        methods: {

        },
        mounted() {

        }
    }

</script>