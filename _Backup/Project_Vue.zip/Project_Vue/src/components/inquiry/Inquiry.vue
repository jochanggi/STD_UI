<template>
		<!-- content -->
		<section id="content" class="content ques-cont">
			<!-- content Header -->
            <!-- 고도화 ver2 : 클래스 has-search삭제, centered-c추가 -->
			<div class="content-header sub-visual">
                <div class="sub-visual-bg"></div>
				<div class="in-sec">
					<div class="tit-wrap centered-c">
						<h2 class="tit-h2">{{ $t('sdp.menu.qna') }}</h2>
						<p class="explain-h2" v-html="$t('sdp.inpuiry.message.title1')"></p>
					</div>

				</div>
			</div>
			<!-- //content Header -->
			<!-- content Body -->
			<div class="content-body">
				<!-- 1:1문의 전체영역 -->
				<div class="ques-inqury-wrap in-sec">
					<div class="ques-inqury">
						<div class="ques-inqury-header">
							<div class="ques-inqury-inner">
								<div class="tit-wrap">
									<h2 class="tit-h2">{{ $t('sdp.menu.qna') }}</h2>
									<p class="explain"><em v-html="$t('sdp.support.message.new.qna4_explain')"></em></p>
									<!--<p class="explain" v-html="$t('sdp.inpuiry.message.title2')"></p>-->
                                    <i class="ico ico-quesmark" aria-hidden="true"></i>
								</div>
							</div>
						</div>
						<div class="ques-inqury-body">
							<div class="ques-inqury-inner">
								<div class="form-inqury">
									<dl class="bul-dt bul-circle">
										<dt><label for="sService">{{ $t('sdp.support.message.catType1') }}</label></dt>
										<dd>
											<span class="form-select2">
												<select name="sService" id="sService" @change="changeService($event, 2);" v-model="cateCode1">
													<option value="" selected>{{ $t('sdp.support.combo.default') }}</option>
													<option v-for="service in serviceList" :value="service.catCode">{{ service.catName }}</option>
												</select>
											</span>
										</dd>
										<dt><label for="sItem" v-html="$t('sdp.support.message.catType2')"></label></dt>
										<dd>
											<span class="form-select2">
												<select name="sItem" id="sItem" @change="changeService($event, 3);" v-model="cateCode2">
													<option value="" selected>{{ $t('sdp.support.combo.default') }}</option>
													<option v-for="category in categoryList" :value="category.catCode">{{ category.catName }}</option>
												</select>
											</span>
										</dd>
										<dt><label for="sType" v-html="$t('sdp.support.message.catType3')"></label></dt>
										<dd>
											<span class="form-select2">
												<select name="sType" id="sType" @change="pageSetting();;" v-model="searchType">
													<option value="" selected>{{ $t('sdp.support.combo.default') }}</option>
													<option v-for="type in typeList" :value="type.catCode">{{ type.catName }}</option>
												</select>
											</span>
										</dd>
									</dl>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- //1:1문의 전체영역 -->

				<!-- 1:1문의 검색결과 -->
				<!--<div class="quse-result-wrap in-sec" v-show="typeShow == true">
					&lt;!&ndash; 탭영역 &ndash;&gt;
					<div class="tab-type1-wrap">
						&lt;!&ndash; 탭메뉴 (퍼블참고 : 검색결과 펼치면서 첫번째 요소에 포커스처리를 위한 클래스 적용 folder-focus) &ndash;&gt;
                        &lt;!&ndash; 고도화 ver2 : 구조 tit 변경1 &ndash;&gt;
						<nav class="tab-nav tab-change tab-type1 tab-cols-2">
							<ul role="tablist">
								<li role="presentation" class="item1" :class="isDiagActive"><a href="#tabContentSelftest2" class="folder-focus" role="tab" aria-controls="tabContentSelftest2" aria-selected="true" aria-expanded="true"><span class="tit">{{ $t('sdp.menu.gnb.self') }}<em class="label-type2">{{ typeDiagPaging.totalCount }}</em></span></a></li>
								<li role="presentation" class="item2" :class="isFaqActive"><a href="#tabContentFaq2" role="tab" aria-controls="tabContentFaq2" aria-selected="false" aria-expanded="false"><span class="tit">{{ $t('sdp.menu.faq') }}<em class="label-type2">{{ typeFaqPaging.totalCount }}</em></span></a></li>
							</ul>
						</nav>
						&lt;!&ndash; //탭메뉴 &ndash;&gt;

						&lt;!&ndash; 탭내용 &ndash;&gt;
						<div class="tab-body">
							&lt;!&ndash; 탭내용_FAQ &ndash;&gt;
							<div id="tabContentFaq2" class="tab-content" :class="isFaqActive">
								<h3 class="blind dv-pc-only">{{ $t('sdp.menu.faq') }}</h3>
                                &lt;!&ndash; FAQ 전체영역 &ndash;&gt;
                                <div id="faqAjaxWrap2" class="faq-wrap" v-if="typeFaqList.length > 0">
                                    &lt;!&ndash; FAQ 목록그룹 &ndash;&gt;
                                        <div class="accordion-wrap faq-accordion">
                                            &lt;!&ndash; 반복영역 &ndash;&gt;
                                            <div class="accordion" v-for="(faq, index) in typeFaqList">
                                                <div class="accordion-title">
                                                    <a :href="'#faqContent2_'+index" class="accordion-toggle" role="button" :aria-controls="'faqContent2_'+index" aria-expanted="false" @click="readCntt(faq.seqNo)">
                                                        <em class="tit-qusetion" aria-label="Qusetion">Q</em>
                                                        <em class="tit-part">{{ faq.catName }}</em>
                                                        <span class="tit-label">{{ faq.titleName }}</span>
                                                        <i class="arw arw-toggle" aria-hidden="true"></i>
                                                    </a>
                                                </div>
                                                <div :id="'faqContent2_'+index" class="accordion-content" aria-hidden="true">
                                                    <em class="tit-answer" aria-label="Answer">A</em>
                                                    <div class="data-content" role="text" v-html="lineBreakCntt(faq.cntt)"></div>
                                                    <div class="tag-wrap">
                                                        <template v-for="hashTag in typeFaqHashTag">
                                                            <a href="javascript:;" class="tag-type1" role="button" v-if="hashTag.seqNo == faq.seqNo" @click="keywordClick(hashTag.hashTag, 'faq');">
                                                                #{{ hashTag.hashTag }}
                                                            </a>
                                                        </template>
                                                    </div>
                                                    <div class="msg-wrap">
                                                        <p class="txt-area"><i class="arw arw-right" aria-hidden="true"></i>{{ $t('sdp.Satisfaction.message.question') }}</p>
                                                        <div class="btn-area">
                                                            <button type="button" class="btn btn-type4 btn-primary" @click="goSatisf('Y')"><span>{{ $t('sdp.Satisfaction.message.btn1') }}</span></button>
                                                            <button type="button" class="btn btn-type4 popup-open" aria-controls="popupFaqQuestion" aria-haspopup="true"><span>{{ $t('sdp.Satisfaction.message.btn2') }}</span></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            &lt;!&ndash; //반복영역 &ndash;&gt;
                                        </div>
                                        &lt;!&ndash; 고도화 ver2 : 속성 페이지 정보 aria-label 수정 &ndash;&gt;
                                        <div class="pagination-wrap">
                                            <div class="pagination">
                                                <div class="btn-wrap">
                                                    <a @click="goFirstPage('Y')" href="javascript:;" class="btn-ico btn-page first" :class="typeFaqPaging.hasFirst == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-first">{{ $t('gwa.alt.common.wa_title_36') }}</i></span></a>
                                                    <a @click="goPrevPage('Y')" href="javascript:;" class="btn-ico btn-page prev" :class="typeFaqPaging.hasPrev == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-prev">{{ $t('gwa.alt.common.wa_title_37') }}</i></span></a>
                                                </div>
                                                <ul class="num-wrap">
                                                    <li v-for="pageList in typeFaqPaging.pageList">
                                                        <span v-show="pageList.num == typeFaqPaging.curPage" class="btn btn-num" :aria-label="$t('gwa.alt.common.wa_title_38', {var1: pageList.num})" aria-current="true" role="text"><span>{{ pageList.num }}</span></span>
                                                        <a v-show="pageList.num != typeFaqPaging.curPage" @click="goPage(pageList.num, 'Y')" href="javascript:;" class="btn btn-num" :aria-label="$t('gwa.alt.common.wa_title_38', {var1: pageList.num})" role="button"><span>{{ pageList.num }}</span></a>
                                                    </li>
                                                </ul>
                                                <div class="btn-wrap">
                                                    <a v-show="typeFaqPaging.hasNext" @click="goNextPage('Y')" href="javascript:;" class="btn-ico btn-page next" :class="typeFaqPaging.hasNext == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-next">{{ $t('gwa.alt.common.wa_title_39') }}</i></span></a>
                                                    <a v-show="typeFaqPaging.hasLast" @click="goLastPage('Y')" href="javascript:;" class="btn-ico btn-page last" :class="typeFaqPaging.hasLast == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-last">{{ $t('gwa.alt.common.wa_title_40') }}</i></span></a>
                                                </div>
                                            </div>
                                        </div>
                                    &lt;!&ndash; //페이징 &ndash;&gt;
                                </div>
                                &lt;!&ndash; //FAQ 전체영역 &ndash;&gt;
                                &lt;!&ndash; 미등록게시물 &ndash;&gt;
                                <div class="noData-wrap" v-else>
                                    <div class="noData">
                                        <div class="inner">
                                            <p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
                                        </div>
                                    </div>
                                </div>
                                &lt;!&ndash; //미등록게시물 &ndash;&gt;
							</div>
							&lt;!&ndash; //탭내용_FAQ &ndash;&gt;

							&lt;!&ndash; 탭내용_자가진단 &ndash;&gt;
							<div id="tabContentSelftest2" class="tab-content" :class="isDiagActive">
								<h3 class="blind dv-pc-only">{{ $t('sdp.menu.gnb.self') }}</h3>
                                &lt;!&ndash; 자가진단 전체영역 &ndash;&gt;
                                <div id="selftestAjaxWrap2" class="selftest-lists-wrap" v-if="typeDiagList.length > 0">
                                    &lt;!&ndash; 목록그룹 (대체텍스트 형식 : alt="[제목] + Thumbnail") &ndash;&gt;
                                        <div class="selftest-lists" data-type="image" >
                                            <ul>
                                                <li v-for="diag in typeDiagList">
                                                    <a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="updateDiagViewCnt(diag.seqNo, diag.catCode1)" class="item-wrap">
                                                        <div role="text">
                                                            <p class="item-thumb thumbnail" aria-hidden="true"><img :src="diag.resourcePth" :alt="$t('gwa.alt.inquiry.wa_alt_1')"></p>
                                                            <p class="item-tit"><strong>{{ diag.titleName }}</strong></p>
                                                            <p class="item-date">{{ diag.crtDate }}</p>
                                                        </div>
                                                    </a>
                                                    &lt;!&ndash;div class="item-tag" v-if="typeDiagHashTag.length > 0">
                                                        <template v-for="hashTag in typeDiagHashTag">
                                                            <a href="javascript:;" class="tag-type1" role="button" v-if="hashTag.seqNo == diag.seqNo" @click="keywordClick(hashTag.hashTag, 'diag');">{{ hashTag.hashTag }}</a>
                                                        </template>
                                                    </div>&ndash;&gt;
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="pagination-wrap">
                                            <div class="pagination">
                                                <div class="btn-wrap">
                                                    <a v-show="typeDiagPaging.hasFirst" @click="goFirstPage('N')" href="javascript:;" class="btn-ico btn-page first" :class="typeDiagPaging.hasFirst == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-first">{{ $t('gwa.alt.common.wa_title_41') }}</i></span></a>
                                                    <a v-show="typeDiagPaging.hasPrev" @click="goPrevPage('N')" href="javascript:;" class="btn-ico btn-page prev" :class="typeDiagPaging.hasPrev == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-prev">{{ $t('gwa.alt.common.wa_title_42') }}</i></span></a>
                                                </div>
                                                <ul class="num-wrap">
                                                    <li v-for="pageList in typeDiagPaging.pageList">
                                                        <span v-show="pageList.num == typeDiagPaging.curPage" class="btn btn-num" :aria-label="$t('gwa.alt.common.wa_title_43', {var1 : pageList.num})" aria-current="true" role="text"><span>{{ pageList.num }}</span></span>
                                                        <a v-show="pageList.num != typeDiagPaging.curPage" @click="goPage(pageList.num, 'N')" href="javascript:;" class="btn btn-num" :aria-label="$t('gwa.alt.common.wa_title_43', {var1 : pageList.num})" role="button"><span>{{ pageList.num }}</span></a>
                                                    </li>
                                                </ul>
                                                <div class="btn-wrap">
                                                    <a v-show="typeDiagPaging.hasNext" @click="goNextPage('N')" href="javascript:;" class="btn-ico btn-page next" :class="typeDiagPaging.hasNext == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-next">{{ $t('gwa.alt.common.wa_title_44') }}</i></span></a>
                                                    <a v-show="typeDiagPaging.hasLast" @click="goLastPage('N')" href="javascript:;" class="btn-ico btn-page last" :class="typeDiagPaging.hasLast == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-last">{{ $t('gwa.alt.common.wa_title_45') }}</i></span></a>
                                                </div>
                                            </div>
                                        </div>
                                    &lt;!&ndash; //페이징 &ndash;&gt;
                                </div>
                                &lt;!&ndash; //자가진단 전체영역 &ndash;&gt;
                                &lt;!&ndash; 미등록게시물 &ndash;&gt;
                                <div class="noData-wrap" v-else>
                                    <div class="noData">
                                        <div class="inner">
                                            <p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
                                        </div>
                                    </div>
                                </div>
                                &lt;!&ndash; //미등록게시물 &ndash;&gt;
							</div>
							&lt;!&ndash; //탭내용 &ndash;&gt;
						</div>
						&lt;!&ndash; //탭내용 &ndash;&gt;
					</div>
					&lt;!&ndash; //탭영역 &ndash;&gt;
				</div>-->
				<!-- //1:1문의 검색결과 -->

				<!-- 버튼영역 -->
				<div class="ques-btn-wrap in-sec align-c">
					<div class="btn-wrap">
						<button type="button" v-show="memberYn == 'N'" class="btn btn-type1 btn-lg btn-primary popup-open" aria-controls="popupConfirm" aria-haspopup="true"><span>{{ $t('sdp.inpuiry.message.btn_inquiry') }}</span></button>
						<button type="button" v-show="memberYn == 'Y'" @click="retrieveInquiryRegister()" class="btn btn-type1 btn-lg btn-primary"><span>{{ $t('sdp.inpuiry.message.btn_inquiry') }}</span></button>
					</div>
				</div>
				<!-- //버튼영역 -->

			<!-- 모바일 QR코드 -->
			<div class="qrcode-wrap">
				<!-- QR코드스캔 -->
				<div class="qrcode-scan in-sec">
					<div class="inner">
						<h3 class="tit-h3">{{ $t('sdp.qr.message.pop_btn1') }}</h3>
						<p class="para">{{ $t('sdp.qr.message.text5') }}</p>

                        <router-link to="/scanner" tag="button" class="btn btn-type6"><span>{{ $t('sdp.qr.message.pop_btn1') }}</span></router-link>
						<i class="ico ico-qrBg centered-l" aria-hidden="true"></i>
					</div>
				</div>
				<!-- //QR코드스캔 -->
				<!-- QR코드_폴더접기펴기 -->
				<div id="QRGuide" class="qrcode-guide folder-content" aria-hidden="true" data-name="QRGuide"  data-state="closed">
					<!-- QR코드가이드 -->
					<ol class="in-sec">
						<li>
							<div class="item folder-focus" role="text">
								<i class="ico ico-qrImg1 centered-l" aria-label="Guide 1. "></i><span class="txt">{{ $t('sdp.qr.message.text1') }}</span>
							</div>
						</li>
						<li>
							<div class="item" role="text">
								<i class="ico ico-qrImg2 centered-l" aria-label="Guide 2. "></i><span class="txt">{{ $t('sdp.qr.message.text2') }}</span>
							</div>
						</li>
						<li>
							<div class="item" role="text">
								<i class="ico ico-qrImg3 centered-l" aria-label="Guide 3. "></i><span class="txt">{{ $t('sdp.qr.message.text3') }}</span>
							</div>
						</li>
						<li>
							<div class="item" role="text">
								<i class="ico ico-qrImg4 centered-l" aria-label="Guide 4. "></i><span class="txt">{{ $t('sdp.qr.message.text4') }}</span>
							</div>
						</li>
					</ol>
					<!-- //QR코드가이드 -->
				</div>
				<!-- //QR코드_폴더접기펴기 -->
				<!-- QR코드_폴더버튼 -->
				<div class="btn-fold-wrap in-sec centered-b">
					<button type="button" class="btn folder-open" aria-controls="QRGuide" aria-expanded="false" aria-hidden="false" data-role="fold" data-target="QRGuide"><span>{{ $t('sdp.qr.message.btn1') }} <i class="arw arw-toggle4"></i></span></button>
					<button type="button" class="btn folder-close is-active" aria-controls="QRGuide" aria-expanded="true" aria-hidden="true" data-role="fold" data-target="QRGuide"><span>{{ $t('sdp.qr.message.btn2') }} <i class="arw arw-toggle4"></i></span></button>
				</div>
				<!-- //QR코드_폴더버튼 -->
			</div>
			<!-- //모바일 QR코드 -->

				<!-- 제휴문의안내 -->
				<div class="ques-coalition-wrap in-sec">
					<div class="ques-coalition">
						<ul class="grid">
							<li class="col">
								<a href="http://www.lgworld.com/web.gateway.dev" target="_blank" :title="$t('gwa.alt.common.wa_title_4')" class="item" role="button">
									<dl>
										<dt class="tit">LG Smart World <span class="dis-ib">(Mobile)</span></dt>
										<dd class="txt" role="text" v-html="$t('sdp.inpuiry.message.link1') + '<i class=\'ico ico-mobile\' aria-hidden=\'true\'></i>'"></dd>
									</dl>
								</a>
							</li>
							<li class="col">
								<a :href="url.slUrl" target="_blank" :title="$t('gwa.alt.common.wa_title_4')" class="item" role="button">
									<dl>
										<dt class="tit">Seller Lounge</dt>
										<dd class="txt" role="text">{{ $t('sdp.inpuiry.message.link2') }} <i class="ico ico-seller" aria-hidden="true"></i></dd>
									</dl>
								</a>
							</li>
							<li class="col">
								<a :href="url.devUrl" target="_blank" :title="$t('gwa.alt.common.wa_title_4')" class="item" role="button">
									<dl>
										<dt class="tit">LG Developer</dt>
										<dd class="txt" role="text" v-html="$t('sdp.inpuiry.message.link3') + '<i class=\'ico ico-developer\' aria-hidden=\'true\'></i>'"></dd>
									</dl>
								</a>
							</li>
						</ul>
					</div>
				</div>
				<!-- //제휴문의안내 -->

				<!-- 팝업_만족도조사 -->
				<FaqSatisfPop></FaqSatisfPop>
				<!-- //팝업_만족도조사 -->

                <!-- 모달팝업_문의확인 -->
				<InquiryConfirmPop></InquiryConfirmPop>
				<!-- //모달팝업_문의확인 -->

                <!-- QR코드_촬영 -->
                <InquiryQRCodeScanPop ref="qrcodeScanPop"></InquiryQRCodeScanPop>
                <!-- //QR코드_촬영 -->

			</div>
			<!-- //content Body -->
		</section>
	<!-- //content -->
</template>

<script>
    import qs from "qs";
    import InquiryConfirmPop from '@/components/inquiry/InquiryConfirmPop';
    import InquiryQRCodeScanPop from '@/components/inquiry/InquiryQRCodeScanPop';
    import FaqSatisfPop from '@/components/faq/FaqSatisfPop';

    export default {
        name: "Inquiry",
        components: {
            InquiryConfirmPop,
            InquiryQRCodeScanPop,
            FaqSatisfPop
        },
        data() {
            return {
                url : {
                  slUrl : "",
				  devUrl : "",
				  pcNoticeUrl : ""
				},
                searchText : "",
				searchType : "",
				faqSeqNo : 0,
                memberYn : "N",
                titleClickYn: "N",
                keywordList : [],
                buttonShow : false,
                serviceList : [],
                categoryList : [],
                typeList : [],
                typeDiagList : [],
                typeDiagPaging: {
                    pageList: [],
                    totalCount: 0,
                    pageCount: 0,
                    rowCount: 3,
                    curPage: 1,
                    hasNext: false,
                    hasLast: false,
                    hasPrev: false,
                    hasFirst: false,
                    curMaxPage: 0,
                    curMinPage: 1,
                    maxPage: 0
                },
                typeDiagHashTag : [],
                typeFaqList : [],
                typeFaqPaging: {
                    pageList: [],
                    totalCount: 0,
                    pageCount: 0,
                    rowCount: 3,
                    curPage: 1,
                    hasNext: false,
                    hasLast: false,
                    hasPrev: false,
                    hasFirst: false,
                    curMaxPage: 0,
                    curMinPage: 1,
                    maxPage: 0
                },
                typeFaqHashTag : [],
                typeShow : false,
				cateCode1 : "",
				cateCode2 : "",
                diagCatCode1: 0,
				diagActiveYn : true
            }
        },
        created() {
        },
        watch: {
        },
        computed: {
            isDiagActive () {
                if (this.diagActiveYn) {
                    return "is-active";
				} else {
                    return "";
				}
			},
            isFaqActive () {
                if (this.diagActiveYn == false) {
                    return "is-active";
                } else {
                    return "";
                }
			}
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            openQRCodeScanPop() {
                console.log('openQRCodeScanPop..');
                this.$refs.qrcodeScanPop.open();
            },
            closeQRCodeScanPop() {
                console.log('closeQRCodeScanPop..')
                this.$refs.qrcodeScanPop.close();
            },
            keywordClick(keyword, type) {
                const vm = this;
                if(type == "faq") {
                    const r = { path : "/main/faq?&hashTagYn=Y&schTxt="+ keyword };
                    this.$router.push(r);
				} else if(type == "diag") {
                    const r = { path : "/main/diag?catCode1=&searchYn=Y&allClickYn=Y&schTxt=" + keyword + "&detailYn=Y" };
                    this.$router.push(r);
				} else {
                    // error
				}
			},
            goFirstPage(faqYn) {

                if (faqYn == 'Y') {
                    if(this.typeFaqPaging.curMinPage > 1) {
                        this.typeFaqPaging.curPage = this.typeFaqPaging.curMinPage - 1;
                    }
                } else {
                    if(this.typeDiagPaging.curMinPage > 1) {
                        this.typeDiagPaging.curPage = this.typeDiagPaging.curMinPage - 1;
                    }
                }
                this.changeType();
            },
            goPrevPage(faqYn) {
                console.log('goPrevPage');
                if (faqYn == 'Y') {
                    if(this.typeFaqPaging.curPage > 1) {
                        this.typeFaqPaging.curPage -= 1;
                    }
                } else {
                    if(this.typeDiagPaging.curPage > 1) {
                        this.typeDiagPaging.curPage -= 1;
                    }
                }
                this.changeType();

            },
            goNextPage(faqYn) {
                console.log('goNextPage');

                if (faqYn == 'Y') {
                    if(this.typeFaqPaging.curPage < this.typeFaqPaging.maxPage) {
                        this.typeFaqPaging.curPage += 1;
                    }
                } else {
                    if(this.typeDiagPaging.curPage < this.typeDiagPaging.maxPage) {
                        this.typeDiagPaging.curPage += 1;
                    }
                }
                this.changeType();
            },
            goLastPage(faqYn) {
                console.log('goLastPage');

                if (faqYn == 'Y') {
                    if(this.typeFaqPaging.curMaxPage < this.typeFaqPaging.maxPage) {
                        this.typeFaqPaging.curPage = this.typeFaqPaging.curMaxPage + 1;
                    }
                } else {
                    if(this.typeDiagPaging.curMaxPage < this.typeDiagPaging.maxPage) {
                        this.typeDiagPaging.curPage = this.typeDiagPaging.curMaxPage + 1;
                    }
                }
                this.changeType();
            },
            goPage(page, faqYn) {
                if (faqYn == 'Y') {
                    this.typeFaqPaging.curPage = page;
                } else {
                    this.typeDiagPaging.curPage = page;
                }
                this.changeType();
            },
			// 최초일 경우
			pageSetting () {
                this.typeFaqPaging.curPage = 1;
                this.typeFaqPaging.totalCount = 0;

                this.typeDiagPaging.curPage = 1;
                this.typeDiagPaging.totalCount = 0;

                this.changeType();
			},
            changeService(event, lowLevelNo) {
                const vm = this;

                // 초기화
                if (lowLevelNo == 2) {
                    vm.cateCode2 = "";
                    this.$store.state.inquiryCateCode1 = vm.cateCode1;
                } else {
                    this.$store.state.inquiryCateCode2 = vm.cateCode2;
				}

                vm.typeList = [];
                vm.searchType = "";
                vm.cateCode3 = "";

                const params = {
                    highCatCode: event.target.value,
                    catLevelNo: lowLevelNo
                };
                this.$axios.post("/api/inquiry/retrieveInquiryCategoryList.ajax", qs.stringify(params)).then((result) => {
                    if(lowLevelNo == 2) {
                        vm.categoryList = result.data.categoryList;
                    }
                    if(lowLevelNo == 3) {
                        vm.typeList = result.data.categoryList;
                    }
                }).catch((error) => {
                    alert("error");
                });
            },
            changeType() {
                const vm = this;

                this.$store.state.inquiryCateCode3 = vm.searchType;

                /*this.typeFaqPaging.curPage = 1;
                this.typeFaqPaging.totalCount = 0;

                this.typeDiagPaging.curPage = 1;
                this.typeDiagPaging.totalCount = 0;*/

                const params = {
                    type : "service",
                    perQuestCatCode : this.searchType,
                    faqCurPage: this.typeFaqPaging.curPage,
                    faqRowCount: this.typeFaqPaging.rowCount,
                    faqPageCount: this.typeFaqPaging.pageCount,
                    faqTotalCount: this.typeFaqPaging.totalCount,
                    selfCurPage: this.typeDiagPaging.curPage,
                    selfRowCount: this.typeDiagPaging.rowCount,
                    selfPageCount: this.typeDiagPaging.pageCount,
                    selfTotalCount: this.typeDiagPaging.totalCount
                };

                this.$axios.post("/api/inquiry/retrieveInquiryList.ajax", qs.stringify(params)).then((result) => {
                    vm.typeShow = true;

                    vm.typeFaqList = result.data.faqList;
                    vm.typeDiagList = result.data.diagList;

                    vm.typeFaqPaging.totalCount = result.data.faqTotalCount;
                    vm.typeFaqPaging.pageCount = result.data.faqPageCount;
                    vm.typeFaqPaging.curPage = result.data.faqCurPage;
                    vm.typeFaqPaging.rowCount = result.data.faqRowCount;

                    vm.typeDiagPaging.totalCount = result.data.selfTotalCount;
                    vm.typeDiagPaging.pageCount = result.data.selfPageCount;
                    vm.typeDiagPaging.curPage = result.data.selfCurPage;
                    vm.typeDiagPaging.rowCount = result.data.selfRowCount;

                    if (vm.typeFaqList.length > 0) {
                        vm.typeFaqHashTag = result.data.faqHashTag;
                    }

                    if (vm.typeDiagList.length > 0) {
                        vm.typeDiagHashTag = result.data.diagHashTag;
                    }

                    if (vm.typeDiagList.length > 0) {
                        vm.diagActiveYn = true;
					} else {
                        if (vm.typeFaqList.length > 0) {
                            vm.diagActiveYn = false;
						} else {
                            vm.diagActiveYn = true;
						}
					}

                    vm._resetPageList();
                    vm.typeShow = true; // 항목 리스트 노출

                    vm.$nextTick(function() {
                        ui.tab.init();
                        ui.faqAccordion.init();
                    })
                }).catch((error) => {
                    alert("error");
                });
            },
            readCntt(seqNo) {

                this.$store.state.faqSeqNo = seqNo;
                this.$store.state.satisfType = 'faq';

                const vm = this;
                if(seqNo != vm.faqSeqNo) {
                    vm.faqSeqNo = seqNo;
                    vm.updateViewCnt();
                } else {
                    if(vm.titleClickYn == 'Y') {
                        vm.titleClickYn = 'N';
                    } else {
                        vm.updateViewCnt();
                    }
                }
            },
            updateViewCnt() {
                const vm = this;
                const params = {
                    seqNo: vm.faqSeqNo
                };
                this.$axios.post("/api/faq/updateFaqViewCnt.ajax",
                    qs.stringify(params)).then((result) => {
                    vm.titleClickYn = 'Y';
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            goSatisf(clickType) {
                const vm = this;

                const params = {
                    clickType: clickType,
                    faqSeqNo: vm.faqSeqNo
                };

                this.$axios.post("/api/faq/mergeFaqSatisf.ajax",
                    qs.stringify(params)).then((result) => {
                    alert(this.$t("sdp.Satisfaction.message.pop_text6"));
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            updateDiagViewCnt(seqNo, catCode1) {
                const vm = this;
                vm.diagSeqNo = seqNo;
                vm.diagCatCode1 = catCode1;

                const params = {
                    seqNo: vm.diagSeqNo
                };

                this.$axios.post("/api/diag/updateDiagViewCnt.ajax",
                    qs.stringify(params)).then((result) => {
                    const r = { path : "/main/diag/detail?seqNo=" + vm.diagSeqNo + "&catCode1="
                    + vm.diagCatCode1 + "&searchYn=N&allClickYn=N&schTxt=&curPage=1" };
                    this.$router.push(r);
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            lineBreakCntt(cntt) {
                if(cntt != null && cntt != "") {
                    return cntt.split("\n").join("<br />");
                } else {
                    return "";
                }
            },
            _resetPageList() {
                var faqList = [];
                var diagList = [];

                faqList = this.typeFaqPaging;
                diagList = this.typeDiagPaging;

                var fMaxPage = Math.floor(faqList.totalCount / faqList.rowCount);
                var sMaxPage = Math.floor(diagList.totalCount / diagList.rowCount);

                if(faqList.totalCount % faqList.rowCount != 0) {
                    fMaxPage += 1;
                }
                if(diagList.totalCount % diagList.rowCount != 0) {
                    sMaxPage += 1;
                }

                faqList.maxPage = fMaxPage;
                diagList.maxPage = sMaxPage;

                faqList.curMaxPage = Math.floor((faqList.curPage - 1) / faqList.pageCount) * faqList.pageCount + faqList.pageCount;
                diagList.curMaxPage = Math.floor((diagList.curPage - 1) / diagList.pageCount) * diagList.pageCount + diagList.pageCount;

                faqList.curMinPage = Math.floor((faqList.curPage - 1) / faqList.pageCount) * faqList.pageCount + 1;
                diagList.curMinPage = Math.floor((diagList.curPage - 1) / diagList.pageCount) * diagList.pageCount + 1;

                faqList.pageList = [];
                for(var i = faqList.curMinPage; i <= faqList.curMaxPage; ++i) {
                    if(fMaxPage < i) {
                        break;
                    }
                    faqList.pageList.push({
                        num: i
                    })
                }

                if(fMaxPage <= faqList.curMaxPage) {
                    faqList.hasLast = false;
                } else {
                    faqList.hasLast = true;
                }

                if(faqList.curPage < fMaxPage) {
                    faqList.hasNext = true;
                } else {
                    faqList.hasNext = false;
                }

                if(faqList.curPage != 1) {
                    faqList.hasPrev = true;
                } else {
                    faqList.hasPrev = false;
                }

                if(faqList.curMinPage != 1) {
                    faqList.hasFirst = true;
                } else {
                    faqList.hasFirst = false;
                }

                diagList.pageList = [];
                for(var i = diagList.curMinPage; i <= diagList.curMaxPage; ++i) {
                    if(sMaxPage < i) {
                        break;
                    }
                    diagList.pageList.push({
                        num: i
                    })
                }

                if(sMaxPage <= diagList.curMaxPage) {
                    diagList.hasLast = false;
                } else {
                    diagList.hasLast = true;
                }

                if(diagList.curPage < sMaxPage) {
                    diagList.hasNext = true;
                } else {
                    diagList.hasNext = false;
                }

                if(diagList.curPage != 1) {
                    diagList.hasPrev = true;
                } else {
                    diagList.hasPrev = false;
                }

                if(diagList.curMinPage != 1) {
                    diagList.hasFirst = true;
                } else {
                    diagList.hasFirst = false;
                }

            },
            retrieveInquiryRegister() {
                //dimmer.close('dimmer-popup', 0.6);
                var param = "?";
                if (typeof this.$store.state.inquiryCateCode1 == 'undefined') {
                } else {
                    param += `cateCode1=${this.$store.state.inquiryCateCode1}`;
                }
                if (typeof this.$store.state.inquiryCateCode2 == 'undefined') {
                } else {
                    param += `&cateCode2=${this.$store.state.inquiryCateCode2}`;
                }
                if (typeof this.$store.state.inquiryCateCode3 == 'undefined') {
                } else {
                    param += `&cateCode3=${this.$store.state.inquiryCateCode3}`;
                }
                const r = { path : `/main/inquiry/register`+param};
                this.$router.push(r);
            }
        },
        mounted() {

            // Vuex 초기화
            this.$store.state.inquiryCateCode1 = '';
            this.$store.state.inquiryCateCode2 = '';
            this.$store.state.inquiryCateCode3 = '';

            // ui.searchAll.close('searchAll'); // 검색바 닫힘

            // 1:1문의 서비스 항목 및 추천 검색어
            const vm = this;

            var clientWidth = document.documentElement.clientWidth;
            console.log('clientWidth ', clientWidth);

            var pageCount = 10;
            var faqRowCount = 5;
            var diagRowCount = 8;

            vm.typeFaqPaging.curPage = 1;
            vm.typeDiagPaging.curPage = 1;

            vm.typeFaqPaging.rowCount = faqRowCount;
            vm.typeDiagPaging.rowCount = diagRowCount;

            vm.typeFaqPaging.pageCount = pageCount;
            vm.typeDiagPaging.pageCount = pageCount;

            this.$axios.post("/api/inquiry/retrieveInquirySearch.ajax").then((result) => {
                vm.keywordList = result.data.keywordList;
                vm.serviceList = result.data.serviceList;
                vm.memberYn = result.data.memberYn;

                // URL Setting
				vm.url.slUrl = result.data.slUrl;
				vm.url.devUrl = result.data.devUrl;
				vm.url.pcNoticeUrl = result.data.pcNoticeUrl;

                vm.$nextTick(function() {
                    ui.init();
                    ui.faqAccordion.init();
                });
            }).catch((error) => {
                alert("error");
            });
        }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
