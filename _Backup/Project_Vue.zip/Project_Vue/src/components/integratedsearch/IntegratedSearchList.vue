<template>
    <!-- Content -->
		<section id="content" class="content search-cont">
			<!-- 전체검색 -->
			<div class="search-all-wrap is-static">
				<div class="search-page" role="search">
					<!-- 검색폼 -->
					<fieldset>
						<legend id="searchAllLegend">{{ $t('sdp.search.message.integrated') }}</legend>
						<div class="search-form ac-form-wrap">
							<!--<input v-model="searchText" @keyup="keyPress" type="text" name="sSearchAll" class="search-check search-focus" autocomplete="off" :placeholder="$t('sdp.search.message.text_box')" :title="$t('sdp.search.message.integrated')" />-->
							<input v-model="searchText" type="text" name="sSearchAll" id="sSearchAll2" class="search-check search-focus ac-keyword" @keyup="keyPress" autocomplete="off" :placeholder="$t('sdp.search.message.text_box')" :title="$t('sdp.search.message.integrated')" />
							<transition name="fade" v-on:after-leave="afterLeave">
								<button type="button" @click="deleteSearchText()" class="btn-ico search-delete centered-r" v-show="searchText != null && searchText != ''"><span><i class="ico ico-del2">{{ $t('gwa.alt.common.wa_label_59') }}</i></span></button>
							</transition>
							<button type="submit" class="btn btn-search centered-r" @click="checkSearchTime('')"><span><i class="ico ico-search2 centered-c">{{ $t('gwa.alt.common.wa_label_48') }}</i></span></button>
							<!-- Auto Complete -->
							<div class="ac-form ac-search-static"></div>
							<!--<div class="ac-form" v-if="completeCheck == true">
								<div class="ac-scroll">
									<ul>
										<li tabindex="0" class="ui-menu-item" v-for="value in completeKeywordList" @click="completeClick(value)" @keyup.enter="completeClick(value)">
											<div class="ui-menu-item-wrapper">
												{{ value }}
											</div>
										</li>
									</ul>
								</div>
							</div>-->
							<!-- //Auto Complete -->
						</div>
					</fieldset>
					<!-- //검색폼 -->
					<!-- 추천검색어 -->
					<!-- 고도화 ver2 : 속성 aria-label 검색 추가 -->
					<div class="keyword-wrap" data-state="closed">
						<h3 class="keyword-tit">{{ $t('sdp.search.message.recommend') }}</h3>
						<div class="keyword">
							<div id="foldKeywordAll" class="folder-keyword folder-content type-all" data-name="foldKeywordAll">
								<div class="folder-inner">
									<p v-for="keyword in keywordList"><a href="javascript:;" @click="checkSearchTime(keyword.keywrd);" :aria-label="keyword.keywrd+' '+$t('gwa.alt.main.sch')">{{ keyword.keywrd }}</a></p>
								</div>
							</div>
							<div class="keyword-btn">
								<button type="button" class="btn-ico folder-open is-active" tabindex="0" aria-controls="foldKeywordAll" aria-expanded="false" aria-hidden="false" data-role="more" data-target="foldKeywordAll"><span><i class="arw arw-toggle6">{{ $t('gwa.alt.common.wa_label_32') }}</i></span></button>
								<button type="button" class="btn-ico folder-close" tabindex="-1" aria-controls="foldKeywordAll" aria-expanded="true" aria-hidden="true" data-role="more" data-target="foldKeywordAll"><span><i class="arw arw-toggle6">{{ $t('gwa.alt.common.wa_label_33') }}</i></span></button>
							</div>
						</div>
					</div>
					<!-- //추천검색어 -->
					<!-- <button type="button" class="return-close">{{ $t('sdp.search.message.integrated') }}</button> 마지막에 닫으라고 고려해놨더니 왜 초점이 여기로 오냐고 잘못된 지적을 받음 -->
				</div>
			</div>
			<!-- //전체검색 -->

			<!-- Content Header -->
			<div hidden>
				<div class="content-header sub-visual">
					<div class="sub-visual-bg"></div>
					<div class="in-sec">
						<div class="tit-wrap centered-c">
							<h2 class="tit-h2">{{ $t('sdp.search.message.integrated') }}</h2>
							<p class="explain-h2" v-html="$t('sdp.support.message.faqInfo')"></p>
						</div>
					</div>
				</div>
			</div>
			<!-- //Content Header -->

			<!-- Content Body -->
			<div class="content-body">
				<!-- 탭영역 -->
				<div class="tab-type1-wrap in-sec">
					<!-- 탭메뉴 개발참고사항
						선택된 메뉴 : li태그 - class="is-active", a태그 - aria-selected="true" aria-expanded="true"
					-->
					<!-- 고도화 ver2 : 구조 tit 변경1 -->
					<nav class="tab-nav tab-type1 tab-responsive">
						<ul role="tablist">
							<li role="presentation" :class="{ 'is-active' : isTabActive ('total') }"><a href="javascript:;" @click="totalEvent();" role="tab" aria-selected="true" aria-expanded="true"><span class="tit">{{ $t('sdp.search.message.integrated') }}<em class="label-type2">{{ totalCount }}</em></span></a></li>
							<li role="presentation" :class="{ 'is-active' : isTabActive ('tvApp') }"><a href="javascript:;" @click="retireveTvAppList();" role="tab" aria-selected="false" aria-expanded="false"><span class="tit">{{ $t('sdp.menu.gnb.tvapp') }}<em class="label-type2">{{ appCount }}</em></span></a></li>
							<li role="presentation" :class="{ 'is-active' : isTabActive ('notice') }"><a href="javascript:;" @click="retireveNoticeList();" role="tab" aria-selected="false" aria-expanded="false"><span class="tit">{{ $t('sdp.menu.notice') }}<em class="label-type2">{{ noticeCount }}</em></span></a></li>
							<li role="presentation" :class="{ 'is-active' : isTabActive ('faq') }"><a href="javascript:;" @click="retireveFaqList();" role="tab" aria-selected="false" aria-expanded="false"><span class="tit">{{ $t('sdp.menu.faq') }}<em class="label-type2">{{ faqCount }}</em></span></a></li>
							<li role="presentation" :class="{ 'is-active' : isTabActive ('diag') }"><a href="javascript:;" @click="retireveDiagList();" role="tab" aria-selected="false" aria-expanded="false"><span class="tit">{{ $t('sdp.menu.gnb.self') }}<em class="label-type2">{{ diagCount }}</em></span></a></li>
						</ul>
					</nav>
					<!-- //탭메뉴 -->

					<!-- 탭내용 -->
					<div class="tab-body">
						<!-- TV앱 섹션 -->
						<!-- 고도화 ver1 : 클래스 section-category로 변경 -->
						<section class="section section-category" v-if="totalYn == 'Y' || tvAppYn == 'Y'">
							<div class="section-header" v-if="loadingYn == 'N'">
								<div class="inner">
									<h3 class="tit-h3">{{ $t('sdp.menu.gnb.tvapp') }} <em class="label-type4"><span class="txt-count">{{ appCount }}</span></em></h3>
								</div>
							</div>
							<div class="section-body" v-if="loadingYn == 'Y'">
								<div class="loading-wrap">
									<div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
								</div>
							</div>
							<div class="section-body" v-else>
								<div id="tvAppWrap1" class="app-lists-wrap">
									<div class="app-lists" data-type="image">
										<ul>
											<template v-for="app in appTotal">
												<li v-if="totalYn == 'Y' && tvAppYn == 'N'">
													<div class="item-wrap">
														<p v-if="app.age >= 18 && userAge < 18" class="item-thumb thumbnail"><a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" class="more-focus popup-open" aria-controls="popupInfoGuide" aria-haspopup="true" @click="setAdultAppName(app.appName, app.appId)"><img :src="app.appPath" :alt="$t('gwa.alt.integrated.wa_label_2', {var1: app.appName})" onerror="imageResize.reset(this)" /></a></p>
														<p v-else class="item-thumb thumbnail"><a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" class="more-focus" @click="goTvappDetail(app.appId)"><img :src="app.appPath" :alt="$t('gwa.alt.integrated.wa_label_2', {var1: app.appName})" onerror="imageResize.reset(this)" /></a></p>
														<p class="item-tit"><strong>{{ app.appName }}</strong></p>
														<p class="item-part" :aria-label="$t('gwa.alt.integrated.wa_label_4', {var1: app.catName})">{{ app.catName }}</p>
														<p class="item-txt"><a class="tracking app_list seller" href="javascript:;" :title="$t('gwa.alt.tvapp.wa_title_1')" :aria-label="$t('gwa.alt.integrated.wa_label_5', {var1: app.sellerUserName})" @click="goTvappSeller(app.sellerUserName)">{{ app.sellerUserName }}</a></p>
														<div class="item-star">
															<div class="js starRating-label" role="text" aria-valuemax="5" aria-valuemin="0" :aria-valuenow="appStar(app.avgSscr)" :aria-label="$t('gwa.alt.integrated.wa_label_3', {var1: appStar(app.avgSscr)})">
																<span class="blind dv-pc-only">{{ $t('gwa.alt.integrated.wa_label_3', {var1 : appStar(app.avgSscr)}) }}</span>
																<span class="rating"><span class="rating-max"></span><span class="rating-now"></span></span>
															</div>
														</div>
													</div>
												</li>
											</template>
											<template v-for="app in appList">
												<li v-if="totalYn == 'N' && tvAppYn == 'Y'">
													<div class="item-wrap">
														<p v-if="app.age >= 18 && userAge < 18" class="item-thumb thumbnail"><a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" class="more-focus popup-open" @click="setAdultAppName(app.appName, app.appId)" aria-controls="popupInfoGuide" aria-haspopup="true"><img :src="app.appPath" :alt="$t('gwa.alt.integrated.wa_label_2', {var1:app.appName})" onerror="imageResize.reset(this)" /></a></p>
														<p v-else class="item-thumb thumbnail"><a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" class="more-focus" @click="goTvappDetail(app.appId)"><img :src="app.appPath" :alt="$t('gwa.alt.integrated.wa_label_2', {var1:app.appName})" onerror="imageResize.reset(this)" /></a></p>
														<p class="item-tit"><strong>{{ app.appName }}</strong></p>
														<p class="item-part" :aria-label="$t('gwa.alt.integrated.wa_label_4', {var1: app.catName})">{{ app.catName }}</p>
														<p class="item-txt"><a class="tracking app_list seller" href="javascript:;" :title="$t('gwa.alt.tvapp.wa_title_1')" :aria-label="$t('gwa.alt.integrated.wa_label_5', {var1: app.sellerUserName})" @click="goTvappSeller(app.sellerUserName)">{{ app.sellerUserName }}</a></p>
														<div class="item-star">
															<div class="js starRating-label" role="text" aria-valuemax="5" aria-valuemin="0" :aria-valuenow="appStar(app.avgSscr)" :aria-label="$t('gwa.alt.integrated.wa_label_3', {var1: appStar(app.avgSscr)})">
																<span class="blind dv-pc-only">{{ $t('gwa.alt.integrated.wa_label_3', {var1 : appStar(app.avgSscr)}) }}</span>
																<span class="rating"><span class="rating-max"></span><span class="rating-now"></span></span>
															</div>
														</div>
													</div>
												</li>
											</template>
										</ul>
									</div>
									<!-- 미등록게시물 -->
									<div class="noData-wrap" v-if="(appTotal == null || appList == null) && loadingYn == 'N'">
										<div class="noData">
											<div class="inner">
												<p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
											</div>
										</div>
									</div>
									<!-- //미등록게시물 -->
								</div>
							</div>
							<a href="javascript:;" v-if="totalYn == 'Y' && tvAppYn == 'N' && loadingYn == 'N'" @click="more('tvApp')" class="btn btn-more" role="button" :title="$t('gwa.alt.integrated.wa_label_1')">{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-cate" @click="more('tvApp')"></i></a>
							<a href="javascript:;" v-if="totalYn == 'N' && tvAppYn == 'Y' && loadingYn == 'N'" @click="move('tvApp')" class="btn btn-more" role="button" :title="$t('gwa.alt.integrated.wa_label_1')">{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-cate" @click="move('tvApp')"></i></a>
						</section>
						<!-- //TV앱 섹션 -->

						<!-- 공지사항 섹션 -->
						<!-- 고도화 ver1 : 클래스 section-category2로 변경1 -->
						<!-- 고도화 ver2 : 속성 더보기 aria-label 수정 -->
						<section class="section section-category2" v-if="totalYn == 'Y' || noticeYn == 'Y'">
							<div class="section-header" v-if="loadingYn == 'N'">
								<div class="inner">
									<h3 class="tit-h3">{{ $t('sdp.menu.notice') }} <em class="label-type4"><span class="txt-count">{{ noticeCount }}</span></em></h3>
								</div>
							</div>
							<div class="section-body">
								<!-- 목록그룹 (공지 :, 약관 : type-term)-->
								<div class="section-body" v-if="loadingYn == 'Y'">
									<div class="loading-wrap">

										<div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
									</div>
								</div>
								<div class="board-list-wrap" v-else>
									<div class="board-list">
										<table>
											<caption>
												<div class="blind-area" role="text">
													<strong>{{ $t('gwa.alt.common.wa_caption_1') }}</strong>
													<p>{{ $t('gwa.alt.common.wa_summary_1') }}</p>
												</div>
											</caption>
											<thead>
												<tr>
													<th id="boardListNo">{{ $t('sdp.support.message.num') }}</th>
													<th id="boardListSubject">{{ $t('sdp.support.message.subject') }}</th>
													<th id="boardListDate">{{ $t('sdp.support.message.regdate') }}</th>
												</tr>
											</thead>
											<tbody>
												<!-- 등록게시물 -->
												<template v-for="(notice, index) in noticeTotal">
													<tr v-if="totalYn == 'Y' && noticeYn == 'N'">
														<td headers="boardListNo">{{ index+1 }}</td>
														<td headers="boardListSubject" class="align-l">
															<a href="javascript:;" @click="retrieveNoticeInfo(notice.seqNo)" class="link-wrap">
																<span class="link-text">{{ notice.titleName }}</span>
																<i class="arw arw-next2 centered-r" aria-hidden="true"></i>
															</a>
														</td>
														<td headers="boardListDate">{{ notice.crtDate }}</td>
													</tr>
												</template>
												<template v-for="(notice, index) in noticeList">
													<tr v-if="totalYn == 'N' && noticeYn == 'Y'">
														<td headers="boardListNo">{{ index+1 }}</td>
														<td headers="boardListSubject" class="align-l">
															<a href="javascript:;" @click="retrieveNoticeInfo(notice.seqNo)" class="link-wrap">
																<span class="link-text">{{ notice.titleName }}</span>
																<i class="arw arw-next2 centered-r" aria-hidden="true"></i>
															</a>
														</td>
														<td headers="boardListDate">{{ notice.crtDate }}</td>
													</tr>
												</template>
												<!-- //등록게시물 -->
												<!-- 미등록게시물 -->
												<tr v-show="noticeTotal.length == 0 && totalYn == 'Y' && noticeYn == 'N' && loadingYn == 'N'" class="tbl-noData-wrap">
													<td colspan="3" class="tbl-noData">{{ $t('sdp.support.message.nolist') }}</td>
												</tr>
												<!-- //미등록게시물 -->
												<!-- 미등록게시물 -->
												<tr v-show="noticeList.length == 0 && totalYn == 'N' && noticeYn == 'Y' && loadingYn == 'N'" class="tbl-noData-wrap">
													<td colspan="3" class="tbl-noData">{{ $t('sdp.support.message.nolist') }}</td>
												</tr>
												<!-- //미등록게시물 -->
											</tbody>
										</table>
									</div>
								</div>
								<!-- //목록그룹 -->
							</div>
							<a href="javascript:;" v-if="totalYn == 'Y' && noticeYn == 'N'" @click="more('notice')" class="btn btn-more" role="button" :title="$t('gwa.alt.integrated.wa_label_6')">{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-cate" @click="more('notice')"></i></a>
							<a href="javascript:;" v-if="totalYn == 'N' && noticeYn == 'Y'" @click="move('notice')" class="btn btn-more" role="button" :title="$t('gwa.alt.integrated.wa_label_6')">{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-cate" @click="move('notice')"></i></a>
						</section>
						<!-- //공지사항 섹션 -->

						<!-- FAQ 섹션 -->
						<!-- 고도화 ver1 : 클래스 section-category2로 변경2 -->
						<section class="section section-category2" v-if="totalYn == 'Y' || faqYn == 'Y'">
							<div class="section-header" v-if="loadingYn == 'N'">
								<div class="inner">
									<h3 class="tit-h3">{{ $t('sdp.menu.faq') }} <em class="label-type4"><span class="txt-count">{{ faqCount }}</span></em></h3>
								</div>
							</div>
							<div class="section-body" v-if="loadingYn == 'Y'">
								<div class="loading-wrap">
									<div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
								</div>
							</div>
							<div class="section-body" v-else>
								<!-- FAQ 전체영역 -->
								<div id="faqWrap" class="faq-wrap">
									<!-- FAQ 목록그룹 -->
									<div class="accordion-wrap faq-accordion">
										<!-- 반복영역 -->
										<template v-for="(faq, index) in faqTotal" >
											<div class="accordion" v-if="totalYn == 'Y' && faqYn == 'N'">
												<div class="accordion-title">
												<a :href="'#faqContent'+(index+1)" class="accordion-toggle" role="button"
														:aria-controls="'faqContent'+(index+1)" aria-expanted="false" @click="readCntt(faq.seqNo)">
													<em class="tit-qusetion" aria-label="Qusetion">Q</em>
													<em class="tit-part">{{ faq.catName }}</em>
													<span class="tit-label" v-html="faq.titleName"></span>
													<i class="arw arw-toggle" aria-hidden="true"></i>
												</a>
												</div>
												<div :id="'faqContent'+(index+1)" class="accordion-content" aria-hidden="true">
													<em class="tit-answer" aria-label="Answer">A</em>
													<div class="data-content" role="text" v-html="lineBreakCntt(faq.cntt)"></div>
													<div class="tag-wrap">
														<a v-show="faq.seqNo == hashTag.seqNo" v-for="hashTag in faqHashTag"
																@click="keywordClick(hashTag.hashTag);" href="javascript:;" class="tag-type1">
															#{{ hashTag.hashTag }}
														</a>
													</div>
													<div class="msg-wrap">
														<p class="txt-area"><i class="arw arw-right" aria-hidden="true"></i>{{ $t('sdp.Satisfaction.message.question') }}</p>
														<div class="btn-area">
															<button type="button" class="btn btn-type4 btn-primary" @click="goSatisf('Y')"><span>{{ $t('sdp.Satisfaction.message.btn1') }}</span></button>
															<button type="button" class="btn btn-type4 popup-open" aria-controls="popupFaqQuestion" aria-haspopup="true"><span>{{ $t('sdp.Satisfaction.message.btn2') }}</span></button>
														</div>
													</div>
												</div>
											</div>
										</template>
										<template v-for="(faq, index) in faqList">
											<div class="accordion" v-if="totalYn == 'N' && faqYn == 'Y'">
												<div class="accordion-title">
												<a :href="'#faqContent'+(index+1)" class="accordion-toggle" role="button"
														:aria-controls="'faqContent'+(index+1)" aria-expanted="false" @click="readCntt(faq.seqNo)">
													<em class="tit-qusetion" aria-label="Qusetion">Q</em>
													<em class="tit-part">{{ faq.catName }}</em>
													<span class="tit-label" v-html="faq.titleName"></span>
													<i class="arw arw-toggle" aria-hidden="true"></i>
												</a>
												</div>
												<div :id="'faqContent'+(index+1)" class="accordion-content" aria-hidden="true">
													<em class="tit-answer" aria-label="Answer">A</em>
													<div class="data-content" role="text" v-html="lineBreakCntt(faq.cntt)"></div>
													<div class="tag-wrap">
														<a v-show="faq.seqNo == hashTag.seqNo" v-for="hashTag in faqHashTag"
																@click="keywordClick(hashTag.hashTag);" href="javascript:;" class="tag-type1">
															#{{ hashTag.hashTag }}
														</a>
													</div>
													<div class="msg-wrap">
														<p class="txt-area"><i class="arw arw-right" aria-hidden="true"></i>{{ $t('sdp.Satisfaction.message.question') }}</p>
														<div class="btn-area">
															<button type="button" class="btn btn-type4 btn-primary" @click="goSatisf('Y')"><span>{{ $t('sdp.Satisfaction.message.btn1') }}</span></button>
															<button type="button" class="btn btn-type4 popup-open" aria-controls="popupFaqQuestion" aria-haspopup="true"><span>{{ $t('sdp.Satisfaction.message.btn2') }}</span></button>
														</div>
													</div>
												</div>
											</div>
											<!-- //반복영역 -->
										</template>
									</div>
								</div>
								<!-- //FAQ 전체영역 -->
							</div>
							<a href="javascript:;" v-if="totalYn == 'Y' && faqYn == 'N'" @click="more('faq')" class="btn btn-more" role="button" :title="$t('gwa.alt.integrated.wa_label_7')">{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-cate" @click="more('faq')"></i></a>
							<a href="javascript:;" v-if="totalYn == 'N' && faqYn == 'Y'" @click="move('faq')" class="btn btn-more" role="button" :title="$t('gwa.alt.integrated.wa_label_7')">{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-cate" @click="move('faq')"></i></a>
							<!-- 미등록게시물 -->
							<div class="noData-wrap" v-if="faqTotal.length == 0 && totalYn == 'Y' && faqYn == 'N' && loadingYn == 'N'">
								<div class="noData">
									<div class="inner">
										<p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
									</div>
								</div>
							</div>
							<!-- //미등록게시물 -->
							<!-- 미등록게시물 -->
							<div class="noData-wrap" v-if="faqList.length == 0 && totalYn == 'N' && faqYn == 'Y' && loadingYn == 'N'">
								<div class="noData">
									<div class="inner">
										<p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
									</div>
								</div>
							</div>
							<!-- //미등록게시물 -->
						</section>
						<!-- //FAQ 섹션 -->

						<!-- 자가진단 섹션 -->
						<!-- 고도화 ver1 : 클래스 section-category2로 변경3 -->
						<section class="section section-category2" v-if="totalYn == 'Y' || diagYn == 'Y'">
							<div class="section-header" v-if="loadingYn == 'N'">
								<div class="inner">
									<h3 class="tit-h3">{{ $t('sdp.menu.gnb.self') }} <em class="label-type4"><span class="txt-count">{{ diagCount }}</span></em></h3>
								</div>
							</div>
							<div class="section-body" v-if="loadingYn == 'Y'">
								<div class="loading-wrap">
									<div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
								</div>
							</div>
							<div class="section-body" v-else>
								<div id="selftestWrap" class="selftest-lists-wrap">
									<!-- 목록그룹 (대체텍스트 형식 : alt="[제목] + Thumbnail") -->
									<div class="selftest-lists" data-type="image" v-if="totalYn == 'Y' && diagYn == 'N'">
										<ul>
											<li v-for="diag in diagTotal">
												<a href="javascript:;" class="item-wrap" :title="$t('gwa.alt.common.wa_title_33')" @click="updateDiagViewCnt(diag.seqNo, diag.catCode1)">
													<div role="text">
														<p class="item-thumb thumbnail" aria-hidden="true"><img :src="diag.resourcePth" :alt="$t('gwa.alt.integrated.wa_alt_1', {var1: diag.titleName})"></p>
														<p class="item-tit"><strong>{{ diag.titleName }}</strong></p>
														<p class="item-date">{{ diag.crtDate }}</p>
													</div>
												</a>
												<!--<div class="item-tag">
													<a v-for="hashTag in diagHashTag" v-show="hashTag.seqNo == diag.seqNo"
															href="javascript:;" class="tag-type1" role="button" @click="keywordClick(hashTag.hashTag);">
														{{ hashTag.hashTag }}
													</a>
												</div>-->
											</li>
										</ul>
									</div>
									<div class="selftest-lists" data-type="image" v-if="totalYn == 'N' && diagYn == 'Y'">
										<ul>
											<li v-for="diag in diagList">
												<a href="javascript:;" class="item-wrap" :title="$t('gwa.alt.common.wa_title_33')" @click="updateDiagViewCnt(diag.seqNo, diag.catCode1)">
													<div role="text">
														<p class="item-thumb thumbnail" aria-hidden="true"><img :src="diag.resourcePth" :alt="$t('gwa.alt.integrated.wa_alt_1', {var1: diag.titleName})"></p>
														<p class="item-tit"><strong>{{ diag.titleName }}</strong></p>
														<p class="item-date">{{ diag.crtDate }}</p>
													</div>
												</a>
												<!--<div class="item-tag">
													<a v-for="hashTag in diagHashTag" v-show="hashTag.seqNo == diag.seqNo"
															href="javascript:;" class="tag-type1" role="button" @click="keywordClick(hashTag.hashTag);">
														{{ hashTag.hashTag }}
													</a>
												</div>-->
											</li>
										</ul>
									</div>
									<!-- //목록그룹 -->
								</div>
							</div>
							<a href="javascript:;" v-if="totalYn == 'Y' && diagYn == 'N'" @click="more('diag')" class="btn btn-more" role="button" :title="$t('gwa.alt.integrated.wa_label_8')">{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-cate" @click="more('diag')"></i></a>
							<a href="javascript:;" v-if="totalYn == 'N' && diagYn == 'Y'" @click="move('diag')"  class="btn btn-more" role="button" :title="$t('gwa.alt.integrated.wa_label_8')">{{ $t('sdp.store.message.showdescription') }}<i class="ico ico-more-cate" @click="move('diag')"></i></a>
							<!-- 미등록게시물 -->
							<div class="noData-wrap" v-if="diagTotal.length == 0 && totalYn == 'Y' && diagYn == 'N' && loadingYn == 'N'">
								<div class="noData">
									<div class="inner">
										<p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
									</div>
								</div>
							</div>
							<!-- //미등록게시물 -->
							<!-- 미등록게시물 -->
							<div class="noData-wrap" v-if="diagList.length == 0 && totalYn == 'N' && diagYn == 'Y' && loadingYn == 'N'">
								<div class="noData">
									<div class="inner">
										<p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
									</div>
								</div>
							</div>
							<!-- //미등록게시물 -->
						</section>
						<!-- //자가진단 섹션 -->
					</div>
					<!-- //탭내용 -->
				</div>
				<!-- //탭영역 -->

				<!-- 팝업_만족도조사 -->
				<FaqSatisfPop></FaqSatisfPop>
				<!-- //팝업_만족도조사 -->

				<!-- 팝업_APP이용안내 -->
				<div id="popupInfoGuide" class="popup-wrap" hidden>
					<div class="popup popup-type1" role="dialog" aria-labelledby="popupInfoGuideTitle">
						<div class="blind-area popup-focus dv-ios-only" role="text" :aria-label="$t('gwa.alt.common.wa_label_55')"><!-- IOS접근성 영역자체에 초점처리 --></div>
						<div class="popup-container">
							<div class="popup-header">
								<h3 class="tit-h3" id="popupInfoGuideTitle">APP {{ $t("sdp.menu.overview") }}</h3>
							</div>
							<div class="popup-body popup-scroll">
								<div class="para-wrap align-c">
									<p class="para color-primary" v-html="$t('sdp.store.message.minorsapp')"></p>
									<p class="para" v-html="$t('sdp.store.minorsapp.detailinfo', { var1 : adultAppName })"></p>
								</div>
							</div>
							<div class="popup-footer">
								<div class="btn-wrap">
									<button @click="goLgaccount('N')" type="button" class="btn btn-type2 btn-primary"><span>{{ $t("sdp.menu.join_member") }}</span></button>
									<button @click="goLgaccount('Y')" type="button" class="btn btn-type2 btn-primary"><span>{{ $t("sdp.menu.gnb.lgaccount") }}</span></button>
									<button type="button" class="btn btn-type2 btn-secondary popup-close" aria-controls="popupInfoGuide"  :title="$t('gwa.alt.common.wa_title_58')"><span>{{ $t("sdp.message.layerpopup.close") }}</span></button>
								</div>
							</div>
							<button type="button" class="btn-ico btn-popup-close popup-close" aria-controls="popupInfoGuide" :title="$t('gwa.alt.common.wa_title_58')"><span><i class="ico ico-close2">{{ $t('sdp.message.layerpopup.close') }}</i></span></button>
						</div>
					</div>
				</div>
				<!-- //팝업_APP 이용안내 -->

				<div id="popupTabSelect" class="popup-wrap popup-select" role="dialog">
                    <div class="popup popup-tab">
       					<nav class="tab-nav tab-type1 tab-responsive">
							<ul role="tablist">
								<li role="presentation" :class="{ 'is-active' : isTabActive ('total') }"><a href="javascript:;" @click="totalEvent();" role="tab" aria-selected="true" aria-expanded="true"><span class="tit">{{ $t('sdp.search.message.integrated') }}<em class="label-type2">{{ totalCount }}</em></span></a></li>
								<li role="presentation" :class="{ 'is-active' : isTabActive ('tvApp') }"><a href="javascript:;" @click="retireveTvAppList();" role="tab" aria-selected="false" aria-expanded="false"><span class="tit">{{ $t('sdp.menu.gnb.tvapp') }}<em class="label-type2">{{ appCount }}</em></span></a></li>
								<li role="presentation" :class="{ 'is-active' : isTabActive ('notice') }"><a href="javascript:;" @click="retireveNoticeList();" role="tab" aria-selected="false" aria-expanded="false"><span class="tit">{{ $t('sdp.menu.notice') }}<em class="label-type2">{{ noticeCount }}</em></span></a></li>
								<li role="presentation" :class="{ 'is-active' : isTabActive ('faq') }"><a href="javascript:;" @click="retireveFaqList();" role="tab" aria-selected="false" aria-expanded="false"><span class="tit">{{ $t('sdp.menu.faq') }}<em class="label-type2">{{ faqCount }}</em></span></a></li>
								<li role="presentation" :class="{ 'is-active' : isTabActive ('diag') }"><a href="javascript:;" @click="retireveDiagList();" role="tab" aria-selected="false" aria-expanded="false"><span class="tit">{{ $t('sdp.menu.gnb.self') }}<em class="label-type2">{{ diagCount }}</em></span></a></li>
							</ul>
						</nav>
                        <button type="button" class="btn-ico btn-close-select" aria-controls="popupTabSelect"><span><i class="ico ico-close2">{{ $t('gwa.alt.common.wa_label_11') }}</i></span></button>
                    </div>
                </div>

			</div>
			<!-- //Content Body -->
		</section>
	<!-- //Content -->
</template>

<style>
</style>

<script>

    import qs from "qs";
    import FaqSatisfPop from '@/components/faq/FaqSatisfPop';


    export default {
        name: "IntegratedSearchList",
        components: {
            FaqSatisfPop
        },
        data() {
            return {
                totalYn : 'Y',
				tvAppYn : 'N',
				noticeYn : 'N',
				faqYn: 'N',
				diagYn : 'N',
				category : 'total',
                keywordList : [],
                searchText : "",
				maxLength: 256,
                appList : [],
                appTotal : [],
                appCount : 0,
                userAge : 0,
                adultAppName: "",
				adultAppId: "",
                noticeList : [],
				noticeTotal : [],
                noticeCount : 0,
                faqList : [],
				faqTotal : [],
                faqCount : 0,
                faqHashTag : [],
                diagList : [],
				diagTotal : [],
                diagCount : 0,
                diagHashTag : [],
                diagCatCode1: "",
                titleClickYn : "N",
				loadingYn: "Y",
				totalCount : 0,
                completeKeywordList : [],
                completeCheck : false,
				cntryCode: _domainCntryCode
            }
        },
        created() {
            // console.log("SearchResult.created");
        },
        destroyed() {
            // console.log('SearchResult destroyed');
        },
        watch: {
            /*$route: "fetchData"*/
        },
        computed: {
        },
        methods: {
			track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
			keyPress(e) {
                // arrow key down, up
                if(e.which == 40 || e.which == 38) {
                    return;
                }
			    if (e.which == 13) {
                    this.checkSearchTime('');
				} else {
			        this.autoSearchText();
				}
			},
            autoSearchText() {

                const keyword = $('#sSearchAll2').val().toLowerCase();

                var params = {
                    searchText : keyword
                };
                const vm = this;

                this.$axios.post("/api/integratedSearch/retrieveAutoSearch.ajax", qs.stringify(params)).then((result) => {

                    console.log("completeKeywordList", vm.completeKeywordList);

                    if(result.data.completeKeywordList == undefined) {
                        vm.completeKeywordList = []
                    } else {
                        vm.completeKeywordList = result.data.completeKeywordList;
                    }

                    $("#sSearchAll2").autocomplete("option", "source", vm.completeKeywordList);
                    $("#sSearchAll2").autocomplete( "search", keyword );

                    /*this.$nextTick(function() {
                        vm.completeKeywordList = result.data.completeKeywordList;
                        $("#sSearchAll2").autocomplete({
                            appendTo: ".ac-search-static",
                            source : vm.completeKeywordList,
                            messages: {
                                noResults: '',
                                results: function() {}
                            }
                        });
                    })*/

                }).catch((error) => {
                    ui.loading.close();
                    this.loadingYn = "N";
                    alert("error");
                });
            },
            completeClick(valueText) {
                this.searchText = valueText;
                /*this.completeCheck = false;*/
            },
            deleteSearchText() {
                const vm = this;
				vm.searchText = '';
				$('#sSearchPage').focus();
            },
            isTabActive (category) {

                if (category == 'total') {
                    this.$nextTick(function() {
                        ui.init();
                        ui.faqAccordion.init();
                    });
				}

                if (category == this.category) {
                    return true;
				} else {
                    return false;
				}
            },
			more (category) {
                if (category == 'tvApp') {
                    // 목록 Setting
                    this.totalYn = "N";
                    this.tvAppYn = "Y";

                    this.category = 'tvApp';
                    this.retireveTvAppList();
				} else if (category == 'notice') {
                    // 목록 Setting
                    this.totalYn = "N";
                    this.noticeYn = "Y";

                    this.category = 'notice';
                    this.retireveNoticeList();
				} else if (category == 'faq') {
                    // 목록 Setting
                    this.totalYn = "N";
                    this.faqYn = "Y";

                    this.category = 'faq';
                    this.retireveFaqList();
				} else if (category == 'diag') {
                    // 목록 Setting
                    this.totalYn = "N";
                    this.diagYn = "Y";

                    this.category = 'diag';
                    this.retireveDiagList();
				}

                this.isTabActive (this.category);
			},
			move (category) {
                if (category == 'tvApp') {

                    const r = { path : `/main/tvapp`};
                    this.$router.push(r);

				} else if (category == 'notice') {

                    const r = { path : `/main/notice`};
                    this.$router.push(r);

				} else if (category == 'faq') {

                    const r = { path : `/main/faq`};
                    this.$router.push(r);

                } else if (category == 'diag') {

                    const r = { path : `/main/diag`};
                    this.$router.push(r);

                } else {

				}
			},
            checkSearchTime(keyword) {
                const vm = this;
                this.$axios.post("/api/common/checkSearchTimeValidation.ajax").then((result) => {
                    if(result.data.timeErrorYn == "Y") {
                        alert("Please wait 1 seconds");
                    } else {
                        if(keyword != "") {
                            vm.keywordClick(keyword);
                        } else {
                            vm.retrieveSearchList();
                        }
                    }
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            keywordClick (searchText) {
                const vm = this;
                vm.searchText = searchText;

                vm.retrieveSearchKeywordList();
            },
            appStar (avgSscr) {
                if (avgSscr >= 9.5) {
                    return 5;
                } else if (avgSscr >= 8.5) {
                    return 4.5;
                } else if (avgSscr >= 7.5) {
                    return 4;
                } else if (avgSscr >= 6.5) {
                    return 3.5;
                } else if (avgSscr >= 5.5) {
                    return 3;
                } else if (avgSscr >= 4.5) {
                    return 2.5;
                } else if (avgSscr >= 3.5) {
                    return 2;
                } else if (avgSscr >= 2.5) {
                    return 1.5;
                } else if (avgSscr >= 1.5) {
                    return 1;
                } else if (avgSscr >= 0.5) {
                    return 0.5;
                } else {
                    return 0;
                }
            },
            goTvappDetail(appId) {
                const r = { path : "/main/tvapp/detail?appId=" + appId
                + "&catCode1=&moreYn=N&cateYn=N&orderType=0&headerName=&appRankCode=&sellrUsrNo=" };
                this.$router.push(r);
            },
            setAdultAppName(appName, appId) {
                this.adultAppName = appName;
                this.adultAppId = appId;
            },
            goLgaccount(loginYn) {
                const vm = this;

                var _params = {
                    appId: vm.adultAppId,
                    catCode1: "",
                    moreYn: "N",
                    cateYn: "N",
                    orderType: "0",
                    headerName: "",
                    appRankCode: "",
                    sellrUsrNo: ""
                };

                const params = {
                    cntryCode: _domainCntryCode,
                    path: "tvapp/detail?" + qs.stringify(_params),
                    loginYn: loginYn
                };

                this.$axios.post('/api/main/retrieveLoginInfo.ajax',
                    qs.stringify(params)).then((result) => {
                    var loginUrl = result.data.loginUrl;
                    window.location = loginUrl;
                }).catch((err) => {
                    alert(err);
                });
            },
            readCntt(seqNo) {

                this.$store.state.faqSeqNo = seqNo;
                this.$store.state.satisfType = 'faq';

                const vm = this;
                if(seqNo != vm.seqNo) {
                    vm.seqNo = seqNo;
                    vm.updateViewCnt();
                } else {
                    if(vm.titleClickYn == 'Y') {
                        vm.titleClickYn = 'N';
                    } else {
                        vm.updateViewCnt();
                    }
                }
            },
			goSatisf(clickType) {
				const vm = this;

				const params = {
					clickType: clickType,
					faqSeqNo: vm.seqNo
				};

                this.$axios.post("/api/faq/mergeFaqSatisf.ajax",
                    qs.stringify(params)).then((result) => {
                    alert(this.$t("sdp.Satisfaction.message.pop_text6"));
                }).catch((err) => {
                    alert("error : " + err);
                });
			},
            updateViewCnt() {
                const vm = this;
                const params = {
                    seqNo: vm.seqNo
                };
                this.$axios.post("/api/faq/updateFaqViewCnt.ajax",
                    qs.stringify(params)).then((result) => {
                    vm.titleClickYn = 'Y';
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
			totalEvent() {
                // 목록 Setting
                this.totalYn = "Y";
                this.tvAppYn = "N";
                this.noticeYn = "N";
                this.faqYn = "N";
                this.diagYn = "N";

                this.category = 'total';
            },
            retrieveNoticeInfo(seqNo) {
                /*ui.searchAll.close('totalSearch');*/ // 검색바 닫기

                const r = { path : `/main/notice/detail?seqNo=${seqNo}&keyword=&curPage=1`};
                this.$router.push(r);
            },
            updateDiagViewCnt(seqNo, catCode1) {
                const vm = this;
                vm.diagSeqNo = seqNo;
                vm.diagCatCode1 = catCode1;

                const params = {
                    seqNo: vm.diagSeqNo
                };

                this.$axios.post("/api/diag/updateDiagViewCnt.ajax",
                    qs.stringify(params)).then((result) => {
                    const r = { path : "/main/diag/detail?seqNo=" + vm.diagSeqNo + "&catCode1="
                    + vm.diagCatCode1 + "&searchYn=N&allClickYn=N&schTxt=&curPage=1" };
                    this.$router.push(r);
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            retrieveSearchList() {

                this.searchText = $('#sSearchAll2').val();

                if (this.searchText.length <= 1) {
                    alert(this.$t('requisite.minlength', { var1 : this.$t('sdp.search.message.integrated'), var2 : 2 }));
                    return;
                }

                // 값이 클 경우 값을 잘라서 검색
                var strValue = this.searchText;
                var strLength = this.getStrByte(strValue);

                if (strLength > this.maxLength) {
                    strValue = this.strCutByByte(strValue, this.maxLength);
                    strLength = this.getStrByte(strValue);
                    this.searchText = strValue;
				}

                const r = { path : `/main/integrated/search?searchText=` + this.searchText};
                this.$router.push(r);

                ui.loading.open();
                this.loadingYn = "Y";

                const params = {
                    searchText : this.searchText
                };

                this.$axios.post("/api/integratedSearch/retrieveIntegratedSearchList.ajax", qs.stringify(params)).then((result) => {
                    this.keywordList = result.data.keywordList;
					this.userAge = result.data.userAge;

					ui.loading.close();

                    // Tv App
                    this.appList = result.data.appList;
                    this.appCount = result.data.appCount;
                    this.appTotal = result.data.appTotal;

                    // 공지사항
                    this.noticeTotal = result.data.noticeList;
                    this.noticeCount = result.data.noticeCount;

                    // FAQ
                    this.faqTotal = result.data.faqList;
                    this.faqCount = result.data.faqCount;
                    this.faqHashTag = result.data.faqHashTag;

                    // 자가진단
                    this.diagTotal = result.data.diagList;
                    this.diagCount = result.data.diagCount;
                    this.diagHashTag = result.data.diagHashTag;

                    this.loadingYn = "N";

                    this.totalCount = this.appCount + this.noticeCount + this.faqCount + this.diagCount;

                    if (this.noticeYn == 'Y') {
                        this.retireveNoticeList();
					} else if (this.faqYn == 'Y') {
                        this.retireveFaqList();
					} else if (this.diagYn == 'Y') {
                        this.retireveDiagList();
					}

                    this.$nextTick(function() {
                        ui.init();
                        ui.faqAccordion.init();
                        $("#sSearchAll2").blur();
                    });

                }).catch((error) => {
                    ui.loading.close();
                    this.loadingYn = "N";
                    alert("error");
                });
            },
            retrieveSearchKeywordList() {

                if (this.searchText.length <= 1) {
                    alert(this.$t('requisite.minlength', { var1 : this.$t('sdp.search.message.integrated'), var2 : 2 }));
                    return;
                }

                // 값이 클 경우 값을 잘라서 검색
                var strValue = this.searchText;
                var strLength = this.getStrByte(strValue);

                if (strLength > this.maxLength) {
                    strValue = this.strCutByByte(strValue, this.maxLength);
                    strLength = this.getStrByte(strValue);
                    this.searchText = strValue;
                }

                const r = { path : `/main/integrated/search?searchText=` + this.searchText};
                this.$router.push(r);

                ui.loading.open();
                this.loadingYn = "Y";

                const params = {
                    searchText : this.searchText
                };

                this.$axios.post("/api/integratedSearch/retrieveIntegratedSearchList.ajax", qs.stringify(params)).then((result) => {
                    this.keywordList = result.data.keywordList;
                    this.userAge = result.data.userAge;

                    ui.loading.close();

                    // Tv App
                    this.appList = result.data.appList;
                    this.appCount = result.data.appCount;
                    this.appTotal = result.data.appTotal;

                    // 공지사항
                    this.noticeTotal = result.data.noticeList;
                    this.noticeCount = result.data.noticeCount;

                    // FAQ
                    this.faqTotal = result.data.faqList;
                    this.faqCount = result.data.faqCount;
                    this.faqHashTag = result.data.faqHashTag;

                    // 자가진단
                    this.diagTotal = result.data.diagList;
                    this.diagCount = result.data.diagCount;
                    this.diagHashTag = result.data.diagHashTag;

                    this.loadingYn = "N";

                    this.totalCount = this.appCount + this.noticeCount + this.faqCount + this.diagCount;

                    if (this.noticeYn == 'Y') {
                        this.retireveNoticeList();
                    } else if (this.faqYn == 'Y') {
                        this.retireveFaqList();
                    } else if (this.diagYn == 'Y') {
                        this.retireveDiagList();
                    }

                    this.$nextTick(function() {
                        ui.init();
                        ui.faqAccordion.init();
                    });

                }).catch((error) => {
                    ui.loading.close();
                    this.loadingYn = "N";
                    alert("error");
                });
            },
            retireveTvAppList() { // TV App Tab

                // 목록 Setting
                this.totalYn = "N";
                this.tvAppYn = "Y";
                this.noticeYn = "N";
                this.faqYn = "N";
                this.diagYn = "N";

                this.category = 'tvApp';

            },
			retireveNoticeList() { // 공지사항 Tab
			    ui.loading.open();
			    this.loadingYn = "Y";

                const params = {
                    searchText : this.searchText
                };

                this.$axios.post("/api/integratedSearch/retrieveNoticeList.ajax", qs.stringify(params)).then((result) => {
                    ui.loading.close();

                    // 공지사항
                    this.noticeList = result.data.noticeList;
                    this.noticeCount = result.data.noticeCount;

                    // 목록 Setting
					this.totalYn = "N";
                    this.tvAppYn = "N";
                    this.noticeYn = "Y";
                    this.faqYn = "N";
                    this.diagYn = "N";

                    this.category = 'notice';
                    this.loadingYn = "N";

                    this.totalCount = this.appCount + this.noticeCount + this.faqCount + this.diagCount;

                }).catch((error) => {
                    ui.loading.close();
                    this.loadingYn = "N";
                    alert("error");
                });
			},
			retireveFaqList() { // FAQ Tab
                ui.loading.open();
                this.loadingYn = "Y";

                const params = {
                    searchText : this.searchText
                };

                this.$axios.post("/api/integratedSearch/retrieveFaqList.ajax", qs.stringify(params)).then((result) => {
                    ui.loading.close();

                    // FAQ
                    this.faqList = result.data.faqList;
                    this.faqCount = result.data.faqCount;
                    this.faqHashTag = result.data.faqHashTag;

                    this.$nextTick(function() {
                        ui.init();
                        ui.faqAccordion.init()
                    });


                    // 목록 Setting
                    this.totalYn = "N";
                    this.tvAppYn = "N";
                    this.noticeYn = "N";
                    this.faqYn = "Y";
                    this.diagYn = "N";

                    this.category = 'faq';
                    this.loadingYn = "N";

                    this.totalCount = this.appCount + this.noticeCount + this.faqCount + this.diagCount;


                }).catch((error) => {
                    ui.loading.close();
                    this.loadingYn = "N";
                    alert("error");
                });
			},
            retireveDiagList() { // 자가진단 Tab
                ui.loading.open();
                this.loadingYn = "Y";

                const params = {
                    searchText : this.searchText
                };

                this.$axios.post("/api/integratedSearch/retrieveDiagList.ajax", qs.stringify(params)).then((result) => {
                    ui.loading.close();

                    // 자가진단
                    this.diagList = result.data.diagList;
                    this.diagCount = result.data.diagCount;
                    this.diagHashTag = result.data.diagHashTag;

                    // 목록 Setting
                    this.totalYn = "N";
                    this.tvAppYn = "N";
                    this.noticeYn = "N";
                    this.faqYn = "N";
                    this.diagYn = "Y";

                    this.category = 'diag';
                    this.loadingYn = "N";

                    this.totalCount = this.appCount + this.noticeCount + this.faqCount + this.diagCount;

                }).catch((error) => {
                    ui.loading.close();
                    this.loadingYn = "N";
                    alert("error");
                });
			},
            lineBreakCntt(cntt) {
                if(cntt != null && cntt != "") {
                    return cntt.split("\n").join("<br />");
                } else {
                    return "";
                }
            },
            strCutByByte (str, max) {
                var byteLength = 0;
                var result = "";

                for (var inx = 0; inx < str.length; inx++) {
                    var oneChar  = str.charAt(inx);
                    var charCode = oneChar.charCodeAt(0);
                    if(charCode)
                        if(charCode != 13){
                            if (charCode <= 0x00007F) {
                                byteLength ++;
                            }else if (charCode <= 0x0007FF) {
                                byteLength += 2;
                            }else if (charCode <= 0x00FFFF) {
                                byteLength += 3;
                            } else {
                                byteLength += 4;
                            }
                        }

                    if (byteLength > max) {
                        break;
                    }
                    result = result + str.charAt(inx);
                }

                return result;
            },
            getStrByte(value) {
                var byteLength = 0, ch;
                var charCode;
                var len = value.length;
                for(var i = 0; i < len; i++) {
                    ch = value.charAt(i);
                    charCode = ch.charCodeAt(0);
                    if(charCode)
                        if(charCode != 13){ // enter값이 2번 넘어온다.10,13 10번은 화면 test 시  나오지만 13번은 나오지 않아 13번을 막음.
                            if (charCode <= 0x00007F) {
                                byteLength ++;
                            }else if (charCode <= 0x0007FF) {
                                byteLength += 2;
                            }else if (charCode <= 0x00FFFF) {
                                byteLength += 3;
                            } else {
                                byteLength += 4;
                            }
                        }
                }
                return byteLength;
            },
			loadSearchList(keyword) {
				const params = {
                	searchText : keyword
				};

				this.$axios.post("/api/integratedSearch/retrieveIntegratedSearchList.ajax", qs.stringify(params)).then((result) => {
					this.keywordList = result.data.keywordList;

					ui.loading.close();

					// Tv App
					this.appList = result.data.appList;
					this.appCount = result.data.appCount;
					this.appTotal = result.data.appTotal;

					// 공지사항
					this.noticeTotal = result.data.noticeList;
					this.noticeCount = result.data.noticeCount;

					// FAQ
					this.faqTotal = result.data.faqList;
					this.faqCount = result.data.faqCount;
					this.faqHashTag = result.data.faqHashTag;

					// 자가진단
					this.diagTotal = result.data.diagList;
					this.diagCount = result.data.diagCount;
					this.diagHashTag = result.data.diagHashTag;

					this.loadingYn = "N";

					this.totalCount = this.appCount + this.noticeCount + this.faqCount + this.diagCount;

					const vm = this;
					this.$nextTick(function() {
						ui.init();
						ui.faqAccordion.init()

                        $("#sSearchAll2").autocomplete({
                            appendTo: ".ac-search-static",
                            source : vm.completeKeywordList,
                            messages: {
                                noResults: '',
                                results: function() {}
                            }
                        });

                        ui.searchAll.closeCallback = function() {
                            vm.searchText = '';
                        }
					});

				}).catch((error) => {
					ui.loading.close();
					this.loadingYn = "N";
					alert("error");
				});
			}
		},
        beforeRouteUpdate(to, from, next) {

            if(this.searchText != to.query.searchText) {
                this.searchText = to.query.searchText;
                this.loadSearchList(this.searchText);
            }

            next();
        },
        mounted() {

            // ui.searchAll.close('searchAll'); // 검색바 닫힘

			ui.loading.open();

            this.searchText = this.$route.query.searchText;
			
			this.loadSearchList(this.searchText);
        }
    }
</script>

<style scoped>

</style>