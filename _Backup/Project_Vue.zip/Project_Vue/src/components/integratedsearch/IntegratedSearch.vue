<template>
    <div id="searchAll" class="search-all-wrap" aria-hidden="true" hidden>
        <div class="search-page" role="search">
            <div class="search-page-inner in-sec">
                <!-- 검색폼 -->
                <fieldset>
                    <legend id="searchAllLegend">{{ $t('sdp.search.message.integrated') }}</legend>
                    <div class="search-form ac-form-wrap">
                        <!--<input v-model="searchText" type="text" name="sSearchAll" id="sSearchAll" class="search-check search-focus" @keyup="keyPress" autocomplete="off" :placeholder="$t('sdp.search.message.text_box')" :title="$t('sdp.search.message.integrated')" />-->
                        <input v-model="searchText" type="text" name="sSearchAll" id="sSearchAll" class="search-check search-focus ac-keyword" @keyup="keyPress" autocomplete="on" :placeholder="$t('sdp.search.message.text_box')" :title="$t('sdp.search.message.integrated')" />
                        <transition name="fade" v-on:after-leave="afterLeave">
                            <button type="button" @click="deleteSearchText()" class="btn-ico search-delete centered-r" v-show="searchText != null && searchText != ''"><span><i class="ico ico-del2">{{ $t('gwa.alt.common.wa_label_59') }}</i></span></button>
                        </transition>
                        <button type="submit" class="btn btn-search centered-r" :aria-label="$t('gwa.alt.common.wa_label_48')" @click="checkSearchTime('');"><span><i class="ico ico-search2 centered-c"></i></span></button>
                        <!-- Auto Complete -->
                        <div class="ac-form ac-search-fixed"></div>
                        <!-- //Auto Complete -->
                    </div>
                </fieldset>
                <!-- //검색폼 -->
                <!-- 추천검색어 -->
                <!-- 고도화 ver2 : 속성 aria-label 검색 추가 -->
                <!-- 추천검색어 -->
                <div class="keyword-wrap" data-state="closed">
                    <h3 class="keyword-tit">{{ $t('sdp.search.message.recommend') }}</h3>
                    <div class="keyword">
                        <div id="foldKeywordAll2" class="folder-keyword folder-content type-all" data-name="foldKeywordAll2">
                            <div class="folder-inner">
                                <p v-for="keyword in keywordList"><a href="javascript:;" @click="checkSearchTime(keyword.keywrd);" :aria-label="keyword.keywrd+' '+$t('gwa.alt.main.sch')">{{ keyword.keywrd }}</a></p>
                            </div>
                        </div>
                        <div class="keyword-btn">
                            <button type="button" class="btn-ico folder-open is-active" tabindex="0" aria-controls="foldKeywordAll2" aria-expanded="false" aria-hidden="false" data-role="more" data-target="foldKeywordAll2"><span><i class="arw arw-toggle6">{{ $t('gwa.alt.common.wa_label_32') }}</i></span></button>
                            <button type="button" class="btn-ico folder-close" tabindex="-1" aria-controls="foldKeywordAll2" aria-expanded="true" aria-hidden="true" data-role="more" data-target="foldKeywordAll2"><span><i class="arw arw-toggle6">{{ $t('gwa.alt.common.wa_label_33') }}</i></span></button>
                        </div>
                    </div>
                </div>
                <!-- //추천검색어 -->
            </div>

            <!-- <button type="button" class="return-close">{{ $t('sdp.search.message.integrated') }}</button> 마지막에 닫으라고 고려해놨더니 왜 초점이 여기로 오냐고 잘못된 지적을 받음 -->
        </div>
    </div>
</template>

<style>
</style>

<script>

    import qs from "qs";

    export default {
        name: "IntegratedSearch",
        data() {
            return {
                keywordList : [],
                searchText : "",
                maxLength: 256,
                completeKeywordList : []
            }
        },
        computed() {
        },
        created() {
            // console.log("SearchResult.created");
        },
        destroyed() {
            // console.log('SearchResult destroyed');
        },
        watch: {
            /*$route: "fetchData"*/
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            keyPress(e) {

                // arrow key down, up
                if(e.which == 40 || e.which == 38) {
                    return;
                }

                if (e.which == 13) {
                    this.checkSearchTime('');
                } else {
                    this.autoSearchText();
                }
            },
            autoSearchText() {

                const keyword = $('#sSearchAll').val().toLowerCase();

                var params = {
                    searchText : keyword
                };

                const vm = this;
                this.$axios.post("/api/integratedSearch/retrieveAutoSearch.ajax", qs.stringify(params)).then((result) => {

                    console.log("completeKeywordList", vm.completeKeywordList);

                    // vm.$nextTick(function() {

                        if(result.data.completeKeywordList == undefined) {
                            vm.completeKeywordList = []
                        } else {
                            vm.completeKeywordList = result.data.completeKeywordList;
                        }

                        $("#sSearchAll").autocomplete("option", "source", vm.completeKeywordList);
                        $("#sSearchAll").autocomplete( "search", keyword );

                        // $("#sSearchAll").autocomplete({
                        //     appendTo: ".ac-search-fixed",
                        //     source : vm.completeKeywordList,
                        //     messages: {
                        //         noResults: '',
                        //         results: function() {}
                        //     }
                        // });
                    // })

                }).catch((error) => {
                    ui.loading.close();
                    this.loadingYn = "N";
                    alert("error");
                });
            },
            completeClick(valueText) {
                this.searchText = valueText;
            },
            deleteSearchText() {
                const vm = this;
                vm.searchText = '';
                $('#sSearchAll').focus();
            },
            checkSearchTime(keyword) {
                const vm = this;
                this.$axios.post("/api/common/checkSearchTimeValidation.ajax").then((result) => {
                    if(result.data.timeErrorYn == "Y") {
                        alert("Please wait 1 seconds");
                    } else {
                        if(keyword != "") {
                            vm.keywordClick(keyword);
                        } else {
                            vm.retrieveSearchList();
                        }
                    }
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            keywordClick (searchText) {
                const vm = this;
                vm.searchText = searchText;

                vm.retireveSearchKeyword();
            },
            retrieveSearchList() {
                this.searchText = $('#sSearchAll').val();
                if (this.searchText.length <= 1) {
                    alert(this.$t('requisite.minlength', { var1 : this.$t('sdp.search.message.integrated'), var2 : 2 }));
                    return;
                }

                // 값이 클 경우 값을 잘라서 검색
                var strValue = this.searchText;
                var strLength = this.getStrByte(strValue);

                if (strLength > this.maxLength) {
                    strValue = this.strCutByByte(strValue, this.maxLength);
                    strLength = this.getStrByte(strValue);
                    this.searchText = strValue;
                }

                const r = { path : `/main/integrated/search?searchText=` + this.searchText};
                this.$router.push(r);
                this.$nextTick(function() {
                    this.searchText = "";
                });
                ui.searchAll.close('searchAll'); // 검색바 닫힘
            },
            retireveSearchKeyword() {
                if (this.searchText.length <= 1) {
                    alert(this.$t('requisite.minlength', { var1 : this.$t('sdp.search.message.integrated'), var2 : 2 }));
                    return;
                }

                // 값이 클 경우 값을 잘라서 검색
                var strValue = this.searchText;
                var strLength = this.getStrByte(strValue);

                if (strLength > this.maxLength) {
                    strValue = this.strCutByByte(strValue, this.maxLength);
                    strLength = this.getStrByte(strValue);
                    this.searchText = strValue;
                }

                const r = { path : `/main/integrated/search?searchText=` + this.searchText};
                this.$router.push(r);
                this.$nextTick(function() {
                    this.searchText = "";
                });
                ui.searchAll.close('searchAll'); // 검색바 닫힘
            },
            strCutByByte (str, max) {
                var byteLength = 0;
                var result = "";

                for (var inx = 0; inx < str.length; inx++) {
                    var oneChar  = str.charAt(inx);
                    var charCode = oneChar.charCodeAt(0);
                    if(charCode)
                        if(charCode != 13){
                            if (charCode <= 0x00007F) {
                                byteLength ++;
                            }else if (charCode <= 0x0007FF) {
                                byteLength += 2;
                            }else if (charCode <= 0x00FFFF) {
                                byteLength += 3;
                            } else {
                                byteLength += 4;
                            }
                        }

                    if (byteLength > max) {
                        break;
                    }
                    result = result + str.charAt(inx);
                }

                return result;
            },
            getStrByte(value) {
                var byteLength = 0, ch;
                var charCode;
                var len = value.length;
                for(var i = 0; i < len; i++) {
                    ch = value.charAt(i);
                    charCode = ch.charCodeAt(0);
                    if(charCode)
                        if(charCode != 13){ // enter값이 2번 넘어온다.10,13 10번은 화면 test 시  나오지만 13번은 나오지 않아 13번을 막음.
                            if (charCode <= 0x00007F) {
                                byteLength ++;
                            }else if (charCode <= 0x0007FF) {
                                byteLength += 2;
                            }else if (charCode <= 0x00FFFF) {
                                byteLength += 3;
                            } else {
                                byteLength += 4;
                            }
                        }
                }
                return byteLength;
            }
        },
        mounted() {

            const vm = this;
            this.$axios.post("/api/integratedSearch/retrieveIntegratedSearch.ajax").then((result) => {
                vm.keywordList = result.data.keywordList;
                vm.$nextTick(function() {
                    ui.init();

                    $("#sSearchAll").autocomplete({
                        appendTo: ".ac-search-fixed",
                        source : vm.completeKeywordList,
                        messages: {
                            noResults: '',
                            results: function() {}
                        }
                    });

                    ui.searchAll.closeCallback = function() {
                        vm.searchText = '';
                    }
                });
            }).catch((error) => {
                alert("error");
            });

            // $("#sSearchAll").autocomplete({
            //     appendTo: ".ac-search-fixed",
            //     source : vm.completeKeywordList,
            //     messages: {
            //         noResults: '',
            //         results: function() {}
            //     }
            // });

        }
    }
</script>

<style scoped>
.center {
    margin: auto;
}

canvas {
    border: 3px solid blue;
}

</style>