<template>
		<!-- content -->
		<section id="content" class="content faq-cont">
			<!-- content Header -->
			<div class="content-header sub-visual">
                <div class="sub-visual-bg"></div>
				<div class="in-sec">
					<div class="tit-wrap centered-c">
						<h2 class="tit-h2">{{ $t('sdp.menu.faq') }}</h2>
						<p class="explain-h2">{{ $t('sdp.faq.message.title_explain') }}</p>
					</div>
				</div>
			</div>
			<!-- //content Header -->
			<!-- content Body -->
			<div class="content-body">
				<!-- 검색전체영역 -->
				<div class="search-page-wrap in-sec" role="search">
					<!-- 검색영역 -->
					<fieldset class="search-page">
						<legend id="searchLegend">{{ $t('sdp.support.message.faqSearch') }}</legend>
						<!-- 검색입력 -->
						<div class="search-form">
							<input type="text" v-model="schTxt" @keydown="checkTextLength($event);" name="ssearchPage" id="sSearchPage" :placeholder="$t('sdp.search.message.text_box')" @keyup.enter="checkSearchTime('')" :title="$t('gwa.alt.common.wa_title_12')" />
							<transition name="fade" v-on:after-leave="afterLeave">
								<button type="button" @click="deleteKeyword()" class="btn-ico search-delete centered-r" v-show="schTxt != null && schTxt != ''"><span><i class="ico ico-del2">{{ $t('gwa.alt.common.wa_label_59') }}</i></span></button>
							</transition>
							<button type="submit" class="btn btn-search centered-r" @click="checkSearchTime('')"><span><i class="ico ico-search2 centered-c">{{ $t('gwa.alt.common.wa_label_10') }}</i></span></button>
						</div>
						<!-- //검색입력 -->
						<!-- 추천검색어 -->
                        <!-- 고도화 ver2 : 속성 aria-label 검색 추가 -->
						<div class="keyword-wrap" data-state="closed">
							<h3 class="keyword-tit">{{ $t('sdp.search.message.recommend') }}</h3>
							<div class="keyword">
								<div id="foldKeywordPage" class="folder-keyword folder-content type-page" data-name="foldKeywordPage">
									<div class="folder-inner">
										<p v-for="item in keywordList"><a href="javascript:;" @click="checkSearchTime(item.keywrd)" :aria-label="item.keywrd+' '+$t('gwa.alt.main.sch')">{{ item.keywrd }}</a></p>
									</div>
								</div>
                                <div class="keyword-btn">
                                    <button type="button" class="btn-ico folder-open is-active" tabindex="0" aria-controls="foldKeywordPage" aria-expanded="true" aria-hidden="true" data-role="more" data-target="foldKeywordPage"><span><i class="arw arw-toggle6">{{ $t('gwa.alt.common.wa_label_32') }}</i></span></button>
                                    <button type="button" class="btn-ico folder-close" tabindex="-1" aria-controls="foldKeywordPage" aria-expanded="false" aria-hidden="false" data-role="more" data-target="foldKeywordPage"><span><i class="arw arw-toggle6">{{ $t('gwa.alt.common.wa_label_33') }}</i></span></button>
                                </div>
							</div>
						</div>
						<!-- //추천검색어 -->
					</fieldset>
					<!-- //검색영역 -->
				</div>
				<!-- //검색전체영역 -->

				<!-- 탭영역 -->
				<div class="tab-type1-wrap in-sec">
					<!-- 탭메뉴 개발참고사항
						선택된 메뉴 : li태그 - class="is-active", a태그 - aria-selected="true" aria-expanded="true"
					-->
                    <!-- 고도화 ver2 : 구조 tit 변경 -->
					<nav class="tab-nav tab-type1 tab-responsive">
						<ul role="tablist">
							<li role="presentation" :class="{'is-active' : isTabActive('')}" v-show="faqHighCateList.length > 0">
								<a href="javascript:;" role="tab" aria-selected="true" aria-expanded="true" @click="goAllSearch()">
									<span class="tit">{{ firstTabName }}<em v-show="searchYn == 'Y'" class="label-type2">{{ totCnt }}</em></span>
								</a>
							</li>
							<li v-for="item in faqHighCateList" role="presentation" :class="{'is-active' : isTabActive(item.catCode)}">
								<a href="javascript:;" role="tab" aria-selected="false" aria-expanded="false" @click="goTabSearch(item.catCode, item.catName)">
									<span class="tit">{{ item.catName }}<em class="label-type2">{{ item.cnt }}</em></span>
								</a>
							</li>
						</ul>
					</nav>
					<!-- //탭메뉴 -->

					<!-- 탭내용 -->
					<div class="tab-body">
                        <h3 class="blind dv-pc-only">{{ tabPanelName }}</h3>
                        <div class="loading-wrap" v-if="loadingYn == 'Y'">
                            <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                        </div>
                        <!-- FAQ 전체영역 -->
                        <div id="faqAjaxWrap" class="faq-wrap" v-else-if="faqList.length > 0">
                            <!-- FAQ 공통모듈
                                개발참고사항 (아이디 연결 참고바랍니다.)
                                제목 .accordion-toggle   : href, aria-controls
                                내용 .accordion-content  : id
                                데이터 로드 후 호출함수   : ui.faqAccordion.init();
                            -->
                            <!-- FAQ 목록그룹 -->
                            <div class="accordion-wrap faq-accordion">
                                <!-- 반복영역 -->
                                <div class="accordion" v-for="(item, index) in faqList">
                                    <div class="accordion-title">
                                        <a :href="'#faqContent'+(index+1)" class="accordion-toggle" role="button"
                                        :aria-controls="'faqContent'+(index+1)" aria-expanted="false" @click="readCntt(item.seqNo, index)">
                                            <em class="tit-qusetion" :aria-label="$t('gwa.alt.faq.wa_label_1')">Q</em>
                                            <em class="tit-part">{{ item.catName }}</em>
                                            <span class="tit-label" v-html="item.titleName"></span>
                                            <i class="arw arw-toggle" aria-hidden="true"></i>
                                        </a>
                                    </div>
                                    <div :id="'faqContent'+(index+1)" class="accordion-content" aria-hidden="true">
                                        <em class="tit-answer" :aria-label="$t('gwa.alt.faq.wa_label_2')">A</em>
                                        <div class="data-content" role="text" v-html="lineBreakCntt(item.cntt)"></div>
                                        <div class="tag-wrap">
                                            <template v-for="tag in faqHashTagList">
                                                <a v-show="tag.seqNo == item.seqNo" @click="goKeywordSearch(tag.hashTag)" href="javascript:;" class="tag-type1" role="button">
                                                    #{{ tag.hashTag }}
                                                </a>
                                            </template>
                                        </div>
                                        <div class="msg-wrap">
                                            <p class="txt-area"><i class="arw arw-right" aria-hidden="true"></i>{{ $t('sdp.Satisfaction.message.question') }}</p>
                                            <div class="btn-area">
                                                <button type="button" class="btn btn-type4 btn-primary" @click="goSatisf('Y')"><span>{{ $t('sdp.Satisfaction.message.btn1') }}</span></button>
                                                <button type="button" class="btn btn-type4 popup-open" aria-controls="popupFaqQuestion" aria-haspopup="true"><span>{{ $t('sdp.Satisfaction.message.btn2') }}</span></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- //반복영역 -->
                            </div>
                            <!-- //FAQ 목록그룹 -->

                            <!-- 페이징 개발참고(선택된 현재페이지 번호)
                                1. span태그로 변경
                                2. aria-current="true"
                                3. role="text"로 변경
                            -->
                            <!-- 고도화 ver2 : 속성 페이지 정보 aria-label 수정 -->
                            <div class="pagination-wrap">
                                <div class="pagination">
                                    <div class="btn-wrap">
                                        <a @click="goFirstPage()" href="javascript:;" class="btn-ico btn-page first" :class="paging.hasFirst == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-first">{{ $t('gwa.alt.common.wa_title_36') }}</i></span></a>
                                        <a @click="goPrevPage()" href="javascript:;" class="btn-ico btn-page prev" :class="paging.hasPrev == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-prev">{{ $t('gwa.alt.common.wa_title_37') }}</i></span></a>
                                    </div>
                                    <ul class="num-wrap">
                                        <li v-for="page in paging.pageList">
                                            <span v-show="page.num == paging.curPage" class="btn btn-num" :aria-label="$t('gwa.alt.common.wa_title_38', { var1 : page.num })" aria-current="true" role="text"><span>{{ page.num }}</span></span>
                                            <a v-show="page.num != paging.curPage" @click="goPage(page.num)" href="javascript:;" class="btn btn-num" :aria-label="$t('gwa.alt.common.wa_title_38', { var1 : page.num })" role="button"><span>{{ page.num }}</span></a>
                                        </li>
                                    </ul>
                                    <div class="btn-wrap">
                                        <a @click="goNextPage()" href="javascript:;" class="btn-ico btn-page next" :class="paging.hasNext == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-next">{{ $t('gwa.alt.common.wa_title_39') }}</i></span></a>
                                        <a @click="goLastPage()" href="javascript:;" class="btn-ico btn-page last" :class="paging.hasLast == true ? '' : 'is-hidden'" role="button"><span><i class="ico ico-page-last">{{ $t('gwa.alt.common.wa_title_40') }}</i></span></a>
                                    </div>
                                </div>
                            </div>
                            <!-- //페이징 -->
                        </div>
                        <!-- //FAQ 전체영역 -->
                        <!-- 미등록게시물 -->
                        <div class="noData-wrap" v-else>
                            <div class="noData">
                                <div class="inner">
                                    <p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
                                </div>
                            </div>
                        </div>
                        <!-- //미등록게시물 -->
					</div>
					<!-- //탭내용 -->

					<!-- 관련정보 -->
					<div class="box-wrap box-relateMenu">
						<div class="box">
							<div class="box-header">
								<p class="para">{{ $t('sdp.faq.message.text1') }}</p>
							</div>
							<div class="box-body">
								<div class="grid grid-divieder">
									<div class="col col-6">
										<router-link to="/main/diag" class="relate-link">
											<span class="ico-area" aria-hidden="true"><i class="ico ico-selftest"></i></span>
											<dl>
												<dt class="tit">{{ $t('sdp.menu.gnb.self') }}</dt>
												<dd class="txt">{{ $t('sdp.self.message.title1') }}</dd>
											</dl>
										</router-link>
									</div>
									<div class="col col-6">
										<router-link to="/main/inquiry" class="relate-link">
											<span class="ico-area" aria-hidden="true"><i class="ico ico-ques"></i></span>
											<dl>
												<dt class="tit">{{ $t('sdp.menu.qna') }}</dt>
												<dd class="txt" v-html="$t('sdp.support.message.new.qna4')"></dd>
											</dl>
										</router-link>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- //관련정보 -->
				</div>
				<!-- //탭영역 -->

				<!-- 팝업_만족도조사 -->
				<FaqSatisfPop></FaqSatisfPop>
				<!-- //팝업_만족도조사 -->

                <div id="popupTabSelect" class="popup-wrap popup-select" role="dialog">
                    <div class="popup popup-tab">
                        <nav class="tab-nav tab-type1 tab-responsive">
                            <ul role="tablist">
                                <li role="presentation" :class="{'is-active' : isTabActive('')}" v-show="faqHighCateList.length > 0">
                                    <a href="javascript:;" role="tab" aria-selected="true" aria-expanded="true" @click="goAllSearch()">
                                        <span class="tit">{{ firstTabName }}<em v-show="searchYn == 'Y'" class="label-type2">{{ totCnt }}</em></span>
                                    </a>
                                </li>
                                <li v-for="item in faqHighCateList" role="presentation" :class="{'is-active' : isTabActive(item.catCode)}">
                                    <a href="javascript:;" role="tab" aria-selected="false" aria-expanded="false" @click="goTabSearch(item.catCode)">
                                        <span class="tit">{{ item.catName }}<em class="label-type2">{{ item.cnt }}</em></span>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                        <button type="button" class="btn-ico btn-close-select" aria-controls="popupTabSelect"><span><i class="ico ico-close2">{{ $t('gwa.alt.common.wa_label_11') }}</i></span></button>
                    </div>
                </div>
			</div>
			<!-- //content Body -->
		</section>
		<!-- //content -->
</template>

<script>
    import qs from "qs";
    import FaqSatisfPop from '@/components/faq/FaqSatisfPop';

    export default {
        name: "Faq",
        components: {
            FaqSatisfPop
        },
        data() {
            return {
                faqList: [],
                faqHighCateList: [],
                faqLowCateList: [],
                totCnt: 0,
                faqHashTagList: [],
                catCode1: "",
                searchYn: "N",
                allClickYn: "Y",
                titleClickYn: "N",
				loadingYn: "Y",
                seqNo: "",
                schTxt: "",
				maxLength: 256,
                keywordList: [],
                paging: {
                    pageList: [],
                    totalCount: 0,
                    pageCount: 0,
					rowCount: 0,
                    curPage: 1,
                    hasNext: false,
                    hasLast: false,
                    hasPrev: false,
                    hasFirst: false,
                    curMaxPage: 0,
                    curMinPage: 1,
					maxPage: 0
                },
				inquiryYn: false,
                tabPanelName: ""
            }
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
			checkSearchTime(keyword) {
                const vm = this;
                this.$axios.post("/api/common/checkSearchTimeValidation.ajax").then((result) => {
                    if(result.data.timeErrorYn == "Y") {
                        alert("Please wait 1 seconds");
					} else {
                        if(keyword != "") {
                            vm.goKeywordSearch(keyword);
						} else {
                            vm.goSearch();
						}
					}
                }).catch((err) => {
                    alert("error : " + err);
                });
			},
            goSearch() {
                const vm = this;
                vm.searchYn = "Y";
                vm.tabPanelName = vm.firstTabName;
                vm.paging.curPage = 1;
                vm.goSearchAjax();
            },
            goAllSearch() {
                const vm = this;
                vm.catCode1 = "";
                vm.tabPanelName = vm.firstTabName;
                vm.allClickYn = "Y";
                vm.paging.curPage = 1;
                vm.goSearchAjax();
            },
            goTabSearch(catCode1, catName) {
                const vm = this;
                vm.catCode1 = catCode1;
                vm.tabPanelName = catName;
                vm.allClickYn = "N";
                vm.paging.curPage = 1;
                vm.goSearchAjax();
            },
            goKeywordSearch(keyword) {
                const vm = this;
                vm.searchYn = "Y";
                vm.tabPanelName = vm.firstTabName;
                vm.schTxt = keyword;
                vm.paging.curPage = 1;
                $(window).scrollTop(0);
                vm.goSearchAjax();
            },
            goSearchAjax() {
                const vm = this;
                vm.loadingYn = "Y";
                ui.loading.open();

                const params = {
                    catCode1: vm.catCode1,
                    schTxt: vm.schTxt,
                    searchYn: vm.searchYn,
                    allClickYn: vm.allClickYn,
                    curPage: vm.paging.curPage,
                    rowCount: vm.paging.rowCount,
                    pageCount: vm.paging.pageCount,
                    totalCount: vm.paging.totalCount
                };

                this.$axios.post("/api/faq/retrieveFaqList.ajax",
                    qs.stringify(params)).then((result) => {
                    ui.loading.close();
                    vm.faqList = result.data.faqList;
                    vm.faqHighCateList = result.data.faqHighCateList;
                    vm.faqLowCateList = result.data.faqLowCateList;
                    vm.totCnt = result.data.totCnt;
                    vm.faqHashTagList = result.data.faqHashTagList;
                    vm.titleClickYn = "N";
                    vm.loadingYn = "N";

                    vm.setResult(result);
                    vm.resetPageList();
                    vm.$nextTick(function() {
                        ui.tab.init();
                        ui.faqAccordion.init();
                        $("#sSearchPage").blur();
                    });
                }).catch((err) => {
                    ui.loading.close();
                    vm.loadingYn = "N";
                    alert("error : " + err);
                });
            },
            goFirstPage() {
                if(this.paging.curMinPage > 1) {
                    this.paging.curPage = this.paging.curMinPage - 1;
				}
                this.goSearchAjax();
            },
            goPrevPage() {
                if(this.paging.curPage > 1) {
                    this.paging.curPage -= 1;
				}
                this.goSearchAjax();
            },
            goNextPage() {
                if(this.paging.curPage < this.paging.maxPage) {
                    this.paging.curPage += 1;
				}
                this.goSearchAjax();
            },
            goLastPage() {
                if(this.paging.curMaxPage < this.paging.maxPage) {
                    this.paging.curPage = this.paging.curMaxPage + 1;
				}
                this.goSearchAjax();
            },
            goPage(page) {
                this.paging.curPage = page;
                this.goSearchAjax();
            },
            setResult(result) {
                this.paging.totalCount = result.data.totalCount;
                this.paging.pageCount = result.data.pageCount;
                this.paging.curPage = result.data.curPage;
                this.paging.rowCount = result.data.rowCount;
            },
            resetPageList() {
                var maxPage = Math.floor(this.paging.totalCount / this.paging.rowCount);
                if(this.paging.totalCount % this.paging.rowCount != 0) {
                    maxPage += 1;
                }
                this.paging.maxPage = maxPage;

                this.paging.curMaxPage = Math.floor((this.paging.curPage - 1) / this.paging.pageCount) * this.paging.pageCount + this.paging.pageCount;
                this.paging.curMinPage = Math.floor((this.paging.curPage - 1) / this.paging.pageCount) * this.paging.pageCount + 1;

                this.paging.pageList = [];
                for(var i = this.paging.curMinPage; i <= this.paging.curMaxPage; ++i) {
                    if(maxPage < i) {
                        break;
                    }
                    this.paging.pageList.push({
                        num: i
                    });
                }

                if(maxPage <= this.paging.curMaxPage) {
                    this.paging.hasLast = false;
                } else {
                    this.paging.hasLast = true;
                }

                if(this.paging.curPage < maxPage) {
                    this.paging.hasNext = true;
                } else {
                    this.paging.hasNext = false;
                }

                if(this.paging.curPage != 1) {
                    this.paging.hasPrev = true;
                } else {
                    this.paging.hasPrev = false;
                }

                if(this.paging.curMinPage != 1) {
                    this.paging.hasFirst = true;
                } else {
                    this.paging.hasFirst = false;
                }
            },
            goRecommendKeywordAjax(keyword) {
                const vm = this;
                this.$axios.post("/api/common/retrieveRecommendKeyword.ajax").then((result) => {
                    vm.keywordList = result.data.keywordList;
                    if(keyword != "") {
                        vm.goKeywordSearch(keyword);
					}
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            readCntt(seqNo, index) {
                this.$store.state.faqSeqNo = seqNo;
                this.$store.state.satisfType = 'faq';

                const vm = this;

                if(vm.titleClickYn == "Y") {
                    if(vm.seqNo == seqNo) {
                        vm.titleClickYn = "N";
                        return;
					} else {
                        vm.seqNo = seqNo;
                        vm.updateViewCnt();
					}
				} else {
                    vm.seqNo = seqNo;
                    vm.titleClickYn = "Y";
                    vm.updateViewCnt();
				}
            },
            updateViewCnt() {
                const vm = this;

                if(vm.$store.state.countSeqNoList.includes(vm.seqNo)) {
                    return;
                }
                vm.$store.state.countSeqNoList.push(vm.seqNo);

                const params = {
                    seqNo: vm.seqNo
                };

                this.$axios.post("/api/faq/updateFaqViewCnt.ajax",
                    qs.stringify(params)).then((result) => {
					console.log("success");
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            goSatisf(clickType) {
                const vm = this;

                const params = {
                    clickType: clickType,
                    faqSeqNo: vm.seqNo
                };

                this.$axios.post("/api/faq/mergeFaqSatisf.ajax",
                    qs.stringify(params)).then((result) => {
                    alert(this.$t("sdp.Satisfaction.message.pop_text6"));
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            lineBreakCntt(cntt) {
                if(cntt != null && cntt != "") {
                    return cntt.split("\n").join("<br />");
                } else {
                    return "";
                }
			},
            afterLeave: function (el) {
                this.$nextTick(function(){
                    $('#ssearchPage').focus();
                });
            },
            deleteKeyword() {
                this.schTxt = '';
                $('#sSearchPage').focus();
            },
            isTabActive(catCode1) {
                if(this.catCode1 == catCode1) {
                    return true;
                } else {
                    return false;
                }
            },
			checkTextLength (event) {
                var strValue = event.target.value;
                var strLength = this.getStrByte(event.target.value);

                if (strLength > this.maxLength) {
                    strValue = this.strCutByByte(strValue, this.maxLength);
                    strLength = this.getStrByte(strValue);
                    this.schTxt = strValue;
                    return;
                }
            },
            strCutByByte (str, max) {
                var byteLength = 0;
                var result = "";

                for (var inx = 0; inx < str.length; inx++) {
                    var oneChar  = str.charAt(inx);
                    var charCode = oneChar.charCodeAt(0);
                    if(charCode)
                        if(charCode != 13){
                            if (charCode <= 0x00007F) {
                                byteLength ++;
                            }else if (charCode <= 0x0007FF) {
                                byteLength += 2;
                            }else if (charCode <= 0x00FFFF) {
                                byteLength += 3;
                            } else {
                                byteLength += 4;
                            }
                        }

                    if (byteLength > max) {
                        break;
                    }
                    result = result + str.charAt(inx);
                }

                return result;
            },
            getStrByte(value) {
                var byteLength = 0, ch;
                var charCode;
                var len = value.length;
                for(var i = 0; i < len; i++) {
                    ch = value.charAt(i);
                    charCode = ch.charCodeAt(0);
                    if(charCode)
                        if(charCode != 13){ // enter값이 2번 넘어온다.10,13 10번은 화면 test 시  나오지만 13번은 나오지 않아 13번을 막음.
                            if (charCode <= 0x00007F) {
                                byteLength ++;
                            }else if (charCode <= 0x0007FF) {
                                byteLength += 2;
                            }else if (charCode <= 0x00FFFF) {
                                byteLength += 3;
                            } else {
                                byteLength += 4;
                            }
                        }
                }
                return byteLength;
            }
        },
        computed: {
            firstTabName: function() {
                if(this.searchYn == "Y") {
                    return this.$t("sdp.mypage.message.tabbuyall");
                } else {
                    return this.$t("sdp.faq.message.tap_top");
                }
            }
        },
        mounted() {
            const vm = this;

            var clientWidth = document.documentElement.clientWidth;
            console.log('clientWidth ', clientWidth);

            var pageCount = 10;
            var rowCount = 10;
            if(clientWidth < 760) {
                rowCount = 3;
                pageCount = 3;
            }

            if (vm.$route.query.seqNo != null && vm.$route.query.seqNo != "") {
                // 1:1문의에서 들어왔는지 확인
                vm.inquiryYn = true;
            }
            if (vm.$route.query.catCode1 != null && vm.$route.query.catCode1 != "") {
                // 스토어에서 들어왔는지 확인
                vm.catCode1 = vm.$route.query.catCode1;
                vm.allClickYn = "N";
            }

            const params = {
                searchYn: vm.searchYn,
                allClickYn: vm.allClickYn,
                seqNo: vm.$route.query.seqNo,
                catCode1: vm.$route.query.catCode1,
                curPage: 1,
                rowCount: rowCount,
                pageCount: pageCount,
                totalCount: 0
            };

            if (vm.$route.query.hashTagYn != null && vm.$route.query.hashTagYn != "") {
                // 1:1 문의에서 해시태그 클릭 시
				vm.paging.rowCount = rowCount;
				vm.paging.pageCount = pageCount;
                vm.goRecommendKeywordAjax(vm.$route.query.schTxt);
            } else {
                ui.loading.open();

                this.$axios.post("/api/faq/retrieveFaqList.ajax",
                    qs.stringify(params)).then((result) => {
                    ui.loading.close();
                    vm.faqList = result.data.faqList;
                    vm.faqHighCateList = result.data.faqHighCateList;
                    vm.faqLowCateList = result.data.faqLowCateList;
                    vm.totCnt = result.data.totCnt;
                    vm.faqHashTagList = result.data.faqHashTagList;
                    vm.loadingYn = "N";

                    if (vm.inquiryYn) {
                        vm.searchYn = "Y";
                        vm.seqNo = vm.$route.query.seqNo;
                        vm.$store.state.faqSeqNo = vm.$route.query.seqNo;
                    }

					vm.tabPanelName = vm.firstTabName;

                    vm.setResult(result);
                    vm.resetPageList();

                    vm.$nextTick(function() {
                        ui.init();
                        if (vm.inquiryYn) {
                            // 1:1문의에서 넘어온 경우 첫번째 Content toggle open
                            ui.faqAccordion.action('faqContent1');
                        }
                    });
                }).catch((err) => {
                    ui.loading.close();
                    vm.loadingYn = "N";
                    alert("error : " + err);
                });

                vm.goRecommendKeywordAjax("");
			}
        }
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
