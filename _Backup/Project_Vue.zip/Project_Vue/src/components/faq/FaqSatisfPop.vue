<template>
	<!-- 팝업_만족도조사 -->
	<div id="popupFaqQuestion" class="popup-wrap" hidden>
		<div class="popup popup-type1 popup-question" role="dialog" aria-labelledby="popupFaqQuestionTitle">
			<div class="blind-area popup-focus dv-ios-only" role="text" :aria-label="$t('gwa.alt.common.wa_label_60')"><!-- IOS접근성 영역자체에 초점처리 --></div>
			<div class="popup-container">
				<div class="popup-header">
					<h3 class="tit-h3" id="popupFaqQuestionTitle">{{ $t('sdp.Satisfaction.message.pop_title') }}</h3>
				</div>
				<div class="popup-header">
				</div>
				<div class="popup-body popup-scroll">
					<ul class="bul bul-dot bul-primary">
						<li class="color-primary" v-html="$t('sdp.Satisfaction.message1')">
						</li>
					</ul>
					<div class="question-content">
						<ol class="form-radio-vertical aria-radio-wrap">
							<li>
                                <span class="form-radio aria-radio">
                                    <input type="radio" v-model="satisf.rsnType" name="sQuseItem1" id="sQuseItem11" value="RSN1" checked />
                                    <label for="sQuseItem11"><span>{{ $t('sdp.Satisfaction.message.pop_text1') }}</span></label>
                                </span>
							</li>
							<li>
                                <span class="form-radio aria-radio">
                                    <input type="radio" v-model="satisf.rsnType" name="sQuseItem1" id="sQuseItem12" value="RSN2" />
                                    <label for="sQuseItem12"><span>{{ $t('sdp.Satisfaction.message.pop_text2') }}</span></label>
                                </span>
							</li>
							<li>
                                <span class="form-radio aria-radio">
                                    <input type="radio" v-model="satisf.rsnType" name="sQuseItem1" id="sQuseItem13" value="RSN3" />
                                    <label for="sQuseItem13"><span v-html="$t('sdp.Satisfaction.message.pop_text3')"></span></label>
                                </span>
							</li>
							<li>
                                <span class="form-radio aria-radio">
                                    <input type="radio" v-model="satisf.rsnType" name="sQuseItem1" id="sQuseItem14" value="ETC" />
                                    <label for="sQuseItem14"><span>{{ $t('sdp.Satisfaction.message.pop_text4') }}</span></label>
                                </span>
								<div class="form-textarea-wrap">
									<textarea type="text" v-model="satisf.etcCntt" name="sTextEtc" id="sTextEtc" rows="2" cols="30" :placeholder="$t('sdp.Satisfaction.message.pop_text5')" :title="$t('gwa.alt.inquiry.wa_title_5')" value="" class="form-textarea" :disabled="isCnttDisabled"></textarea>
									<div class="bul bul-star">
										<p>{{ $t('sdp.Satisfaction.message2') }}</p>
									</div>
								</div>
							</li>
						</ol>
					</div>
				</div>
				<div class="popup-footer">
					<div class="btn-wrap">
						<button type="button" class="btn btn-type2 btn-primary popup-close" :aria-controls="isValid" :title="$t('gwa.alt.common.wa_label_39')" @click="typeCheck('N')"><span>{{ $t('sdp.Satisfaction.message.pop_btn1') }}</span></button>
						<button type="button" class="btn btn-type2 btn-secondary popup-close" aria-controls="popupFaqQuestion" :title="$t('gwa.alt.common.wa_label_40')" @click="typeCheck('C')"><span>{{ $t('sdp.support.message.cancel') }}</span></button>
					</div>
				</div>
				<button type="button" class="btn-ico btn-popup-close popup-close" aria-controls="popupFaqQuestion" :title="$t('gwa.alt.common.wa_title_49')" @click="resetRsnType()"><span><i class="ico ico-close2">{{ $t('gwa.alt.common.wa_label_19') }}</i></span></button>
			</div>
		</div>
	</div>
	<!-- //팝업_만족도조사 -->
</template>

<script>
    import qs from "qs";

    export default {
        name: "FaqStatifPop",
        data() {
            return {
                satisf: {
                    clickType: "",
                    rsnType: "RSN1",
                    etcCntt: ""
                },
				seqNo : 0
            }
        },
        created() {
        },
        watch: {
        },
        computed: {
            isCnttDisabled: function() {
                if(this.satisf.rsnType == "ETC") {
                    return false;
                } else {
                    return true;
                }
            },
			isValid: function() {
                if(this.satisf.rsnType == 'ETC' && this.satisf.etcCntt == '') {
                    return "";
				} else {
                    return "popupFaqQuestion";
				}
			}
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            typeCheck(clickType) {
              if (this.$store.state.satisfType == 'diag') {
                  this.goSatisfDiag(clickType);
			  } else {
                  this.goSatisfFaq(clickType);
			  }
			},
            goSatisfFaq(clickType) {
                const vm = this;
                vm.satisf.clickType = clickType;

                if(vm.satisf.clickType == 'N' && vm.satisf.rsnType == 'ETC' && vm.satisf.etcCntt == '') {
                    alert(this.$t("sdp.warn.com.input", { var1 : this.$t("sdp.support.message.content") }));
                    return;
                }

                const params = {
                    clickType: vm.satisf.clickType,
                    rsnType: vm.satisf.rsnType,
                    cntt: vm.satisf.etcCntt,
                    faqSeqNo: this.$store.state.faqSeqNo
                };

                this.$axios.post("/api/faq/mergeFaqSatisf.ajax",
                    qs.stringify(params)).then((result) => {
					vm.resetRsnType();
                    if(result.data.clickType != 'C') {
                        alert(this.$t("sdp.Satisfaction.message.pop_text6"));
                    }
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
            goSatisfDiag(clickType) {
                const vm = this;
                vm.satisf.clickType = clickType;

                if(vm.satisf.clickType == 'N' && vm.satisf.rsnType == 'ETC' && vm.satisf.etcCntt == '') {
                    alert(this.$t("sdp.warn.com.input", { var1 : this.$t("sdp.support.message.content") }));
                    return;
                }

                const params = {
                    clickType: vm.satisf.clickType,
                    rsnType: vm.satisf.rsnType,
                    cntt: vm.satisf.etcCntt,
                    diagSeqNo: this.$store.state.faqSeqNo
                };

                this.$axios.post("/api/diag/mergeDiagSatisf.ajax",
                    qs.stringify(params)).then((result) => {
                    vm.resetRsnType();
                    if(result.data.clickType != 'C') {
                        alert(this.$t("sdp.Satisfaction.message.pop_text6"));
                    }
                }).catch((err) => {
                    alert("error : " + err);
                });
            },
			resetRsnType() {
                this.satisf.rsnType = "RSN1";
                this.satisf.etcCntt = "";
			}
        },
        mounted() {
            this.seqNo = this.$store.state.faqSeqNo;
        }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
