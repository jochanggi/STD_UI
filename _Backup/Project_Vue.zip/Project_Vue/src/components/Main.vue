<template>
<div id="wrapper">
    <!-- SkipNav -->
    <div id="skipNav">
        <ul>
            <li><a href="#content" >본문 바로가기</a></li>
        </ul>
    </div>
    <!-- //SkipNav -->

    <!-- Header -->
    <Header ref="header"></Header>
    <!-- //Header -->

    <!-- 전체검색 -->
    <IntegratedSearch></IntegratedSearch>
    <!-- //전체검색 -->

    <hr />
    <!-- Container -->
    <div id="container" class="out-sec">
        <router-view />
    </div>
    <!-- //Container -->
    <hr />

    <!-- 챗봇 -->
    <aside class="float-wrap">
        <div id="chatbot" class="float-chatbot" v-show="cntryCode == 'KR' || cntryCode == 'US'">
            <button type="button" class="btn-ico" @click="goChatbot()" :title="$t('gwa.alt.common.wa_title_4')"><span><i class="ico ico-chatbot">Chatbot</i></span></button>
        </div>
        <div class="float-pageUp">
            <button type="button" class="btn" :title="$t('gwa.alt.common.wa_title_60')"><span><i class="arw arw-up"></i><em>Top</em></span></button>
        </div>
    </aside>
    <!-- //챗봇 -->

    <!-- Footer -->
    <Footer></Footer>
    <!-- //Footer -->

    <div id="pageLoading" class="loadingDim-wrap">
        <div class="loading"><img src="/img/cmn/loading.png" alt="로딩중"></div>
    </div>
</div>
</template>

<script>

    import qs from "qs";

    import Header from '@/components/nav/Header';
    import Footer from '@/components/nav/Footer';
    import IntegratedSearch from '@/components/integratedsearch/IntegratedSearch';

	export default {
		name: "App",
		components: {
            Header,
            Footer,
            IntegratedSearch
		},
		data() {
			return {
                isLogin: false,
                cntryCode : ""
			}
        },
			computed: {

			},
			watch: {
				'$route': 'changeRoute'
			},
			mounted() {
				console.log('App.vue mounted..');

				var firstName = this.getCookie('firstName');
				var lastName = this.getCookie('lastName');
				if(firstName == null || lastName == null) {
					this.isLogin = false;
				} else {
					this.isLogin = true;
				}

                this.cntryCode = _domainCntryCode;

			},
		methods : {
			changeRoute(to, from) {
				console.log('Main.vue', 'changeRoute', to, from);
                console.log(this.$refs.header.changeMenu(to));
                
                // ui.searchAll.close('searchAll'); // 검색바 닫힘
			},
            logout() {
                const vm = this;
                this.$axios.get('/api/main/logout.ajax').then((result) => {
                    console.log('document.cookie', document.cookie);
                    this.isLogin = false;
                })
            },
		    goChatbot() {
			    const params = {
			        cntryCode: this.cntryCode.toLowerCase()
                };

                this.$axios.post('/api/main/retrieveChatBotUrl.ajax', qs.stringify(params)).then((result) => {
                    var newWindow = window.open(result.data.url, "_blank", 'left=0, top=0, width=360, height=620, resizable=yes');
                    newWindow.location.href = result.data.url;
                });
            },
            goLgaccount() {
                var params = {
                    cntryCode: _domainCntryCode,
                    path: ''
                }
                this.$axios.post('/api/main/retrieveLoginInfo.ajax', qs.stringify(params)).then((result) => {
                    var loginUrl = result.data.loginUrl;
                    window.location = loginUrl;
                }).catch((err) => {
                    alert(err);
                });
            },
		    retrieveFamilySite(event) {
                  if (event.target.value == "smartWorld") {
                      window.location.href = "http://www.lgworld.com/web.gateway.dev";
                  } else if (event.target.value == "sellerLounge") {
                      window.location.href = "http://seller.lgappstv.com/seller/main/Main.lge";
                  } else if (event.target.value == "developer") {
                      window.location.href = "http://webostv.developer.lge.com/";
                  }
		    },
            getCookie(cname) {
                var name = cname + "=";
                var decodedCookie = decodeURIComponent(document.cookie);
                var ca = decodedCookie.split(';');
                for(var i = 0; i <ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == ' ') {
                        c = c.substring(1);
                    }
                    if (c.indexOf(name) == 0) {
                        var str = c.substring(name.length, c.length);
                        if(str === null || str === '') {
                            return null;
                        } else {
                            return str;
                        }
                    }
                }
                return null;
            }
		}
	};
</script>

<style>
</style>
