<template>
   <!-- Footer -->
		<footer id="footer" class="out-sec">
			<div class="in-sec">
				<!-- Footer Nav -->
				<div class="fnb-wrap">
					<ul class="fnb">
						<li><router-link to="/main/terms"><span role="text" v-html="$t('sdp.menu.device.terms_condition')"></span></router-link></li>
						<li><a @click="goLgTerms('SVC')" href="javascript:;" v-html="$t('sdp.menu.terms_condition')"></a></li>
						<li><a @click="goLgTerms('PRV')" href="javascript:;" v-html="$t('sdp.menu.privacy')"></a></li>
					</ul>
				</div>
				<!-- //Footer Nav -->

				<!-- Information -->
				<div class="info-wrap" v-html="$t('sdp.menu.footer.copyright')">
				</div>
				<!-- <div class="info-wrap" v-html="copyrightCheck">
				</div> -->
				<!-- //Information -->

				<!-- FamilySite -->
				<!-- 고도화 ver2 : 속성 title="새창" 추가 -->
				<div class="familySite-wrap">
					<div class="dropdown-wrap dropdown-familySite">
						<a href="#familySiteDrop" class="dropdown-toggle" role="button" aria-controls="familySiteDrop" aria-expanted="false"><span>FAMILYSITE <i class="arw arw-toggle2 centered-r"></i></span></a>
						<div id="familySiteDrop" class="dropdown">
							<span class="blind-area dropdown-focus" role="text" aria-labeledby="familySiteOpen"></span>
							<ul class="dropdown-menu">
								<li><a href="http://www.lg.com/common/index.jsp" class="dropdown-item" target="_blank" :title="$t('gwa.alt.common.wa_title_4')" v-html="$t('sdp.main.main.website')"></a></li>
								<li><a href="http://seller.lgappstv.com/seller/main/Main.lge" class="dropdown-item" target="_blank" :title="$t('gwa.alt.common.wa_title_4')">{{ $t('sdp.menu.seller_guide') }}</a></li>
								<li><a href="http://webostv.developer.lge.com" class="dropdown-item" target="_blank" :title="$t('gwa.alt.common.wa_title_4')">{{ $t('sdp.menu.developer_guide') }}</a></li>
							</ul>
						</div>
					</div>
				</div>
				<!-- //FamilySite -->

				<!-- WA Mark -->
				<!--<div v-show="langCode == 'kor'" class="mark-wrap">
					<a href="https://www.msit.go.kr/" title="새창열림" target="_blank"><img src="/img/cmn/ico_waMark.png" alt="과학기술정보통신부 WA(WEB ACCESSIBLITY) Mark" /></a>
				</div>-->
				<!-- //WA Mark -->
			</div>
		</footer>
	<!-- //Footer -->
</template>

<script>

    import qs from "qs";

    export default {
      name: "Footer",
      data() {
        return {
            isLogin: false,
			langCode: _domainLangCode,
			cntryCode: _domainCntryCode
        }
      },
      created() {
      },
      watch: {
      },
      computed: {
          copyrightCheck() {
			  var copyRight = this.$t('sdp.menu.footer.copyright.'+ _domainCntryCode);
			  console.log("copyRight", copyRight);
			  if (copyRight == 'sdp.menu.footer.copyright.'+ _domainCntryCode) {
				  return this.$t('sdp.menu.footer.copyright');
			  } else {
			      return copyRight;
			  }
		  }
      },
      mounted() {
      },
      methods: {
          goLgTerms(type) {
              var params = {
                  cntryCode: _domainCntryCode,
				  langCode: _domainLangCode,
				  termsType: type
              };

              this.$axios.post('/api/terms/retrieveTermsUrl.ajax', qs.stringify(params)).then((result) => {
                  this.openTermsUrl(result.data.termsUrl);
              }).catch((err) => {
                  alert(err);
              });
          },
		  openTermsUrl(termsUrl) {
              window.open(termsUrl, "_blank");
		  }
      }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
