<template>
   <!-- Header -->
		<header id="header" :class="isLogined == false ? 'out-sec is-loginBefore' : 'out-sec is-loginAfter'">
			<div class="in-sec">
				<!-- 전체메뉴 -->
				<div class="aside-open-wrap">
					<button type="button" class="aside-open" aria-controls="asideWrap" aria-haspopup="true" aria-extended="false"><span>{{ $t('gwa.alt.header.wa_alt_1') }}</span></button>
				</div>
                <!-- //전체메뉴 -->

                <!-- 로고 -->
				<div class="logo-wrap">
					<h1 class="logo"><router-link to="/main" :title="$t('gwa.alt.header.wa_title_1')"><span role="text">{{ $t('gwa.alt.header.wa_alt_2') }}</span></router-link></h1>
				</div>
                <!-- //로고 -->
			
				<!-- GNB -->
				<div class="gnb-wrap">
					<!-- 로그인메세지 -->
					<div class="userMsg-wrap login-after" v-show="isLogined">
						<p v-html="$t('sdp.message.wellcome', {var1: userEmail})"></p>
					</div>
					<!-- //로그인메세지 -->

					<!-- 로그인메뉴 -->
					<div class="account-wrap">
						<!-- 로그인전 -->
						<div class="login-before">
							<div class="item">
								<a href="#" class="link-account" @click="goLgaccount()" :aria-label="$t('gwa.alt.header.wa_alt_3')"><i class="ico ico-user centered-l"></i>{{ $t('sdp.menu.gnb.lgaccount') }}</a>
							</div>
						</div>
						<!-- //로그인전 -->
						<!-- 로그인후 -->
						<div class="login-after">
							<div class="item">
								<div class="dropdown-wrap dropdown-mypage">
									<a href="#dropdownMypage" class="dropdown-toggle" role="button" aria-controls="dropdownMypage" aria-expanded="false"><span class="dropdown-label"><i class="ico ico-user centered-l"></i>{{ $t('sdp.menu.my_page') }}</span> <i class="arw arw-toggle5 centered-r"></i></a>
									<div id="dropdownMypage" class="dropdown">
										<i class="arw arw-dropup"></i>
										<div class="blind-area" role="text" :aria-label="$t('gwa.alt.header.wa_alt_4')"></div>
										<ul class="dropdown-menu">
											<li><a href="javascript:;" @click="retrieveMemberInfoManagement()" class="dropdown-item"><i class="ico ico ico-mypage1"></i>{{ $t('sdp.menu.gnb.mypage_member') }}</a></li>
											<li><a href="javascript:;" @click="retrieveMemberInquiryInfo()" class="dropdown-item"><i class="ico ico ico-mypage2"></i>{{ $t('sdp.menu.gnb.mypage_inpuiry') }}</a></li>
										</ul>
									</div>
								</div>
							</div>
							<div class="item">
								<a href="javascript:;" class="link-logout" @click="logout()"><i class="ico ico-logout2 centered-l"></i>{{ $t('sdp.menu.logout') }}</a>
							</div>
						</div>
						<!-- //로그인후 -->
					</div>
					<!-- //로그인메뉴 -->

					<!-- 글로벌메뉴 -->
					<div class="global-wrap">
						<ul class="global">
							<li><button type="type" class="link-national" @click="loginCheck()"><i class="ico ico-location"></i> {{ $t('sdp.menu.gnb.country') }}</button></li>
							<li>
								<div class="dropdown-wrap dropdown-language" :class="isSelected">
									<a href="#dropdownLang" class="dropdown-toggle link-language" role="button" aria-controls="dropdownLang" aria-expanded="false"><span class="dropdown-label">{{ curLangName }}</span> <i class="arw arw-toggle3 centered-r"></i></a>
									<div id="dropdownLang" class="dropdown">
										<div class="blind-area" role="text" :aria-label="$t('gwa.alt.header.wa_alt_5')"></div>
										<ul class="dropdown-menu">
											<li v-for="cntry in cntryList">
												<a @click="changeLang(cntry.langCode, cntry.cntryName, cntry.dpCntryLangName)" href="javascript:;" class="dropdown-item">{{ cntry.cntryName }}/{{ cntry.dpCntryLangName }}</a>
											</li>
										</ul>
									</div>
								</div>
							</li>
						</ul>
					</div>
					<!-- //글로벌메뉴 -->
				</div>
				<!-- //GNB -->

                <!-- PC메뉴 -->
				<div class="lnb-wrap">
					<nav class="lnb">
						<ul>
							<li :class="navName == 'tvapp' ? 'is-current' : ''"><router-link @click.native="clickNav('tvapp')" to="/main/tvapp" class="node-link" :aria-current="navName == 'tvapp' ? 'page' : 'false'">{{ $t('sdp.menu.gnb.tvapp') }}</router-link></li>
							<li :class="navName == 'faq' ? 'is-current' : ''"><router-link @click.native="clickNav('faq')" to="/main/faq" class="node-link" :aria-current="navName == 'faq' ? 'page' : 'false'">{{ $t('sdp.menu.faq') }}</router-link></li>
							<li :class="navName == 'diag' ? 'is-current' : ''"><router-link @click.native="clickNav('diag')" to="/main/diag" class="node-link" :aria-current="navName == 'diag' ? 'page' : 'false'">{{ $t('sdp.menu.gnb.self') }}</router-link></li>
							<li :class="navName == 'inquiry' ? 'is-current' : ''"><router-link @click.native="clickNav('inquiry')" to="/main/inquiry" class="node-link" :aria-current="navName == 'inquiry' ? 'page' : 'false'">{{ $t('sdp.menu.qna') }}</router-link></li>
							<li :class="navName == 'notice' ? 'is-current' : ''"><router-link @click.native="clickNav('notice')" to="/main/notice" class="node-link" :aria-current="navName == 'notice' ? 'page' : 'false'">{{ $t('sdp.menu.notice') }}</router-link></li>
						</ul>
					</nav>
				</div>
                <!-- //PC메뉴 -->

                <!-- 모바일메뉴 -->
				<aside id="asideWrap" class="aside-wrap"><!-- 로그인상태 클래스 : is-loginAfter, is-loginBefore --><!--  :class="isLogined ? 'aside-wrap is-loginAfter' : 'aside-wrap is-loginBefore'" -->
					<div class="blind-area aside-focus" role="text" :aria-label="$t('gwa.alt.common.wa_label_43')"></div>
						<div class="aside-inner">
						<div class="aside-header">
							<div class="inner">
								<!-- 로그인전 -->
								<div class="login-before">
									<div class="aside-user">
										<button @click="goLgaccount()" type="button" class="btn btn-user" :aria-label="$t('gwa.alt.header.wa_alt_3')"><span><i class="ico ico-user2"></i>{{ $t('sdp.menu.gnb.lgaccount') }}<i class="arw arw-next"></i></span></button>
									</div>
								</div>
								<!-- //로그인전 -->
								<!-- 로그인후 -->
								<div class="login-after">
									<div class="aside-user">
										<i class="ico ico-user2 centered-l" aria-hidden="true"></i>
										<!-- <p class="user-name"><strong>{{ $t('sdp.support.message.qnamail3', {'var1': userName}) }}</strong></p> -->
										<p class="user-email">{{ userEmail }}</p>
									</div>
								</div>
								<!-- //로그인후 -->
							</div>
							<div class="aside-util login-after">
								<div class="btn-group">
									<span class="col"><button type="button" class="btn" @click="retrieveMemberInfoManagement()" ><span>{{ $t('sdp.menu.gnb.mypage_member') }}</span></button></span>
									<span class="col"><button type="button" class="btn" @click="retrieveMemberInquiryInfo()" ><span>{{ $t('sdp.menu.gnb.mypage_inpuiry') }}</span></button></span>
								</div>
							</div>
						</div>
						<div class="aside-body">
							<!-- 국가, 언어선택 -->
							<div class="aside-lang">
								<button type="button" @click="loginCheck()" class="link-national"><i class="ico ico-location"></i> {{ $t('sdp.menu.gnb.country') }}</button>
								<div v-show="cntryList.length > 1" class="dropdown-wrap dropdown-language" :class="isSelected">
									<a href="#dropdownLang2" class="dropdown-toggle" role="button" aria-controls="dropdownLang2" aria-expanded="false"><span class="dropdown-label">{{ curLangName }}</span> <i class="arw arw-toggle5 centered-r"></i></a>
									<div id="dropdownLang2" class="dropdown">
										<div class="blind-area" role="text" :aria-label="$t('gwa.alt.header.wa_alt_5')"></div>
										<ul class="dropdown-menu">
											<li v-for="cntry in cntryList">
												<a @click="changeLang(cntry.langCode, cntry.cntryName, cntry.dpCntryLangName)" href="javascript:;" class="dropdown-item">{{ cntry.cntryName }}/{{ cntry.dpCntryLangName }}</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
							<!-- //국가, 언어선택 -->

							<!-- 메뉴영역 -->
							<nav class="mnb">
								<ul>
									<li :class="navName == 'tvapp' ? 'is-current' : ''"><router-link to="/main/tvapp" class="node-link">{{ $t('sdp.menu.gnb.tvapp') }}</router-link></li>
									<li :class="navName == 'faq' ? 'is-current' : ''"><router-link to="/main/faq" class="node-link">{{ $t('sdp.menu.faq') }}</router-link></li>
									<li :class="navName == 'diag' ? 'is-current' : ''"><router-link to="/main/diag" class="node-link">{{ $t('sdp.menu.gnb.self') }}</router-link></li>
									<li :class="navName == 'inquiry' ? 'is-current' : ''"><router-link to="/main/inquiry" class="node-link">{{ $t('sdp.menu.qna') }}</router-link></li>
									<li :class="navName == 'notice' ? 'is-current' : ''"><router-link to="/main/notice" class="node-link" aria-current="page">{{ $t('sdp.menu.notice') }}</router-link></li>
								</ul>
							</nav>
							<!-- //메뉴영역 -->

							<!-- 계정설정 -->
							<div class="aside-mypage login-after">
								<div class="btn-group">
									<span class="col"><button type="button" class="btn" @click="logout()"><span><i class="ico ico-logout"></i>{{ $t('sdp.menu.logout') }}</span></button></span>
									<!-- <span class="col"><button type="button" class="btn"><span><i class="ico ico-user3"></i>{{ $t('sdp.menu.my_page') }}</span></button></span> -->
								</div>
							</div>
							<!-- //계정설정 -->

						</div>
						<button type="button" class="btn-ico btn-close aside-close" aria-extended="true"><span><i class="ico ico-close3">{{ $t('gwa.alt.common.wa_label_45') }}</i></span></button>
					</div>
				</aside>
                <!-- //모바일메뉴 -->

				<!-- 전체검색 -->
				<div class="search-header">
					<div class="search-combine">
						<a href="#searchAll" class="btn-ico search-open" role="button" aria-controls="searchAll" aria-haspopup="true" aria-expanded="false"><span><i class="ico ico-search1">{{ $t('gwa.alt.common.wa_label_46') }}</i></span></a>
						<a href="#searchAll" class="btn-ico search-close" tabindex="-1" role="button" aria-controls="searchAll" aria-expanded="true" aria-hidden="true"><span><i class="ico ico-close1">{{ $t('gwa.alt.common.wa_label_47') }}</i></span></a>
					</div>
				</div>
				<!-- //전체검색 -->
			</div>
		</header>
    <!-- //Header -->
</template>

<script>

	import qs from "qs";

    export default {
      name: "Header",
      data() {
        return {
			isLogined: false,
			userName: '',
			userEmail: '',
            cntryList: [],
			curLangName: '',
			currentMenu: '',
			cntryCode: _domainCntryCode
        }
      },
      created() {
      },
      watch: {
      },
      computed: {
		  navName: function() {
			  console.log('@@@@ navName:', this.currentMenu);
			  if(this.currentMenu.indexOf('home') == 0) {
				  return '';
			  } else if(this.currentMenu.indexOf('terms') == 0) {
				  return '';
			  } else if(this.currentMenu.indexOf('integrated') == 0) {
				  return '';
			  } else if(this.currentMenu.indexOf('notice') == 0) {
				  	return 'notice';
			  } else if(this.currentMenu.indexOf('faq') == 0) {
					return 'faq';
			  } else if(this.currentMenu.indexOf('diag') ==  0) {
					return 'diag';
			  } else if(this.currentMenu.indexOf('inquiry') == 0) {
					return 'inquiry';
			  } else if(this.currentMenu.indexOf('tvapp') == 0) {
					return 'tvapp';
			  } else {
			  		return this.currentMenu;
			  }
		  },
		  isSelected: function() {
		      if(this.cntryList.length > 1) {
		          return "is-selected";
			  } else {
		          return "";
			  }
		  }
      },
      mounted() {
        console.log('Header.vue mounted..');

		const vm = this;
		
		// console.log('@@@@ ' + this.$router.currentRoute.name);

        this.$axios.post("/api/main/retrieveHeaderInfo.ajax").then((result) => {
            vm.isLogined = result.data.isLogined;
            vm.userName = result.data.userName;
            vm.userEmail = result.data.userEmail;
            vm.cntryList = result.data.cntryList;
            vm.curLangName = result.data.curLangName;
            vm.$nextTick(function() {
                ui.languageSel.init();
                this.changeMenuByName(this.$router.currentRoute.name);
			});
		});

        /*var firstName = this.getCookie('firstName');
		var lastName = this.getCookie('lastName');
		var email = this.getCookie('email');
        if(firstName == null || lastName == null) {
            this.isLogined = false;
        } else {
            this.isLogined = true;
		}
		
		this.userName = lastName + firstName;
		this.userEmail = email;*/

        // isLogined() {
        // 	var firstName = this.getCookie('firstName');
        // 	var lastName = this.getCookie('lastName');
        // 	if(firstName == null || lastName == null) {
        // 		return false;
        // 	}
        // 	return true;
        // }

	  },
      methods: {
		  clickNav(menu) {
			  console.log('clickNav', menu);
              this.changeMenuByName(menu);
              const r = { path : "/main/" + menu };
              this.$router.push(r);
		  },
		  changeMenu(menu) {
			  this.changeMenuByName(menu.name);
		  },
		  changeMenuByName(name) {
			  console.log('changeMenuByName', name);
			  
			if(name.indexOf('home') == 0
			|| name.indexOf('terms') == 0
			|| name.indexOf('notice') == 0
			|| name.indexOf('faq') == 0
			|| name.indexOf('diag') == 0
			|| name.indexOf('inquiry') == 0
			|| name.indexOf('tvapp') == 0
			|| name.indexOf('integrated') == 0)
			{
				this.currentMenu = name;
			}
		  },
          changeLang(langCode, cntryName, dpCntryLangName) {
		      const vm = this;

              vm.$i18n.locale = langCode;
              vm.curLangName = cntryName + "/" + dpCntryLangName;

              const params = {
                  langCode: langCode
			  };

              this.$axios.post('/api/common/changeLanguage.ajax',
				  qs.stringify(params)).then((result) => {
                  vm.$nextTick(function() {
                      var url = window.location.protocol + '//' + window.location.host + "/main";
                      window.location = url + '?lang=' + langCode +"_" + _domainCntryCode;
                  });
              }).catch((err) => {
                  alert(err);
              });
          },
		logout() {
			const vm = this;
			this.$axios.get('/api/main/logout.ajax').then((result) => {
				console.log('document.cookie', document.cookie);
				this.isLogined = false;

                const r = { path : "/main" };
                this.$router.push(r);
			})
		},
		goLgaccount() {
			console.log('goLgaccount');

			var params = {
				cntryCode: _domainCntryCode,
				path: ''
			}
			
			this.$axios.post('/api/main/retrieveLoginInfo.ajax', qs.stringify(params)).then((result) => {
				var loginUrl = result.data.loginUrl;
				window.location = loginUrl;
			}).catch((err) => {
				alert(err);
			});
		},
        loginCheck() {
            var check = false;

            if(this.isLogined == false) {
                check = true;
            } else {
                if(confirm(this.$t("sdp.footer.message.changecountry"))) {
                    check = true;
                }
            }

            if(check) {
                this.goNation();
            }
        },
        goNation() {
            const r = { path : "/nation" };
            this.$router.push(r);
        },
        getCookie(cname) {
			var name = cname + "=";
			var decodedCookie = decodeURIComponent(document.cookie);
			var ca = decodedCookie.split(';');
			for(var i = 0; i <ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0) == ' ') {
					c = c.substring(1);
				}
				if (c.indexOf(name) == 0) {
					var str = c.substring(name.length, c.length);
					if(str === null || str === '') {
						return null;
					} else {
						return str;
					}
				}
			}
			return null;
		},
	    retrieveMemberInfoManagement() {
            this.$axios.post('/api/main/retrieveMemberInfoManagement.ajax').then((result) => {
                var myPageUrl = result.data.myPageUrl;
                window.location = myPageUrl;
            }).catch((err) => {
                alert(err);
            });
	    },
	    retrieveMemberInquiryInfo () {
            const r = { path : "/main/inquiry/list" };
            this.$router.push(r);
	    }
      }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
