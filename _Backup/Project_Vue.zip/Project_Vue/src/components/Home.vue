<template>
	<section id="content" class="content main-cont" role="main">
		<!-- Main ContentsHeader -->
		<div class="content-header">
			<!-- 메인비주얼 -->
			<div class="main-visual-wrap">
				<div class="swiper-wrap">
					<div class="swiper-mainVisual swiper-container">
						<div class="swiper-controller">
							<div class="swiper-autoplay">
								<button type="button" class="btn-ico btn-play"><span><i class="ico ico-play-visual">{{ $t('gwa.alt.common.wa_label_2') }}</i></span></button>
								<button type="button" class="btn-ico btn-pause" aria-hidden="true" tabindex="-1"><span><i class="ico ico-pause-visual">{{ $t('gwa.alt.common.wa_label_3') }}</i></span></button>
							</div>
							<div class="swiper-pagination"></div>
						</div>
						<div class="swiper-wrapper">
							<!-- 테스트 하드코딩 -->
							<!-- 사용자정의 프로모션 -->
							<div class="swiper-slide swiper-custom" role="img" aria-label="Make the most of your smart life with LG Content Store">
								<div class="bg-area" aria-hidden="true"></div>
								<div class="in-sec" aria-hidden="true">
									<div class="title-area">
										<p class="explain">Make the most of your smart life</p>
										<p class="title" role="text">With <em>LG Content Store</em></p>
									</div>
									<!-- TV 영역 -->
									<div class="tv-area" aria-hidden="false">
										<div class="btm"></div><!-- TV 받침 -->
										<div class="monitor"><img src="/img/cnt/main_visual_1_monitor.png" alt="" /></div><!-- TV 모니터 -->
										<div class="ch1"><img src="/img/cnt/main_visual_1_ch1.png" alt="" /></div><!-- TV 모니터 채널1 -->
										<div class="ch2"><img src="/img/cnt/main_visual_1_ch2.png" alt="" /></div><!-- TV 모니터 채널2 -->
										<div class="ch3"><img src="/img/cnt/main_visual_1_ch3.png" alt="" /></div><!-- TV 모니터 채널3 -->
										<div class="shadow"></div><!-- TV 그림자 -->
									</div>
								</div>
							</div>
							<a href="javascript:;" class="swiper-slide" v-for="banner in bannerList" target="_blank" :title="$t('gwa.alt.common.wa_title_4')" @click="bannerClick(banner.lnkUrl);">
								<!--<div class="swiper-slide-item" v-if="banner.posi == null || banner.posi == ''" role="image" :style="'background-image:url('+banner.imgFile+'); background-position:right center;'" aria-label="Make the most of your smart life with LG Content Store" @click="bannerClick(banner.lnkUrl);"></div>-->
								<div class="swiper-slide-item" :style="'background-image:url('+banner.imgFile+'); background-position:'+ banner.posi +' center;'" role="text">LG Content Store Promotion</div>
							</a>
							<!--<div class="swiper-slide" v-for="banner in bannerList" ><div class="swiper-slide-item" role="image" :style="'background-image:url('+banner.imgFile+'); background-position:20% center;'" aria-label="Make the most of your smart life with LG Content Store"></div></div>-->
							<!-- //사용자정의 프로모션 -->
							<!-- 관리자등록 프로모션 -->
							<!--<div class="swiper-slide"><div class="swiper-slide-item" role="image" style="background-image:url(/upload/@main_visual_2.png)" aria-label="Make the most of your smart life with LG Content Store"></div></div>-->
							<!--<div class="swiper-slide" v-for="banner in bannerList" :style=" 'background-image:url('+banner.imgFile+')'" role="image" aria-label="Make the most of your smart life with LG Content Store"></div>-->
							<!--<div class="swiper-slide"><div class="swiper-slide-item" role="image" style="background-image:url(/upload/@main_visual_3.png)" aria-label="Make the most of your smart life with LG Content Store"></div></div>
							<div class="swiper-slide"><div class="swiper-slide-item" role="image" style="background-image:url(/upload/@main_visual_2.png)" aria-label="Make the most of your smart life with LG Content Store"></div></div>
							<div class="swiper-slide"><div class="swiper-slide-item" role="image" style="background-image:url(/upload/@main_visual_3.png)" aria-label="Make the most of your smart life with LG Content Store"></div></div>-->
							<!-- //관리자등록 프로모션 -->
							<!-- //테스트 하드코딩 -->
						</div>
					</div>
				</div>
			</div>
			<!-- Add "scoped" attribute to limit CSS to this component only -->
			<!-- //메인비주얼 -->
		</div>
		<!-- //Main ContentsHeader -->

		<!-- Main ContentsBody -->
		<div class="content-body">
			<!-- 공지사항 -->
			<div class="section-wrap main-notice-wrap" v-if="noticeList.length > 0">
				<section class="section main-notice in-sec">
					<div class="section-header">
						<h2 class="main-tit-h2">{{ $t('sdp.menu.notice') }}</h2>
					</div>
					<div class="section-body">
						<div class="swiper-mainNotice swiper-container">
							<div class="swiper-autoplay">
								<button type="button" class="btn-ico btn-play" aria-hidden="true" tabindex="-1"><span><i class="ico ico-play-visual">{{ $t('gwa.alt.common.wa_label_2') }}</i></span></button>
								<button type="button" class="btn-ico btn-pause"><span><i class="ico ico-pause-visual">{{ $t('gwa.alt.common.wa_label_3') }}</i></span></button>
							</div>
							<div class="swiper-wrapper" aria-orientation="vertical">
								<div class="swiper-slide" v-for="notice in noticeList"><a href="javascript:;" @click="retrieveNoticeInfo(notice.seqNo)"><span class="tit">{{ notice.titleName }}</span> <span class="txt-date">[{{ notice.cDate }}]</span></a></div>
							</div>
							<div class="swiper-controller centered-r">
								<button type="button" class="swiper-button-prev"></button>
								<button type="button" class="swiper-button-next"></button>
							</div>
						</div>
					</div>
				</section>
			</div>
			<!-- //공지사항 -->

			<!-- TV 앱 -->
			<!-- 고도화 ver2 : 속성 더보기 aria-label 수정 -->
			<!-- 고도화 ver3 : 탭전환시 스와이퍼 UI처리 -->
			<div class="section-wrap main-tvapp-wrap">
				<section class="section in-sec">
					<div class="section-header">
						<h2 class="main-tit-h2">{{ $t('sdp.menu.gnb.tvapp') }}</h2>
					</div>
					<div class="section-body">
						<div class="tab-wrap">
							<div class="tab-nav tab-change tab-type2">
								<ul role="tablist">
									<li role="presentation" class="is-active"><a href="#tabContent11" role="tab" aria-controls="tabContent11" aria-selected="true" aria-expanded="true">{{ $t('sdp.main.store.tap_premium') }}</a></li>
									<li role="presentation"><a href="#tabContent12" role="tab" aria-controls="tabContent12" aria-selected="false" aria-expanded="false">{{ $t('sdp.main.store.tap_hot') }}</a></li>
									<li role="presentation"><a href="#tabContent13" role="tab" aria-controls="tabContent13" aria-selected="false" aria-expanded="false">{{ $t('sdp.main.store.tap_new') }}</a></li>
								</ul>
							</div>
							<div class="tab-body">
								<!-- 탭내용1 -->
								<div id="tabContent11" class="tab-content is-active" aria-hidden="false">
									<h3 class="blind dv-pc-only">{{ $t('gwa.alt.home.wa_alt_1') }}</h3><!-- role="tabpanel"(안읽어줌) 대체텍스트(Tab Panel) 직접입력  -->
									<div class="tab-inner">
										<!-- 앱목록 전체영역 -->
										<div class="app-lists-wrap">
											<!-- 목록그룹 -->
											<!-- 대체텍스트 형식 alt="[제목] + App Icon" -->
											<div v-if="loadingYn == 'Y'" class="section-body">
												<div class="loading-wrap">
													<div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
												</div>
											</div>
											<template v-if="loadingYn == 'N' && premiumAppList.length > 0">
												<div class="app-lists swiper-mainTvapp swiper-container type-premium" data-type="image">
													<ul class="swiper-wrapper">
														<li class="swiper-slide" v-for="premiumApp in premiumAppList">
															<div class="item-wrap">
																<p v-if="premiumApp.age >= 18 && userAge < 18" class="item-thumb thumbnail">
																	<a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" class="popup-open" @click="setAdultAppName(premiumApp.appName, premiumApp.appId)" aria-controls="popupInfoGuide" aria-haspopup="true"><img :src="premiumApp.filePthName" :alt="$t('gwa.alt.integrated.wa_label_2', {var1: premiumApp.appName})" onerror="imageResize.reset(this)" /></a>
																</p>
																<p v-else class="item-thumb thumbnail">
																	<a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(premiumApp.appId)"><img :src="premiumApp.filePthName" :alt="$t('gwa.alt.integrated.wa_label_2', {var1: premiumApp.appName})" onerror="imageResize.reset(this)" /></a>
																</p>
																<p v-if="premiumApp.age >= 18 && premiumApp < 18" class="item-tit">
																	<a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" class="popup-open" @click="setAdultAppName(premiumApp.appName, premiumApp.appId)" aria-controls="popupInfoGuide" aria-haspopup="true"><strong>{{ premiumApp.appName }}</strong></a>
																</p>
																<p v-else class="item-tit">
																	<a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(premiumApp.appId)"><strong>{{ premiumApp.appName }}</strong></a>
																</p>
																<p class="item-star">
																	<span class="js starRating-label" role="text" aria-valuemax="5" aria-valuemin="0" :aria-valuenow="appStar(premiumApp.avgSscr)" :aria-label="$t('gwa.alt.integrated.wa_label_3', {var1: appStar(premiumApp.avgSscr)})">
																		<span class="blind dv-pc-only">{{ $t('gwa.alt.integrated.wa_label_3', {var1: appStar(premiumApp.avgSscr)}) }}</span>
																		<span class="rating"><span class="rating-max"></span><span class="rating-now"></span></span>
																	</span>
																</p>
															</div>
														</li>
													</ul>
												</div>
												<button type="button" class="swiper-button-prev"></button>
												<button type="button" class="swiper-button-next"></button>
												<div class="swiper-pagination"></div>
											</template>
											<!-- 미등록게시물 -->
											<div class="noData-wrap" v-if="loadingYn == 'N' && premiumAppList.length == 0">
												<div class="noData">
													<div class="inner">
														<p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
													</div>
												</div>
											</div>
											<!-- //미등록게시물 -->
											<!-- //목록그룹 -->
										</div>
										<!-- //앱목록 전체영역 -->
										<router-link to="/main/tvapp" tag="a" class="more-page" role="button" :aria-label="$t('gwa.alt.home.wa_alt_2')">{{ $t('sdp.store.message.showdescription') }} <i class="ico ico-more centered-r"></i></router-link>
									</div>
								</div>
								<!-- //탭내용1 -->
								<!-- 탭내용2 -->
								<div id="tabContent12" class="tab-content" aria-hidden="true">
									<h3 class="blind dv-pc-only">TV앱 HOT</h3><!-- role="tabpanel"(안읽어줌) 대체텍스트(Tab Panel) 직접입력  -->
									<div class="tab-inner">
										<!-- 앱목록 전체영역 -->
										<div class="app-lists-wrap">
											<!-- 목록그룹 -->
											<!-- 대체텍스트 형식 alt="[제목] + App Icon" -->
											<div v-if="loadingYn == 'Y'" class="section-body">
												<div class="loading-wrap">
													<div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
												</div>
											</div>
											<template v-if="loadingYn == 'N' && hotAppList.length > 0">
												<div class="app-lists swiper-mainTvapp swiper-container type-hot" data-type="image">
													<ul class="swiper-wrapper">
														<li class="swiper-slide" v-for="(hotApp) in hotAppList">
															<div class="item-wrap">
																<p v-if="hotApp.age >= 18 && userAge < 18" class="item-thumb thumbnail">
																	<a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="setAdultAppName(hotApp.appName, hotApp.appId)" class="popup-open" aria-controls="popupInfoGuide" aria-haspopup="true"><img :src="hotApp.appPath" :alt="$t('gwa.alt.integrated.wa_label_2', {var1: hotApp.appName})" onerror="imageResize.reset(this)" /></a>
																</p>
																<p v-else class="item-thumb thumbnail">
																	<a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(hotApp.appId)"><img :src="hotApp.appPath" :alt="$t('gwa.alt.integrated.wa_label_2', {var1: hotApp.appName})" onerror="imageResize.reset(this)" /></a>
																</p>
																<p v-if="hotApp.age >= 18 && hotApp < 18" class="item-tit">
																	<a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="setAdultAppName(hotApp.appName, hotApp.appId)" class="popup-open" aria-controls="popupInfoGuide" aria-haspopup="true"><strong>{{ hotApp.appName }}</strong></a>
																</p>
																<p v-else class="item-tit">
																	<a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(hotApp.appId)"><strong>{{ hotApp.appName }}</strong></a>
																</p>
																<p class="item-star">
																<span class="js starRating-label" role="text" aria-valuemax="5" aria-valuemin="0" :aria-valuenow="appStar(hotApp.avgSscr)" :aria-label="$t('gwa.alt.integrated.wa_label_3', {var1 : appStar(hotApp.avgSscr)})">
																	<span class="blind dv-pc-only">{{ $t('gwa.alt.integrated.wa_label_3', {var1 : appStar(hotApp.avgSscr)}) }}</span>
																	<span class="rating"><span class="rating-max"></span><span class="rating-now"></span></span>
																</span>
																</p>
															</div>
														</li>
													</ul>
												</div>
												<button type="button" class="swiper-button-prev"></button>
												<button type="button" class="swiper-button-next"></button>
												<div class="swiper-pagination"></div>
											</template>
											<!-- 미등록게시물 -->
											<div class="noData-wrap" v-if="loadingYn == 'N' && hotAppList.length == 0">
												<div class="noData">
													<div class="inner">
														<p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
													</div>
												</div>
											</div>
											<!-- //미등록게시물 -->
											<!-- //목록그룹 -->
										</div>
										<!-- //앱목록 전체영역 -->
										<router-link to="/main/tvapp" tag="a" class="more-page" role="button" :aria-label="$t('gwa.alt.home.wa_alt_3')">{{ $t('sdp.store.message.showdescription') }} <i class="ico ico-more centered-r"></i></router-link>
									</div>
								</div>
								<!-- //탭내용2 -->
								<!-- 탭내용3 -->
								<div id="tabContent13" class="tab-content" aria-hidden="true">
									<h3 class="blind dv-pc-only">TV앱 NEW</h3><!-- role="tabpanel"(안읽어줌) 대체텍스트(Tab Panel) 직접입력  -->
									<div class="tab-inner">
										<!-- 앱목록 전체영역 -->
										<div class="app-lists-wrap">
											<!-- 목록그룹 -->
											<!-- 대체텍스트 형식 alt="[제목] + App Icon" -->
											<div v-if="loadingYn == 'Y'" class="section-body">
												<div class="loading-wrap">
													<div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
												</div>
											</div>
											<template v-if="loadingYn == 'N' && newAppList.length > 0">
												<div class="app-lists swiper-mainTvapp swiper-container type-new" data-type="image">
													<ul class="swiper-wrapper">
														<li class="swiper-slide" v-for="(newApp) in newAppList">
															<div class="item-wrap">
																<p v-if="newApp.age >= 18 && userAge < 18" class="item-thumb thumbnail">
																	<a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="setAdultAppName(newApp.appName, newApp.appId)" class="popup-open" aria-controls="popupInfoGuide" aria-haspopup="true"><img :src="newApp.appPath" :alt="$t('gwa.alt.integrated.wa_label_2', {var1: newApp.appName})" onerror="imageResize.reset(this)" /></a>
																</p>
																<p v-else class="item-thumb thumbnail">
																	<a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(newApp.appId)"><img :src="newApp.appPath" :alt="$t('gwa.alt.integrated.wa_label_2', {var1: newApp.appName})" onerror="imageResize.reset(this)" /></a>
																</p>
																<p v-if="newApp.age >= 18 && newApp < 18" class="item-tit">
																	<a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="setAdultAppName(newApp.appName, newApp.appId)" class="popup-open" aria-controls="popupInfoGuide" aria-haspopup="true"><strong>{{ newApp.appName }}</strong></a>
																</p>
																<p v-else class="item-tit">
																	<a href="javascript:;" :title="$t('gwa.alt.common.wa_title_33')" @click="goTvappDetail(newApp.appId)"><strong>{{ newApp.appName }}</strong></a>
																</p>
																<p class="item-star">
																<span class="js starRating-label" role="text" aria-valuemax="5" aria-valuemin="0" :aria-valuenow="appStar(newApp.avgSscr)" :aria-label="$t('gwa.alt.integrated.wa_label_3', {var1: appStar(newApp.avgSscr)})">
																	<span class="blind dv-pc-only">{{ $t('gwa.alt.integrated.wa_label_3', {var1 : appStar(newApp.avgSscr)}) }}</span>
																	<span class="rating"><span class="rating-max"></span><span class="rating-now"></span></span>
																</span>
																</p>
															</div>
														</li>
													</ul>
												</div>
												<div class="swiper-pagination"></div>
												<button type="button" class="swiper-button-prev"></button>
												<button type="button" class="swiper-button-next"></button>
											</template>
											<!-- 미등록게시물 -->
											<div class="noData-wrap" v-if="loadingYn == 'N' && newAppList.length == 0">
												<div class="noData">
													<div class="inner">
														<p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
													</div>
												</div>
											</div>
											<!-- //미등록게시물 -->
											<!-- //목록그룹 -->
										</div>
										<!-- //앱목록 전체영역 -->
										<router-link to="/main/tvapp" tag="a" class="more-page" role="button" :aria-label="$t('gwa.alt.home.wa_alt_4')">{{ $t('sdp.store.message.showdescription') }} <i class="ico ico-more centered-r"></i></router-link>
									</div>
								</div>
								<!-- //탭내용3 -->
							</div>
						</div>
					</div>
				</section>
			</div>
			<!-- //TV 앱 -->

			<!-- 자가진단 -->
			<div class="section-wrap main-selftest-wrap">
				<section class="section">
					<div class="section-header in-sec">
						<h2 class="main-tit-h2 type2">{{ $t('sdp.menu.gnb.self') }}</h2>
					</div>
					<div v-if="loadingYn == 'Y'" class="section-body">
						<div class="loading-wrap">
							<div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
						</div>
					</div>
					<div class="section-body" v-else>
						<div v-if="diagList.length > 0" class="swiper-mainSelftest in-sec">
							<div class="swiper-container">
								<ul class="swiper-wrapper">
									<li class="swiper-slide col" v-for="diag in diagList">
										<div class="item" :style="'background-image:url('+diag.resourcePth+')'">
											<a href="javascript:;" class="item-link" role="button" @click="updateDiagViewCnt(diag.seqNo, diag.catCode1)"><span>{{ diag.titleName }}</span></a>
										</div>
									</li>
								</ul>
							</div>
							<button type="button" class="swiper-button-prev"></button>
							<button type="button" class="swiper-button-next"></button>
							<div class="swiper-pagination"></div>
						</div>
						<!-- 미등록게시물 -->
						<div class="noData-wrap in-sec" v-else>
							<div class="noData">
								<div class="inner">
									<p><i class="ico ico-waring2"></i><span class="noData-txt">{{ $t('sdp.support.message.nolist') }}</span></p>
								</div>
							</div>
						</div>
						<!-- //미등록게시물 -->
					</div>
				</section>
			</div>
			<!-- //자가진단 -->

			<!-- 빠른메뉴 -->
			<div class="section-wrap main-quick-wrap">
				<section class="section in-sec" aria-labelledby="quickTitle">
					<div class="section-header">
						<h2 class="main-tit-h2" hidden id="quickTitle">{{ $t('gwa.alt.home.wa_alt_5') }}</h2>
					</div>
					<div class="section-body grid-wrap">
						<ul class="quick-lists grid">
							<li class="col">
								<div class="item item-quick1">
									<router-link to="/main/faq" class="item-link" role="button">
										<i class="ico ico-faq"></i>
										<span>{{ $t('sdp.menu.faq') }}</span>
									</router-link>
								</div>
							</li>
							<li class="col">
								<div class="item item-quick2"> 
									<router-link to="/main/inquiry" class="item-link" role="button">
										<i class="ico ico-ques"></i>
										<span v-html="$t('sdp.menu.qna_quick')"></span>
									</router-link>
								</div>
							</li>
							<li class="col">
								<div class="item item-quick3">
									<a href="https://www.lg.com/common/index.jsp" class="item-link" role="button" target="_blank" :title="$t('gwa.alt.common.wa_title_4')">
										<i class="ico ico-lgmain"></i>
										<span v-html="$t('sdp.main.main.website')"></span>
									</a>
								</div>
							</li>
							<li class="col">
								<div class="item item-quick4">
									<a href="http://www.lgworld.com/web.gateway.dev" class="item-link" role="button" target="_blank" :title="$t('gwa.alt.common.wa_title_4')">
										<i class="ico ico-mobile"></i>
										<span>LG Smart World<br>(Mobile)</span>
									</a>
								</div>
							</li>
							<li class="col">
								<div class="item item-quick5">
									<a href="http://seller.lgappstv.com/seller/main/Main.lge" class="item-link" role="button" target="_blank" :title="$t('gwa.alt.common.wa_title_4')">
										<i class="ico ico-seller"></i>
										<span>{{ $t('sdp.menu.seller_guide') }}</span>
									</a>
								</div>
							</li>
							<li class="col">
								<div class="item item-quick6">
									<a href="http://webostv.developer.lge.com/" class="item-link" role="button" target="_blank" :title="$t('gwa.alt.common.wa_title_4')">
										<i class="ico ico-developer"></i>
										<span>{{ $t('sdp.menu.developer_guide') }}</span>
									</a>
								</div>
							</li>
						</ul>
					</div>
				</section>
			</div>
			<!-- //빠른메뉴 -->

			<!-- 팝업_APP이용안내 -->
			<div id="popupInfoGuide" class="popup-wrap" hidden>
				<div class="popup popup-type1" role="dialog" aria-labelledby="popupInfoGuideTitle">
					<div class="blind-area popup-focus dv-ios-only" role="text" :aria-label="$t('gwa.alt.common.wa_label_55')"><!-- IOS접근성 영역자체에 초점처리 --></div>
					<div class="popup-container">
						<div class="popup-header">
							<h3 class="tit-h3" id="popupInfoGuideTitle">APP {{ $t("sdp.menu.overview") }}</h3>
						</div>
						<div class="popup-body popup-scroll">
							<div class="para-wrap align-c">
								<p class="para color-primary" v-html="$t('sdp.store.message.minorsapp')"></p>
								<p class="para" v-html="$t('sdp.store.minorsapp.detailinfo', { var1 : adultAppName })"></p>
							</div>
						</div>
						<div class="popup-footer">
							<div class="btn-wrap">
								<button @click="goLgaccount('N')" type="button" class="btn btn-type2 btn-primary"><span>{{ $t("sdp.menu.join_member") }}</span></button>
								<button @click="goLgaccount('Y')" type="button" class="btn btn-type2 btn-primary"><span>{{ $t("sdp.menu.gnb.lgaccount") }}</span></button>
								<button type="button" class="btn btn-type2 btn-secondary popup-close" aria-controls="popupInfoGuide"  :title="$t('gwa.alt.common.wa_title_58')"><span>{{ $t("sdp.message.layerpopup.close") }}</span></button>
							</div>
						</div>
						<button type="button" class="btn-ico btn-popup-close popup-close" aria-controls="popupInfoGuide" :title="$t('gwa.alt.common.wa_title_58')"><span><i class="ico ico-close2">{{ $t('sdp.message.layerpopup.close') }}</i></span></button>
					</div>
				</div>
			</div>
			<!-- //팝업_APP 이용안내 -->
		</div>
		<!-- //Main ContentsBody -->

	</section>
</template>

<script>

	import qs from "qs";
	export default {
	  name: "Home",
	  data() {
		  return {
			  bannerList : [],
			  noticeList : [],
			  premiumAppList : [],
			  hotAppList : [],
			  newAppList : [],
			  diagList : [],
              diagSeqNo : 0,
			  diagCatCode1 : 0,
			  userAge: 0,
              adultAppName: "",
			  adultAppId: "",
			  loadingYn: "Y",
			  bannerSize : 20,
			  cntryCode: _domainCntryCode
		  }
	  },
	  created() {
	  },
	  computed: {
	  },
	  methods: {
		  track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
          bannerClick(url) {
		      if (url == null || url == '') {
		          return;
			  } else {
                  window.open(url, '_blank');
			  }
		  },
          appStar (avgSscr) {
              if (avgSscr >= 9.5) {
                  return 5;
              } else if (avgSscr >= 8.5) {
                  return 4.5;
              } else if (avgSscr >= 7.5) {
                  return 4;
              } else if (avgSscr >= 6.5) {
                  return 3.5;
              } else if (avgSscr >= 5.5) {
                  return 3;
              } else if (avgSscr >= 4.5) {
                  return 2.5;
              } else if (avgSscr >= 3.5) {
                  return 2;
              } else if (avgSscr >= 2.5) {
                  return 1.5;
              } else if (avgSscr >= 1.5) {
                  return 1;
              } else if (avgSscr >= 0.5) {
                  return 0.5;
              } else {
                  return 0;
              }
          },
          retrieveNoticeInfo(seqNo) {
              const r = { path : `/main/notice/detail?seqNo=${seqNo}`+`&keyword=&curPage=1`};
              this.$router.push(r);
          },
          updateDiagViewCnt(seqNo, catCode1) {
              const vm = this;
              vm.diagSeqNo = seqNo;

              const params = {
                  seqNo: vm.diagSeqNo
              };

              this.$axios.post("/api/diag/updateDiagViewCnt.ajax",
                  qs.stringify(params)).then((result) => {
                  const r = { path : "/main/diag/detail?seqNo=" + vm.diagSeqNo + "&catCode1="
                          + catCode1 + "&searchYn=N&allClickYn=N&schTxt=&curPage=1" };
                  this.$router.push(r);
              }).catch((err) => {
                  alert("error : " + err);
              });
          },
          goTvappDetail(appId) {
              const r = { path : "/main/tvapp/detail?appId=" + appId
					  + "&catCode1=&moreYn=N&cateYn=N&orderType=0&headerName=&appRankCode=&sellrUsrNo=" };
              this.$router.push(r);
          },
          setAdultAppName(appName, appId) {
              this.adultAppName = appName;
              this.adultAppId = appId;
          },
          goLgaccount(loginYn) {
              const vm = this;

              var _params = {
                  appId: vm.adultAppId,
                  catCode1: "",
                  moreYn: "N",
                  cateYn: "N",
                  orderType: "0",
                  headerName: "",
                  appRankCode: "",
                  sellrUsrNo: ""
              };

              const params = {
				  cntryCode: _domainCntryCode,
				  path: "tvapp/detail?" + qs.stringify(_params),
                  loginYn: loginYn
              };

              this.$axios.post('/api/main/retrieveLoginInfo.ajax',
                  qs.stringify(params)).then((result) => {
                  var loginUrl = result.data.loginUrl;
                  window.location = loginUrl;
              }).catch((err) => {
                  alert(err);
              });
          }
	  },
	mounted() {
		// console.log('document.cookie: ', document.cookie);

        // ui.searchAll.close('searchAll'); // 검색바 닫힘

		const vm = this;
		ui.loading.open();

		this.$axios.post("/api/main/retrieveMain.ajax").then((result) => {
			vm.$nextTick(function () {
			    ui.loading.close();
				vm.bannerList = result.data.items.bannerList;
				vm.noticeList = result.data.items.noticeList;
				vm.premiumAppList = result.data.items.premiumAppList;
				vm.hotAppList = result.data.items.hotAppList;
				vm.newAppList = result.data.items.newAppList;
				vm.diagList = result.data.items.diagList;
				vm.userAge = result.data.items.userAge;
				vm.loadingYn = "N";

				vm.$nextTick(function() {
					ui.init();
				})
			})
		}).catch((err) => {
            ui.loading.close();
            vm.loadingYn = "N";
			alert('error : ' + err);
		});
	}
	};
</script>

