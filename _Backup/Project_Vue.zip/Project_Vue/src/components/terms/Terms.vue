<template>
    <!-- Content -->
    <section id="content" class="content terms-cont">
        <!-- Content Header -->
        <div class="content-header sub-visual">
            <div class="sub-visual-bg"></div>
            <div class="in-sec">
                <!-- 고도화 Ver1 : br추가 -->
                <div class="tit-wrap centered-c">
                    <h2 class="tit-h2" v-html="$t('sdp.menu.device.terms_condition')"></h2>
                </div>
            </div>
        </div>
        <!-- //Content Header -->

        <!-- Content Body -->
        <div class="content-body">
            <!-- 탭전체영역 -->
            <!-- 고도화 ver2 : 속성 id, labelledby 연결 -->
            <div class="tab-type4-wrap in-sec">
                <!-- 미국일때 -->
                <div v-if="deviceTerms.cntryCode == 'US'" class="terms-info">
                    As we improve the features and services on our Smart TVs, we periodically update our legal notices and agreements. This page contains the most recent versions of our Smart TV legal documents. Depending on your TV model and the software version it’s running, the legal documents applicable to your Smart TV may be different from those here. You can find the legal documents applicable to your Smart TV on the TV itself.
                </div>
                <!-- //미국일때 -->

                <!-- 메인탭 -->
                <div class="terms-version">
                    <!-- 법적 검토 후 주석 제거 -->
                    <!--<span class="form-select type-platform">
                        <select title="Platform Select" v-model="plfmCode" @change="getDeviceTerms('PLFM')">
							<option value="W19H" selected>webOS4.5</option>
							<option value="W18H">webOS4.0</option>
							<option value="W17H">webOS3.5</option>
							<option value="W16H">webOS3.0</option>
							<option value="W15H">webOS2.0</option>
							<option value="WT1H">webOS1.0</option>
							<option value="NC5U">NC4.5</option>
							<option value="NC4H">NC4.0</option>
							<option value="GP4H">NC3.0</option>
						</select>
					</span>-->
                    <!-- // 법적 검토 후 주석 제거 -->

                    <!-- 사용안함 기획변경
                    <span class="form-select type-version">
                        <select title="Version Select">
							<option value="" selected>Version 1.0</option>
							<option value=""></option>
						</select>
					</span>
                     -->
                </div>
                <nav v-show="plfmCode == 'W17H' || plfmCode == 'W18H' || plfmCode == 'W19H'" class="tab-nav tab-type4 tab-change">
                    <ul role="tablist">
                        <li role="presentation" class="is-active"><a @click="getDeviceTerms(tab1Type)" href="#tabContentTerms1" role="tab" id="tabNavTerms1" aria-controls="tabContentTerms1" aria-selected="true" aria-expanded="true"><span class="tit">{{ $t("sdp.menu.device.menutop1") }}</span></a></li>
                        <li role="presentation"><a @click="getDeviceTerms(tab2Type)" href="#tabContentTerms2" role="tab" id="tabNavTerms2" aria-controls="tabContentTerms2" aria-selected="false" aria-expanded="false"><span class="tit">{{ $t("sdp.menu.device.menutop2") }}</span></a></li>
                        <li role="presentation"><a @click="getDeviceTerms(tab3Type)" href="#tabContentTerms3" role="tab" id="tabNavTerms3" aria-controls="tabContentTerms3" aria-selected="false" aria-expanded="false"><span class="tit">{{ $t("sdp.menu.device.menutop3") }}</span></a></li>
                    </ul>
                </nav>
                <!-- 메인탭 -->

                <!-- 서브탭 -->
                <template v-if="plfmCode == 'W19H'">
                    <div class="tab-body tab-type5-wrap" v-show="loadingYn == 'N'">
                        <div id="tabContentTerms1" aria-labelledby="tabNavTerms1" class="tab-content tab-col is-active">
                            <nav class="tab-nav tab-change tab-sync tab-type5">
                                <ul role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_LGN'" role="presentation" class="is-active"><a @click="getDeviceTerms('S_LGN')" href="#tabContentTerms11" role="tab" id="tabNavTerms11" aria-controls="tabContentTerms11" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_DSC'" role="presentation"><a @click="getDeviceTerms('S_DSC')" href="#tabContentTerms12" role="tab" aria-controls="tabContentTerms12" id="tabNavTerms12" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                            </nav>
                        </div>
                        <div id="tabContentTerms2" aria-labelledby="tabNavTerms2" class="tab-content tab-col">
                            <nav class="tab-nav tab-change tab-sync tab-type5">
                                <ul v-if="deviceTerms.cntryCode == 'KR'" role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_SVC'" role="presentation"><a @click="getDeviceTerms('S_SVC')" href="#tabContentTerms21" role="tab" id="tabNavTerms21" aria-controls="tabContentTerms21" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRV'" role="presentation"><a @click="getDeviceTerms('S_PRV')" href="#tabContentTerms22" role="tab" id="tabNavTerms22" aria-controls="tabContentTerms22" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRD'" role="presentation"><a @click="getDeviceTerms('S_PRD')" href="#tabContentTerms23" role="tab" id="tabNavTerms23" aria-controls="tabContentTerms23" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRY'" role="presentation"><a @click="getDeviceTerms('S_PRY')" href="#tabContentTerms24" role="tab" id="tabNavTerms24" aria-controls="tabContentTerms24" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                                <ul v-else-if="gdprFlag == 'Y'" role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_SVC'" role="presentation"><a @click="getDeviceTerms('S_SVC')" href="#tabContentTerms21" role="tab" id="tabNavTerms21" aria-controls="tabContentTerms21" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_DTO'" role="presentation"><a @click="getDeviceTerms('S_DTO')" href="#tabContentTerms22" role="tab" id="tabNavTerms22" aria-controls="tabContentTerms22" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRP'" role="presentation"><a @click="getDeviceTerms('S_PRP')" href="#tabContentTerms23" role="tab" id="tabNavTerms23" aria-controls="tabContentTerms23" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                                <ul v-else role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_SVC'" role="presentation"><a @click="getDeviceTerms('S_SVC')" href="#tabContentTerms21" role="tab" id="tabNavTerms21" aria-controls="tabContentTerms21" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRG'" role="presentation"><a @click="getDeviceTerms('S_PRG')" href="#tabContentTerms22" role="tab" id="tabNavTerms22" aria-controls="tabContentTerms22" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                            </nav>
                        </div>
                        <div id="tabContentTerms3" aria-labelledby="tabNavTerms3" class="tab-content tab-col">
                            <nav class="tab-nav tab-change tab-sync tab-type5">
                                <ul v-if="deviceTerms.cntryCode == 'KR'" role="tablist">
                                        <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_ADC'" role="presentation"><a @click="getDeviceTerms('S_ADC')" href="#tabContentTerms31" role="tab" id="tabNavTerms31" aria-controls="tabContentTerms31" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                        <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_ADD'" role="presentation"><a @click="getDeviceTerms('S_ADD')" href="#tabContentTerms32" role="tab" id="tabNavTerms32" aria-controls="tabContentTerms32" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                        <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_VDC'" role="presentation"><a @click="getDeviceTerms('S_VDC')" href="#tabContentTerms33" role="tab" id="tabNavTerms33" aria-controls="tabContentTerms33" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                        <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_VDD'" role="presentation"><a @click="getDeviceTerms('S_VDD')" href="#tabContentTerms34" role="tab" id="tabNavTerms34" aria-controls="tabContentTerms34" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                        <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_NVC'" role="presentation"><a @click="getDeviceTerms('S_NVC')" href="#tabContentTerms35" role="tab" id="tabNavTerms35" aria-controls="tabContentTerms35" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                        <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_NVD'" role="presentation"><a @click="getDeviceTerms('S_NVD')" href="#tabContentTerms36" role="tab" id="tabNavTerms36" aria-controls="tabContentTerms36" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                        <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_TAD'" role="presentation"><a @click="getDeviceTerms('S_TAD')" href="#tabContentTerms37" role="tab" id="tabNavTerms37" aria-controls="tabContentTerms37" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                                <ul v-else-if="gdprFlag == 'Y'" role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_VNG'" role="presentation"><a @click="getDeviceTerms('S_VNG')" href="#tabContentTerms31" role="tab" id="tabNavTerms31" aria-controls="tabContentTerms31" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_TAG'" role="presentation"><a @click="getDeviceTerms('S_TAG')" href="#tabContentTerms32" role="tab" id="tabNavTerms32" aria-controls="tabContentTerms32" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle">
                                        <li v-if="title.termsMgtTpCode == 'S_ACR' && (deviceTerms.cntryCode == 'GB' || deviceTerms.cntryCode == 'FR' || deviceTerms.cntryCode == 'IT' || deviceTerms.cntryCode == 'ES' || deviceTerms.cntryCode == 'DE')" role="presentation">
                                            <a @click="getDeviceTerms('S_ACR')" href="#tabContentTerms33" role="tab" id="tabNavTerms33" aria-controls="tabContentTerms33" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a>
                                        </li>
                                    </template>
                                    <template v-for="title in termsTitle">
                                        <li v-if="title.termsMgtTpCode == 'S_CHP' && (deviceTerms.cntryCode == 'FR' || deviceTerms.cntryCode == 'IT' || deviceTerms.cntryCode == 'ES' || deviceTerms.cntryCode == 'DE')" role="presentation">
                                            <a @click="getDeviceTerms('S_CHP')" href="#tabContentTerms34" role="tab" id="tabNavTerms34" aria-controls="tabContentTerms34" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a>
                                        </li>
                                    </template>
                                </ul>
                                <ul v-else role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_ADG'" role="presentation"><a @click="getDeviceTerms('S_ADG')" href="#tabContentTerms31" role="tab" id="tabNavTerms31" aria-controls="tabContentTerms31" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_VNG'" role="presentation"><a @click="getDeviceTerms('S_VNG')" href="#tabContentTerms32" role="tab" id="tabNavTerms32" aria-controls="tabContentTerms32" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_TAG'" role="presentation"><a @click="getDeviceTerms('S_TAG')" href="#tabContentTerms33" role="tab" id="tabNavTerms33" aria-controls="tabContentTerms33" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle">
                                        <li v-if="title.termsMgtTpCode == 'S_VNA' && deviceTerms.cntryCode == 'C01'" role="presentation">
                                            <a @click="getDeviceTerms('S_VNA')" href="#tabContentTerms34" role="tab" id="tabNavTerms34" aria-controls="tabContentTerms34" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a>
                                        </li>
                                    </template>
                                    <template v-for="title in termsTitle">
                                        <li v-if="title.termsMgtTpCode == 'S_ACR' && (deviceTerms.cntryCode == 'SG' || deviceTerms.cntryCode == 'AU' || deviceTerms.cntryCode == 'CA' || deviceTerms.cntryCode == 'MX' || deviceTerms.cntryCode == 'AR' || deviceTerms.cntryCode == 'BR' || deviceTerms.cntryCode == 'MY' || deviceTerms.cntryCode == 'JP' || deviceTerms.cntryCode == 'ID' || deviceTerms.cntryCode == 'IN' || deviceTerms.cntryCode == 'US')" role="presentation">
                                            <a @click="getDeviceTerms('S_ACR')" href="#tabContentTerms35" role="tab" id="tabNavTerms35" aria-controls="tabContentTerms35" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a>
                                        </li>
                                    </template>
                                    <template v-for="title in termsTitle">
                                        <li v-if="title.termsMgtTpCode == 'S_CHP' && (deviceTerms.cntryCode == 'CA' || deviceTerms.cntryCode == 'BR' || deviceTerms.cntryCode == 'US')" role="presentation">
                                            <a @click="getDeviceTerms('S_CHP')" href="#tabContentTerms36" role="tab" id="tabNavTerms36" aria-controls="tabContentTerms36" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a>
                                        </li>
                                    </template>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </template>
                <template v-else-if="plfmCode == 'W18H'">
                    <div class="tab-body tab-type5-wrap" v-show="loadingYn == 'N'">
                        <div id="tabContentTerms1" aria-labelledby="tabNavTerms1" class="tab-content tab-col is-active">
                            <nav class="tab-nav tab-change tab-sync tab-type5">
                                <ul role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_LGN'" role="presentation" class="is-active"><a @click="getDeviceTerms('S_LGN')" href="#tabContentTerms11" role="tab" id="tabNavTerms11" aria-controls="tabContentTerms11" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_DSC'" role="presentation"><a @click="getDeviceTerms('S_DSC')" href="#tabContentTerms12" role="tab" aria-controls="tabContentTerms12" id="tabNavTerms12" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                            </nav>
                        </div>
                        <div id="tabContentTerms2" aria-labelledby="tabNavTerms2" class="tab-content tab-col">
                            <nav class="tab-nav tab-change tab-sync tab-type5">
                                <ul v-if="deviceTerms.cntryCode == 'KR'" role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_SVC'" role="presentation"><a @click="getDeviceTerms('S_SVC')" href="#tabContentTerms21" role="tab" id="tabNavTerms21" aria-controls="tabContentTerms21" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRV'" role="presentation"><a @click="getDeviceTerms('S_PRV')" href="#tabContentTerms22" role="tab" id="tabNavTerms22" aria-controls="tabContentTerms22" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRD'" role="presentation"><a @click="getDeviceTerms('S_PRD')" href="#tabContentTerms23" role="tab" id="tabNavTerms23" aria-controls="tabContentTerms23" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRY'" role="presentation"><a @click="getDeviceTerms('S_PRY')" href="#tabContentTerms24" role="tab" id="tabNavTerms24" aria-controls="tabContentTerms24" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                                <ul v-else-if="gdprFlag == 'Y'" role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_SVC'" role="presentation"><a @click="getDeviceTerms('S_SVC')" href="#tabContentTerms21" role="tab" id="tabNavTerms21" aria-controls="tabContentTerms21" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_DTO'" role="presentation"><a @click="getDeviceTerms('S_DTO')" href="#tabContentTerms22" role="tab" id="tabNavTerms22" aria-controls="tabContentTerms22" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRP'" role="presentation"><a @click="getDeviceTerms('S_PRP')" href="#tabContentTerms23" role="tab" id="tabNavTerms23" aria-controls="tabContentTerms23" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                                <ul v-else role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_SVC'" role="presentation"><a @click="getDeviceTerms('S_SVC')" href="#tabContentTerms21" role="tab" id="tabNavTerms21" aria-controls="tabContentTerms21" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRG'" role="presentation"><a @click="getDeviceTerms('S_PRG')" href="#tabContentTerms22" role="tab" id="tabNavTerms22" aria-controls="tabContentTerms22" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                            </nav>
                        </div>
                        <div id="tabContentTerms3" aria-labelledby="tabNavTerms3" class="tab-content tab-col">
                            <nav class="tab-nav tab-change tab-sync tab-type5">
                                <ul v-if="deviceTerms.cntryCode == 'KR'" role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_ADC'" role="presentation"><a @click="getDeviceTerms('S_ADC')" href="#tabContentTerms31" role="tab" id="tabNavTerms31" aria-controls="tabContentTerms31" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_ADD'" role="presentation"><a @click="getDeviceTerms('S_ADD')" href="#tabContentTerms32" role="tab" id="tabNavTerms32" aria-controls="tabContentTerms32" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_VDC'" role="presentation"><a @click="getDeviceTerms('S_VDC')" href="#tabContentTerms33" role="tab" id="tabNavTerms33" aria-controls="tabContentTerms33" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_VDD'" role="presentation"><a @click="getDeviceTerms('S_VDD')" href="#tabContentTerms34" role="tab" id="tabNavTerms34" aria-controls="tabContentTerms34" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_NVC'" role="presentation"><a @click="getDeviceTerms('S_NVC')" href="#tabContentTerms35" role="tab" id="tabNavTerms35" aria-controls="tabContentTerms35" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_NVD'" role="presentation"><a @click="getDeviceTerms('S_NVD')" href="#tabContentTerms36" role="tab" id="tabNavTerms36" aria-controls="tabContentTerms36" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_TAD'" role="presentation"><a @click="getDeviceTerms('S_TAD')" href="#tabContentTerms37" role="tab" id="tabNavTerms37" aria-controls="tabContentTerms37" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                                <ul v-else-if="gdprFlag == 'Y'" role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_VNG'" role="presentation"><a @click="getDeviceTerms('S_VNG')" href="#tabContentTerms31" role="tab" id="tabNavTerms31" aria-controls="tabContentTerms31" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_TAG'" role="presentation"><a @click="getDeviceTerms('S_TAG')" href="#tabContentTerms32" role="tab" id="tabNavTerms32" aria-controls="tabContentTerms32" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle">
                                        <li v-if="title.termsMgtTpCode == 'S_ACR' && (deviceTerms.cntryCode == 'GB' || deviceTerms.cntryCode == 'FR' || deviceTerms.cntryCode == 'IT' || deviceTerms.cntryCode == 'ES' || deviceTerms.cntryCode == 'DE')" role="presentation">
                                            <a @click="getDeviceTerms('S_ACR')" href="#tabContentTerms33" role="tab" id="tabNavTerms33" aria-controls="tabContentTerms33" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a>
                                        </li>
                                    </template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_TPS'" role="presentation"><a @click="getDeviceTerms('S_TPS')" href="#tabContentTerms34" role="tab" id="tabNavTerms34" aria-controls="tabContentTerms34" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                                <ul v-else role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_ADG'" role="presentation"><a @click="getDeviceTerms('S_ADG')" href="#tabContentTerms31" role="tab" id="tabNavTerms31" aria-controls="tabContentTerms31" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_VNG'" role="presentation"><a @click="getDeviceTerms('S_VNG')" href="#tabContentTerms32" role="tab" id="tabNavTerms32" aria-controls="tabContentTerms32" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_TAG'" role="presentation"><a @click="getDeviceTerms('S_TAG')" href="#tabContentTerms33" role="tab" id="tabNavTerms33" aria-controls="tabContentTerms33" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle">
                                        <li v-if="title.termsMgtTpCode == 'S_VNA' && deviceTerms.cntryCode == 'C01'" role="presentation">
                                            <a @click="getDeviceTerms('S_VNA')" href="#tabContentTerms34" role="tab" id="tabNavTerms34" aria-controls="tabContentTerms34" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a>
                                        </li>
                                    </template>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </template>
                <template v-else-if="plfmCode == 'W17H'">
                    <div class="tab-body tab-type5-wrap" v-show="loadingYn == 'N'">
                        <div id="tabContentTerms1" aria-labelledby="tabNavTerms1" class="tab-content tab-col is-active">
                            <nav class="tab-nav tab-change tab-sync tab-type5">
                                <ul role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_LGN'" role="presentation" class="is-active"><a @click="getDeviceTerms('S_LGN')" href="#tabContentTerms11" role="tab" id="tabNavTerms11" aria-controls="tabContentTerms11" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_DSC'" role="presentation"><a @click="getDeviceTerms('S_DSC')" href="#tabContentTerms12" role="tab" aria-controls="tabContentTerms12" id="tabNavTerms12" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                            </nav>
                        </div>
                        <div id="tabContentTerms2" aria-labelledby="tabNavTerms2" class="tab-content tab-col">
                            <nav class="tab-nav tab-change tab-sync tab-type5">
                                <ul v-if="deviceTerms.cntryCode == 'KR'" role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_SVC'" role="presentation"><a @click="getDeviceTerms('S_SVC')" href="#tabContentTerms21" role="tab" id="tabNavTerms21" aria-controls="tabContentTerms21" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRV'" role="presentation"><a @click="getDeviceTerms('S_PRV')" href="#tabContentTerms22" role="tab" id="tabNavTerms22" aria-controls="tabContentTerms22" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRD'" role="presentation"><a @click="getDeviceTerms('S_PRD')" href="#tabContentTerms23" role="tab" id="tabNavTerms23" aria-controls="tabContentTerms23" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRY'" role="presentation"><a @click="getDeviceTerms('S_PRY')" href="#tabContentTerms24" role="tab" id="tabNavTerms24" aria-controls="tabContentTerms24" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                                <ul v-else-if="gdprFlag == 'Y'" role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_SVC'" role="presentation"><a @click="getDeviceTerms('S_SVC')" href="#tabContentTerms21" role="tab" id="tabNavTerms21" aria-controls="tabContentTerms21" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_DTO'" role="presentation"><a @click="getDeviceTerms('S_DTO')" href="#tabContentTerms22" role="tab" id="tabNavTerms22" aria-controls="tabContentTerms22" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRP'" role="presentation"><a @click="getDeviceTerms('S_PRP')" href="#tabContentTerms23" role="tab" id="tabNavTerms23" aria-controls="tabContentTerms23" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                                <ul v-else role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_SVC'" role="presentation"><a @click="getDeviceTerms('S_SVC')" href="#tabContentTerms21" role="tab" id="tabNavTerms21" aria-controls="tabContentTerms21" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_PRG'" role="presentation"><a @click="getDeviceTerms('S_PRG')" href="#tabContentTerms22" role="tab" id="tabNavTerms22" aria-controls="tabContentTerms22" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                            </nav>
                        </div>
                        <div id="tabContentTerms3" aria-labelledby="tabNavTerms3" class="tab-content tab-col">
                            <nav class="tab-nav tab-change tab-sync tab-type5">
                                <ul v-if="deviceTerms.cntryCode == 'KR'" role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_ADC'" role="presentation"><a @click="getDeviceTerms('S_ADC')" href="#tabContentTerms31" role="tab" id="tabNavTerms31" aria-controls="tabContentTerms31" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_ADD'" role="presentation"><a @click="getDeviceTerms('S_ADD')" href="#tabContentTerms32" role="tab" id="tabNavTerms32" aria-controls="tabContentTerms32" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_VDC'" role="presentation"><a @click="getDeviceTerms('S_VDC')" href="#tabContentTerms33" role="tab" id="tabNavTerms33" aria-controls="tabContentTerms33" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_VDD'" role="presentation"><a @click="getDeviceTerms('S_VDD')" href="#tabContentTerms34" role="tab" id="tabNavTerms34" aria-controls="tabContentTerms34" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_NVC'" role="presentation"><a @click="getDeviceTerms('S_NVC')" href="#tabContentTerms35" role="tab" id="tabNavTerms35" aria-controls="tabContentTerms35" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_NVD'" role="presentation"><a @click="getDeviceTerms('S_NVD')" href="#tabContentTerms36" role="tab" id="tabNavTerms36" aria-controls="tabContentTerms36" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_TAD'" role="presentation"><a @click="getDeviceTerms('S_TAD')" href="#tabContentTerms37" role="tab" id="tabNavTerms37" aria-controls="tabContentTerms37" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                                <ul v-else-if="gdprFlag == 'Y'" role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_VNG'" role="presentation"><a @click="getDeviceTerms('S_VNG')" href="#tabContentTerms31" role="tab" id="tabNavTerms31" aria-controls="tabContentTerms31" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                                <ul v-else role="tablist">
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_ADG'" role="presentation"><a @click="getDeviceTerms('S_ADG')" href="#tabContentTerms31" role="tab" id="tabNavTerms31" aria-controls="tabContentTerms31" aria-selected="true" aria-expanded="true"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_VNG'" role="presentation"><a @click="getDeviceTerms('S_VNG')" href="#tabContentTerms32" role="tab" id="tabNavTerms32" aria-controls="tabContentTerms32" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                    <template v-for="title in termsTitle"><li v-if="title.termsMgtTpCode == 'S_TAG'" role="presentation"><a @click="getDeviceTerms('S_TAG')" href="#tabContentTerms33" role="tab" id="tabNavTerms33" aria-controls="tabContentTerms33" aria-selected="false" aria-expanded="false"><span class="tit" v-html="title.termsTpName"></span></a></li></template>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </template>
                <template v-else></template>
                <!-- //서브탭 -->

                <div class="section-body" v-if="loadingYn == 'Y'">
                    <div class="loading-wrap">
                        <div class="loading"><img src="/img/cmn/loading.png" :alt="$t('gwa.alt.common.wa_etc_1')"></div>
                    </div>
                </div>
                <div class="tab-body" v-else>
                    <!-- Tab11_소프트웨어 사용 계약 및 법적고지 -->
                    <div id="tabContentTerms11" class="tab-content is-active" aria-labelledby="tabNavTerms11">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms11"></h3>
                        <div id="termsSec11" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab11_소프트웨어 사용 계약 및 법적고지 -->
                    <!-- Tab12_약관 안내문 -->
                    <div id="tabContentTerms12" class="tab-content" aria-labelledby="tabNavTerms12">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms12"></h3>
                        <div id="termsSec12" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab12_약관 안내문 -->
                    <!-- Tab21_스마트TV 서비스 이용약관 -->
                    <div id="tabContentTerms21" class="tab-content" aria-labelledby="tabNavTerms21">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms21"></h3>
                        <div id="termsSec21" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab21_스마트TV 서비스 이용약관 -->
                    <!-- Tab22_개인정보 수집 이용 동의 -->
                    <div id="tabContentTerms22" class="tab-content" aria-labelledby="tabNavTerms22">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms22"></h3>
                        <div id="termsSec22" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab22_개인정보 수집 이용 동의 -->
                    <!-- Tab23_개인정보 제3자 제공 동의 -->
                    <div id="tabContentTerms23" class="tab-content" aria-labelledby="tabNavTerms23">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms23"></h3>
                        <div id="termsSec23" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab23_개인정보 제3자 제공 동의 -->
                    <!-- Tab24_개인정보 처리 방침 -->
                    <div id="tabContentTerms24" class="tab-content" aria-labelledby="tabNavTerms24">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms24"></h3>
                        <div id="termsSec24" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab24_개인정보 처리 방침 -->
                    <!-- Tab31_시청정보 수집 이용 동의 -->
                    <div id="tabContentTerms31" class="tab-content" aria-labelledby="tabNavTerms31">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms31"></h3>
                        <div id="termsSec31" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab31_시청정보 수집 이용 동의 -->
                    <!-- Tab32_시청정보 제3자 제공 동의 -->
                    <div id="tabContentTerms32" class="tab-content" aria-labelledby="tabNavTerms32">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms32"></h3>
                        <div id="termsSec32" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab32_시청정보 제3자 제공 동의 -->
                    <!-- Tab33_음성정보 수집 이용 동의 -->
                    <div id="tabContentTerms33" class="tab-content" aria-labelledby="tabNavTerms33">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms33"></h3>
                        <div id="termsSec33" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab33_음성정보 수집 이용 동의 -->
                    <!-- Tab34_음성정보 제3자 제공 동의 -->
                    <div id="tabContentTerms34" class="tab-content" aria-labelledby="tabNavTerms34">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms34"></h3>
                        <div id="termsSec34" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab34_음성정보 제3자 제공 동의 -->
                    <!-- Tab35_뉘앙스 음성정보 수집 이용 동의 -->
                    <div id="tabContentTerms35" class="tab-content" aria-labelledby="tabNavTerms35">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms35"></h3>
                        <div id="termsSec35" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab35_뉘앙스 음성정보 수집 이용 동의 -->
                    <!-- Tab36_뉘앙스 음성정보 제3자 제공 동의 -->
                    <div id="tabContentTerms36" class="tab-content" aria-labelledby="tabNavTerms36">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms36"></h3>
                        <div id="termsSec36" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab36_뉘앙스 음성정보 제3자 제공 동의 -->
                    <!-- Tab37_맞춤형 광고 이용약관 -->
                    <div id="tabContentTerms37" class="tab-content" aria-labelledby="tabNavTerms37">
                        <h3 class="blind blind-labelledby dv-pc-only" data-labelledby="tabNavTerms37"></h3>
                        <div id="termsSec37" class="terms-sec-wrap">
                            <div class="terms-sec" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //Tab37_맞춤형 광고 이용약관 -->
                    <!-- webOS 3.5 미만 약관 -->
                    <div v-if="plfmCode != 'W17H' && plfmCode != 'W18H' && plfmCode != 'W19H'" class="terms-sec-wrap">
                        <div class="terms-sec">
                            <div class="header-wrap" v-html="deviceTerms.termsCntt"></div>
                        </div>
                    </div>
                    <!-- //webOS 3.5 미만 약관 -->
                </div>
            </div>
            <!-- //탭전체영역 -->
        </div>
        <!-- //Content Body -->
    </section>
    <!-- //Content -->
</template>

<script>
    import qs from "qs";

    export default {
        name: "Terms",
        data() {
            return {
                termsTitle: [],
                deviceTerms: {},
                gdprFlag: "",
                tab1Type: "S_LGN",
                tab2Type: "S_SVC",
                tab3Type: "",
                plfmCode: "W19H",
                loadingYn: "Y"
            }
        },
        methods: {
            track () {
				console.log('@@@@ track:', this.$router.currentRoute.path);
				this.$ga.page(this.$router.currentRoute.path)
			},
            getDeviceTerms(type) {
                const vm = this;
                vm.loadingYn = "Y";
                ui.loading.open();

                var termsMgtTpCode = "";
                var netcastYn = "N";
                if(vm.plfmCode == "GP4H" || vm.plfmCode == "NC4H" || vm.plfmCode == "NC5U") {
                    netcastYn = "Y";
                }

                if(type == "PLFM") {
                    if(vm.plfmCode == "W17H" || vm.plfmCode == "W18H" || vm.plfmCode == "W19H") {
                        termsMgtTpCode = "S_LGN";
                    } else {
                        if(vm.deviceTerms.cntryCode == "KR") {
                            termsMgtTpCode = "S_PRT";
                        } else {
                            termsMgtTpCode = "S_PRG";
                        }
                    }
                    $("#tabNavTerms1").trigger("click");
                    $("#tabNavTerms11").trigger("click");
                } else if(type == "") {
                    if(vm.deviceTerms.cntryCode == "KR") {
                        termsMgtTpCode = "S_ADC";
                    } else if (vm.gdprFlag == "Y") {
                        termsMgtTpCode = "S_VNG";
                    } else {
                        termsMgtTpCode = "S_ADG";
                    }
                } else {
                    termsMgtTpCode = type;
                }

                const params = {
                    termsMgtTpCode : termsMgtTpCode,
                    plfmCode : vm.plfmCode,
                    netcastYn : netcastYn
                };

                this.$axios.post("/api/terms/retrieveDeviceTerms.ajax",
                    qs.stringify(params)).then((result) => {
                    ui.loading.close();
                    vm.termsTitle = result.data.termsTitle;
                    vm.deviceTerms = result.data.deviceTerms;
                    vm.gdprFlag = result.data.gdprFlag;
                    vm.loadingYn = "N";

                    vm.$nextTick(function() {
                        ui.tab.init();
                        loadLabelledby();
                        if ($('.terms-sec span').length){ $('.terms-sec span').removeAttr('style'); }
                    });
                }).catch((err) => {
                    ui.loading.close();
                    vm.loadingYn = "N";
                    alert("error : " + err);
                });
            }
        },
        computed: {

        },
        mounted() {
            const vm = this;
            $(window).scrollTop(0);
            vm.getDeviceTerms("S_LGN");
        }
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
