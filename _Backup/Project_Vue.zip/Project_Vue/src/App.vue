<template>
<div id="app">
	<router-view />
</div>
</template>

<script>

import qs from "qs";

export default {
		name: "App",
		data() {
			return {
						isLogin: false
			}
			},
			computed: {

			},
			mounted() {
				console.log('App.vue mounted..');
				console.log('_domainCntryCode', _domainCntryCode);
				console.log('_domainLangCode', _domainLangCode);
				console.log('lang', this.$route.query.lang);

				var firstName = this.getCookie('firstName');
				var lastName = this.getCookie('lastName');
				if(firstName == null || lastName == null) {
					this.isLogin = false;
				} else {
					this.isLogin = true;
				}

				console.log('locale ', this.$i18n.locale);

				this.$store.state.cntryCode = _domainCntryCode;
				this.$store.state.langCode = _domainLangCode;

				this.$i18n.locale = _domainLangCode;

				var lang = this.$route.query.lang;
				if(lang != undefined && lang != null) {
					var langCode = lang.split('_')[0];
					this.$i18n.locale = langCode;
					this.$store.state.langCode = langCode;
				}

				// console.log('$store', this.$store);

				// console.log('locale ', this.$i18n.locale);

				// isLogin() {
				// 	var firstName = this.getCookie('firstName');
				// 	var lastName = this.getCookie('lastName');
				// 	if(firstName == null || lastName == null) {
				// 		return false;
				// 	}
				// 	return true;
				// }

			},
		methods : {
			
				logout() {
					const vm = this;
					this.$axios.get('/api/main/logout.ajax').then((result) => {
						console.log('document.cookie', document.cookie);
						this.isLogin = false;
					})
				},
		  goChatbot() {
					window.open("https://www.lgechat.com/kr/index.html", '_blank');
				},
				goLgaccount() {
					var params = {
						cntryCode: _domainCntryCode,
						path: ''
					}
					this.$axios.post('/api/main/retrieveLoginInfo.ajax'
						, qs.stringify(params)).then((result) => {
						var loginUrl = result.data.loginUrl;
						window.location = loginUrl;
					}).catch((err) => {
						alert(err);
					});
				},
		  retrieveFamilySite(event) {
			  if (event.target.value == "smartWorld") {
				  window.location.href = "http://www.lgworld.com/web.gateway.dev";
			  } else if (event.target.value == "sellerLounge") {
				  window.location.href = "http://seller.lgappstv.com/seller/main/Main.lge";
			  } else if (event.target.value == "developer") {
				  window.location.href = "http://webostv.developer.lge.com/";
			  } else {
				  //alert('패밀리 사이트를 선택해주세요.');
			  }
		  },
			getCookie(cname) {
				var name = cname + "=";
				var decodedCookie = decodeURIComponent(document.cookie);
				var ca = decodedCookie.split(';');
				for(var i = 0; i <ca.length; i++) {
					var c = ca[i];
					while (c.charAt(0) == ' ') {
						c = c.substring(1);
					}
					if (c.indexOf(name) == 0) {
						var str = c.substring(name.length, c.length);
						if(str === null || str === '') {
							return null;
						} else {
							return str;
						}
					}
				}
				return null;
			}
		}
	};
</script>