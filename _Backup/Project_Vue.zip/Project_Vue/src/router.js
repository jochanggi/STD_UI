import Vue from 'vue'
import Router from 'vue-router'
import NotFound from '@/components/common/NotFound'


import Home from './components/Home'
import IntegratedSearchList from './components/integratedsearch/IntegratedSearchList'
import Notice from './components/notice/Notice'
import NoticeDetail from './components/notice/NoticeDetail'
import Faq from './components/faq/Faq'
import Diag from './components/diag/Diag'
import DiagDetail from './components/diag/DiagDetail'
import Inquiry from './components/inquiry/Inquiry'
import InquiryRegister from "./components/inquiry/InquiryRegister"
import InquiryList from "./components/inquiry/InquiryList"
import InquiryDetail from "./components/inquiry/InquiryDetail"
import QRCodeScanner from './components/inquiry/QRCodeScanner'
import QRCodeUnsupported from './components/inquiry/QRCodeUnsupported'
import Tvapp from './components/tvapp/Tvapp'
import TvappSeller from './components/tvapp/TvappSeller'
import TvappDetail from './components/tvapp/TvappDetail'
import Nation from './components/common/Nation'
import Terms from './components/terms/Terms'
import Oss from './components/oss/Oss'
import Main from './components/Main'

Vue.use(Router)

export default new Router({
    mode: 'history',
    linkActiveClass: 'active',
    routes: [
        // main
        { 
            name: "main", path: '/main', component: Main,
            children: [
                { name: 'home', path: '/', component: Home },
                { name: 'integratedSearchList', path: 'integrated/search', component: IntegratedSearchList },
                { name: 'notice', path: 'notice', component: Notice },
                { name: 'noticeDetail', path: 'notice/detail', component: NoticeDetail },
                { name: 'faq', path: 'faq', component: Faq },
                { name: 'diag', path: 'diag', component: Diag },
                { name: 'diagDetail', path: 'diag/detail', component: DiagDetail },
                { name: 'inquiry', path: 'inquiry', component: Inquiry },
                { name: 'inquiryRegister', path: 'inquiry/register', component: InquiryRegister, props: true},
                { name: 'inquiryList', path: 'inquiry/list', component: InquiryList, props: true},
                { name: 'inquiryDetail', path: 'inquiry/detail', component: InquiryDetail, props: true},
                { name: 'tvapp', path: 'tvapp', component: Tvapp },
                { name: 'tvappSeller', path: 'tvapp/seller', component: TvappSeller },
                { name: 'tvappDetail', path: 'tvapp/detail', component: TvappDetail },
                { name: 'terms', path: 'terms', component: Terms },
                { path: "*", component: NotFound },
            ]
        },
        { 
            name: 'nation', path: '/nation', component: Nation
        },
        {
            name: 'scanner', path: '/scanner', component: QRCodeScanner
        },
        {
            name: 'unsupported', path: '/unsupported', component: QRCodeUnsupported
        },
        {
            name: 'oss', path: '/oss', component: Oss
        },
        {
            path: '/index.html', redirect: '/main'
        },
        {
            path: '/', redirect: '/main'
        },
        {
            path: "*", component: NotFound
        }
    ]
});
